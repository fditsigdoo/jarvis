# Launch ULTRON on Windows.  Double-click start.bat, or:  powershell -ExecutionPolicy Bypass -File start.ps1
$ErrorActionPreference = 'Continue'   # native tools report failure through exit codes
Set-Location -LiteralPath $PSScriptRoot

$model = if ($env:ULTRON_MODEL) { $env:ULTRON_MODEL } else { 'gemma3:12b' }

function Fail($msg) { Write-Host "`n  $msg`n" -ForegroundColor Red; Read-Host 'Press Enter to close'; exit 1 }

# Python 3.10 or newer, through the py launcher (or python on PATH).
$pyCmd = $null
foreach ($c in @(@('py', '-3'), @('python'))) {
  if (Get-Command $c[0] -ErrorAction SilentlyContinue) {
    & $c[0] @($c[1..($c.Length - 1)]) -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" 2>$null
    if ($LASTEXITCODE -eq 0) { $pyCmd = $c; break }
  }
}
if (-not $pyCmd) { Fail 'Python 3.10 or newer isn''t installed. Get it from https://python.org (tick "Add python.exe to PATH").' }
function Py { & $pyCmd[0] @($pyCmd[1..($pyCmd.Length - 1)]) @args }

$ollama = (Get-Command ollama -ErrorAction SilentlyContinue).Source
if (-not $ollama) {
  $guess = Join-Path $env:LOCALAPPDATA 'Programs\Ollama\ollama.exe'
  if (Test-Path $guess) { $ollama = $guess } else { Fail 'Ollama isn''t installed. Get it from https://ollama.com/download' }
}

function OllamaUp { try { Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags' -TimeoutSec 2 -ErrorAction Stop | Out-Null; $true } catch { $false } }
if (-not (OllamaUp)) {
  Write-Host 'Starting Ollama...'
  Start-Process -FilePath $ollama -ArgumentList 'serve' -WindowStyle Hidden
  for ($i = 0; $i -lt 30 -and -not (OllamaUp); $i++) { Start-Sleep -Milliseconds 500 }
}

# Gemini models don't live in Ollama, so only pull local ones.
if ($model -notlike 'gemini-*') {
  $have = (Invoke-RestMethod -Uri 'http://127.0.0.1:11434/api/tags').models | ForEach-Object { $_.name }
  $want = if ($model -like '*:*') { $model } else { "$model`:latest" }
  if ($have -notcontains $want) {
    Write-Host "Pulling $model (first run only)..."
    & $ollama pull $model
    if ($LASTEXITCODE -ne 0) { Fail "Couldn't pull $model" }
  }
}

# Its own virtual environment, so nothing touches your system Python. Re-installs when requirements.txt changes.
$venvPy = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
if (-not (Test-Path $venvPy)) { Write-Host 'Creating the Python environment...'; Py -m venv .venv; if ($LASTEXITCODE -ne 0) { Fail 'Could not create .venv' } }
$stamp = Join-Path $PSScriptRoot '.venv\.requirements.sha'
$hash = (Get-FileHash requirements.txt -Algorithm SHA256).Hash
if (-not (Test-Path $stamp) -or (Get-Content $stamp -ErrorAction SilentlyContinue) -ne $hash) {
  Write-Host 'Installing dependencies...'
  & $venvPy -m pip install --quiet --upgrade pip
  & $venvPy -m pip install --quiet -r requirements.txt
  if ($LASTEXITCODE -ne 0) { Fail 'pip install failed' }
  Set-Content -Path $stamp -Value $hash
}

& $venvPy run.py
