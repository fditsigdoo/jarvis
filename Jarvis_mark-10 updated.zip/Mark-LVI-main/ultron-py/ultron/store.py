"""Everything ULTRON keeps on disk: facts, her own interface, paired devices, preferences,
scheduled jobs, and the long-term conversation log with its keyword search and journal."""
from __future__ import annotations

import json
import math
import os
import re
import secrets
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path

from .config import MEM_DIR, now_ms

# Live sessions (websocket connections). Filled in by server.py (serve_agent); the broadcast helpers below use it.
clients: set = set()

_lock = threading.Lock()


def read_json(path: Path, default):
    try:
        return json.loads(path.read_text("utf8"))
    except Exception:
        return default


def write_json(path: Path, data, mode: int | None = None):
    try:
        tmp = path.with_suffix(path.suffix + ".tmp")
        with _lock:
            tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), "utf8")
            if mode is not None:
                try:
                    os.chmod(tmp, mode)
                except OSError:
                    pass
            os.replace(tmp, path)
    except OSError:
        pass


def _send_all(msg: dict, only=lambda c: True):
    for c in list(clients):
        if only(c):
            c.send(msg)


# ───────────────────────── facts ─────────────────────────
MEM_FILE = MEM_DIR / "memory.json"
MEM: dict = {"facts": [], **read_json(MEM_FILE, {})}
_mem_seq = max([f.get("id", 0) for f in MEM["facts"]] or [0])


def save_memory():
    write_json(MEM_FILE, MEM)


def broadcast_memory():
    _send_all({"type": "memory", "facts": MEM["facts"][-60:]})


def remember_fact(text) -> dict | None:
    global _mem_seq
    text = str(text or "").strip()
    if not text:
        return None
    # Replace a near-duplicate instead of piling up.
    norm = lambda t: re.sub(r"[^a-z0-9 ]", "", t.lower()).strip()
    MEM["facts"] = [f for f in MEM["facts"] if norm(f["text"]) != norm(text)]
    _mem_seq += 1
    fact = {"id": _mem_seq, "text": text, "time": now_ms()}
    MEM["facts"].append(fact)
    MEM["facts"] = MEM["facts"][-200:]
    save_memory()
    broadcast_memory()
    return fact


def forget_facts(query) -> int:
    q = str(query or "").lower().strip()
    if not q:
        return 0
    before = len(MEM["facts"])
    MEM["facts"] = [] if q in ("everything", "all") else [f for f in MEM["facts"] if q not in f["text"].lower()]
    n = before - len(MEM["facts"])
    if n:
        save_memory()
        broadcast_memory()
    return n


def memory_text() -> str:
    if not MEM["facts"]:
        return ""
    lines = "\n".join(f"- {f['text']}" for f in MEM["facts"][-60:])
    return f"\nWhat you remember about the user (use this naturally; don't recite it):\n{lines}\n"


PROFILE_FILE = MEM_DIR / "profile.md"


def profile_text() -> str:
    """Who the user is and how to talk to them. Re-read every turn so edits apply live."""
    try:
        return PROFILE_FILE.read_text("utf8").strip()
    except OSError:
        return ""


def profile_greetings() -> list:
    parts = re.split(r"^GREETINGS\b.*$", profile_text(), flags=re.M)
    sec = parts[1] if len(parts) > 1 else ""
    return re.findall(r'^- "(.+)"\s*$', sec, flags=re.M)


# ───────────────────────── her own interface ─────────────────────────
GUI_FILE = MEM_DIR / "gui.json"


def gui_empty() -> dict:
    return {"theme": None, "css": {}, "edits": [], "scripts": {}}


GUI: dict = {**gui_empty(), **read_json(GUI_FILE, {})}


def save_gui():
    write_json(GUI_FILE, GUI)


def reset_gui(what: str):
    global GUI
    if what == "all":
        GUI.clear()
        GUI.update(gui_empty())
    else:
        GUI[what] = gui_empty()[what]
    save_gui()


def keep_edit(e: dict):
    """A later text/html/visibility change to the same element replaces the earlier one."""
    def slot(x):
        a = x.get("action")
        if a in ("hide", "show"):
            return f"{x.get('selector')}|visibility"
        if a in ("text", "html"):
            return f"{x.get('selector')}|content"
        return json.dumps(x, sort_keys=True, default=str)
    GUI["edits"] = ([x for x in GUI["edits"] if slot(x) != slot(e)] + [e])[-200:]
    save_gui()


# ───────────────────────── paired devices ─────────────────────────
DEVICES_FILE = MEM_DIR / "devices.json"
DEVICES: list = read_json(DEVICES_FILE, [])


def save_devices():
    write_json(DEVICES_FILE, DEVICES, 0o600)


# ───────────────────────── preferences ─────────────────────────
PREFS_FILE = MEM_DIR / "prefs.json"
PREFS: dict = read_json(PREFS_FILE, {})


def save_prefs(p: dict):
    PREFS.clear()
    PREFS.update(p)
    write_json(PREFS_FILE, PREFS)


# ───────────────────────── scheduler data ─────────────────────────
SCHED_FILE = MEM_DIR / "schedule.json"
JOBS: list = read_json(SCHED_FILE, [])
_job_seq = max([j.get("id", 0) for j in JOBS] or [0])


def broadcast_jobs():
    _send_all({"type": "jobs", "list": jobs_public()})


def jobs_public() -> list:
    return [{k: v for k, v in j.items() if k not in ("handle", "lastValue")} for j in JOBS]


def save_jobs():
    write_json(SCHED_FILE, JOBS)
    broadcast_jobs()


def next_fire(in_minutes=None, at=None, iso=None, daily=None):
    """Next matching timestamp (ms). Accepts in_minutes, at "HH:MM" (+daily), or an ISO time."""
    if iso:
        try:
            return int(datetime.fromisoformat(str(iso).replace("Z", "+00:00")).timestamp() * 1000)
        except ValueError:
            return None
    if in_minutes is not None:
        try:
            return now_ms() + int(float(in_minutes) * 60000)
        except (TypeError, ValueError):
            return None
    if at:
        m = re.search(r"(\d{1,2}):(\d{2})\s*(am|pm)?", str(at), re.I)
        if not m:
            return None
        h, mi = int(m.group(1)), int(m.group(2))
        if m.group(3):
            pm = m.group(3).lower() == "pm"
            if pm and h < 12:
                h += 12
            if not pm and h == 12:
                h = 0
        try:
            d = datetime.now().replace(hour=h, minute=mi, second=0, microsecond=0)
        except ValueError:
            return None
        if d.timestamp() * 1000 <= now_ms():
            d += timedelta(days=1)
        return int(d.timestamp() * 1000)
    return None


def add_job(job: dict) -> dict:
    global _job_seq
    _job_seq += 1
    job["id"] = _job_seq
    JOBS.append(job)
    save_jobs()
    return job


def cancel_jobs(match) -> int:
    before = len(JOBS)
    JOBS[:] = [j for j in JOBS if not match(j)]
    n = before - len(JOBS)
    if n:
        save_jobs()
    return n


# ───────────────────────── long-term conversation log ─────────────────────────
# Every exchange is kept forever in memory/conversation.jsonl. The latest messages come back after a
# restart, a journal summarizes each conversation once it goes quiet, and every new message pulls in
# the most relevant bits of older conversations (keyword search, BM25).
LOG_FILE = MEM_DIR / "conversation.jsonl"
JOURNAL_FILE = MEM_DIR / "journal.jsonl"


def read_jsonl(f: Path) -> list:
    out = []
    try:
        for line in f.read_text("utf8").split("\n"):
            if line.strip():
                try:
                    out.append(json.loads(line))
                except ValueError:
                    pass
    except OSError:
        pass
    return out


def append_line(f: Path, obj):
    try:
        with _lock, open(f, "a", encoding="utf8") as fh:
            fh.write(json.dumps(obj, ensure_ascii=False) + "\n")
    except OSError:
        pass


LOG: list = read_jsonl(LOG_FILE)         # {t, role, text}
JOURNAL: list = read_jsonl(JOURNAL_FILE)  # {t, from, to, summary}

STOP = set(("the and you for that this with have are was but not what your can just like from about they there would will been them then than "
            "when were also into some our out its more only very want know get got how who why where which here him his her she let lets yeah okay sure did does "
            "done going gonna its it's i'm don't that's one all any now way well make made say said tell told right think thing things really much").split(" "))
_WS = re.compile(r"\s+")
_TERM = re.compile(r"(?:[^\W_]|')(?:[^\W_]|'){2,}")


def terms(t) -> list:
    return [w for w in _TERM.findall(str(t).lower()) if w not in STOP]


_DF: dict = {}
_total_terms = 0


def index_entry(e: dict):
    global _total_terms
    e["terms"] = terms(e["text"])
    _total_terms += len(e["terms"])
    for w in set(e["terms"]):
        _DF[w] = _DF.get(w, 0) + 1


for _e in LOG:
    index_entry(_e)


def for_log(c: str) -> str:
    """Action tags become a short note, so the log says what was done without the raw JSON."""
    c = re.sub(r"<think>[\s\S]*?</think>", "", c)

    def note(m):
        try:
            j = json.loads(m.group(1))
            args = f" {json.dumps(j.get('args'))[:120]}" if j.get("args") else ""
            return f" [did {j.get('tool')}{args}]"
        except Exception:
            return " [did an action]"
    return re.sub(r"<action>([\s\S]*?)</action>", note, c).strip()


class Convo(list):
    """The one conversation shared by every device. Anything added is also written to the log."""

    def append(self, m):  # noqa: D102
        m.setdefault("t", now_ms())
        record(m)
        super().append(m)

    def push(self, *items):
        for m in items:
            self.append(m)


CONVO = Convo()


def record(m: dict):
    if not isinstance(m.get("content"), str) or m["content"].startswith("[TOOL RESULTS]"):
        return
    text = for_log(m["content"])
    if not text or text == "…":
        return
    e = {"t": m["t"], "role": m["role"], "text": text}
    append_line(LOG_FILE, e)
    index_entry(e)
    LOG.append(e)
    schedule_journal()


# Pick up where we left off. The "[did ...]" notes are left out so the model doesn't parrot them.
for _e in LOG[-40:]:
    list.append(CONVO, {"role": _e["role"], "content": re.sub(r"\s*\[did [^\]]*\]", "", _e["text"]).strip() or "…", "t": _e["t"]})


def when(t) -> str:
    d = datetime.fromtimestamp(t / 1000)
    return f"{d.strftime('%a')} {d.day} {d.strftime('%b %Y, %H:%M')}"


def log_line(e: dict) -> str:
    who = "Them" if e["role"] == "user" else "You"
    return "[%s] %s: %s" % (when(e["t"]), who, _WS.sub(" ", e["text"])[:300])


def search(query, pool: list, limit: int) -> list:
    q = list(dict.fromkeys(terms(query)))
    if not q or not pool:
        return []
    n = len(LOG)
    avg = _total_terms / max(1, n)
    scored = []
    for e in pool:
        score = 0.0
        for w in q:
            tf = e["terms"].count(w)
            if not tf:
                continue
            df = _DF.get(w, 1)
            score += math.log(1 + (n - df + 0.5) / (df + 0.5)) * (tf * 2.2) / (tf + 1.2 * (0.25 + 0.75 * len(e["terms"]) / avg))
        if score > 0:
            scored.append((score, e))
    scored.sort(key=lambda x: -x[0])
    return scored[:limit]


def recall_for(query) -> list:
    """Older exchanges that match what was just said, with the reply next to each hit."""
    recent_from = CONVO[-24:][0]["t"] if CONVO else float("inf")   # those are in context already
    pool = [e for e in LOG if e["t"] < recent_from]
    lines = []
    for score, e in search(query, pool, 3):
        if score < 1:   # one rare word in a long message scores ~1.8; common words score far lower
            continue
        i = LOG.index(e)
        for x in LOG[max(0, i - 1): i + 2]:
            if x["t"] < recent_from:
                ln = log_line(x)
                if ln not in lines:
                    lines.append(ln)
    return lines


def past_text(s) -> str:
    journal = "\n".join("- %s: %s" % (when(j["from"]), _WS.sub(" ", j["summary"])) for j in JOURNAL[-8:])
    recalled = getattr(s, "recall", None) or []
    if not journal and not recalled:
        return ""
    out = ("\nYou remember your past conversations with them, across every device and restart. Bring them up naturally when relevant, "
           "and never claim you can't remember earlier chats; use recall to look further back.")
    if journal:
        out += f"\nJournal of recent conversations:\n{journal}"
    if recalled:
        out += "\nFrom older conversations, possibly relevant to what they just said:\n" + "\n".join(recalled)
    return out + "\n"


def day_range(date):
    d = str(date or "").lower().strip()
    start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    m = re.match(r"^(\d+)\s+days?\s+ago$", d)
    if d == "today":
        pass
    elif d == "yesterday":
        start -= timedelta(days=1)
    elif m:
        start -= timedelta(days=int(m.group(1)))
    elif re.match(r"^\d{4}-\d{2}-\d{2}$", d):
        try:
            start = datetime.strptime(d, "%Y-%m-%d")
        except ValueError:
            return None
    else:
        return None
    a = int(start.timestamp() * 1000)
    return [a, a + 86400000]


# When a conversation goes quiet, the model writes itself a short journal entry about it.
_journal_timer = None
_journal_loop = None
JOURNAL_PROMPT = ("Write a journal entry for the assistant's long-term memory about this conversation. 2 to 5 plain sentences: what was talked about, "
                  "decided, built or done, and anything to follow up on. Facts only, no commentary, no markdown.\n\n")


def schedule_journal():
    global _journal_timer
    import asyncio
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = _journal_loop
    if loop is None:
        return
    if _journal_timer:
        _journal_timer.cancel()
    _journal_timer = loop.call_later(15 * 60, lambda: asyncio.ensure_future(write_journal()))


async def write_journal():
    from . import llm
    from .config import CONFIG
    last_to = JOURNAL[-1]["to"] if JOURNAL else 0
    fresh = [e for e in LOG if e["t"] > last_to]
    for i in range(0, len(fresh), 120):
        chunk = fresh[i:i + 120]
        if len(chunk) < 4:
            break
        transcript = "\n".join(f"{'User' if e['role'] == 'user' else 'Assistant'}: {e['text'][:400]}" for e in chunk)
        try:
            r = await llm.chat_once(PREFS.get("model") or CONFIG["model"] or llm.default_model(),
                                    [{"role": "user", "content": JOURNAL_PROMPT + transcript}], None, {"temperature": 0.3})
        except Exception:
            return
        summary = r["text"] if r.get("ok") else ""
        if not summary:
            return
        entry = {"t": now_ms(), "from": chunk[0]["t"], "to": chunk[-1]["t"], "summary": summary}
        JOURNAL.append(entry)
        append_line(JOURNAL_FILE, entry)
        print(f"  ✎ journal: {summary[:120]}")


def new_token(n: int = 32) -> str:
    return secrets.token_urlsafe(n)
