"""The agent's tools. Each is `async def name(s, args, ctx)` and returns a dict with `ok` and either
`message` / data or `error`. `s` is the session (the UI that asked), `ctx` carries the action id and cancel signal."""
from __future__ import annotations

import asyncio
import base64
import json
import os
import re
import urllib.parse
import urllib.request
from datetime import datetime
from pathlib import Path

from . import control as ctl
from . import llm, phone, store
from . import osplat as plat
from . import scheduler as sched
from .config import (CONFIG, DANGEROUS, HOST, IS_WIN, PHONE_APPS, PROMPTS, SITES, TTS_DIR, WORKSPACE, app_name, clamp, expand_path,
                     has_xy, normalize_url, num, slugify)
from .control import control
from .proc import run, spawn_quiet

WEB_PROMPT = (PROMPTS / "web_prompt.txt").read_text("utf8")


def extract_html(raw: str):
    m = re.search(r"<!doctype html|<html", raw, re.I)
    if not m:
        return None
    t = raw[m.start():]
    end = t.lower().rfind("</html>")
    return t[:end + 7] if end >= 0 else re.sub(r"```[\s\S]*$", "", t) + "\n</html>"


def _coord(v) -> int:
    return round(float(v))


async def _confirm(s, command: str, why: str) -> dict | None:
    """Asks the user (in the UI) to approve something. Returns an error dict if they didn't."""
    if not await s.request({"type": "confirm_request", "command": command}, 120):
        return {"ok": False, "error": why}
    return None


async def ask_vision(s, signal, prompt: str, image: str) -> dict:
    """One image + prompt to the vision model (the chat model if it can see, else CONFIG.visionModel)."""
    model = s.model if await llm.has_vision(s.model) else CONFIG["vision_model"]
    return await llm.chat_once(model, [{"role": "user", "content": prompt, "images": [image]}], signal)


async def look_at_screen(s, ctx, prompt: str, app: str = "") -> dict:
    """Screenshot the screen (or a window) and ask the vision model about it. Shared by see_screen/verify."""
    perm = await control("perm")
    if perm["ok"] and '"screen":false' in perm["message"]:
        return {"ok": False, "error": "Screen Recording permission is off. Enable it for the app running ULTRON in System Settings → Privacy & Security → Screen Recording, then restart ULTRON."}
    shot = await ctl.capture_screen(app)
    if not shot:
        return {"ok": False, "error": "Screenshot failed"}
    where = f" showing the {shot['app']} window" if shot["windowShot"] else " screen"
    return await ask_vision(s, ctx.get("signal"), f"This is a screenshot of the user's {HOST}{where}. {prompt}", shot["image"])


def _fetch(url: str, headers: dict, timeout: float) -> str:
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf8", "replace")


async def _afetch(url: str, headers: dict | None = None, timeout: float = 10) -> str:
    return await asyncio.get_running_loop().run_in_executor(None, _fetch, url, headers or {}, timeout)


def _stamp() -> str:
    return datetime.now().strftime("%Y-%m-%d at %H.%M.%S")


def _mins_left(b: dict) -> str:
    m = b.get("minutes_left")
    return f", {m // 60}:{m % 60:02d} remaining" if m else ""


# ───────────────────────── opening things ─────────────────────────
async def open_app(s, a, ctx):
    app = app_name(a.get("name"))
    if not app:
        return {"ok": False, "error": "No application name given"}
    r = await plat.open_app(app)
    if r["ok"] and IS_WIN:
        await asyncio.sleep(1.5)
    return r


async def close_app(s, a, ctx):
    return await plat.close_app(a.get("name"))


async def find_files(s, a, ctx):
    query = a.get("query")
    if not query:
        return {"ok": False, "error": "No search query given"}
    hits = await plat.find_files(str(query), a.get("kind"))
    return {"ok": True, "count": len(hits), "files": hits[:15]} if hits else {"ok": False, "error": f'Nothing named "{query}" found'}


async def open_file(s, a, ctx):
    p = a.get("path")
    if not p:
        return {"ok": False, "error": "No path given"}
    full = expand_path(p, Path.home())
    if not full.exists():
        return {"ok": False, "error": f"Not found: {full}"}
    r = await plat.open_path(str(full), app_name(a["app"]) if a.get("app") else "")
    return {"ok": True, "message": f"Opened {full}"} if r["ok"] else r


async def open_url(s, a, ctx):
    return await plat.open_in_browser(normalize_url(a.get("url")), a.get("browser") or "")


async def search_web(s, a, ctx):
    q = a.get("query") or ""
    r = await plat.open_in_browser(f"https://www.google.com/search?q={urllib.parse.quote(q)}")
    return {"ok": True, "message": f'Searched the web for "{q}"'} if r["ok"] else r


async def play_youtube(s, a, ctx):
    q = a.get("query") or ""
    url = f"https://www.youtube.com/results?search_query={urllib.parse.quote(q)}"
    try:
        html = await _afetch(url, {"accept-language": "en-US"}, 6)
        m = re.search(r'"videoId":"([\w-]{11})"', html)
        if m:
            url = f"https://www.youtube.com/watch?v={m.group(1)}"
    except Exception:
        pass
    await plat.open_in_browser(url)
    return {"ok": True, "message": f'Playing "{q}" on YouTube' if "watch" in url else f'Opened YouTube results for "{q}"'}


async def open_vscode(s, a, ctx):
    p = a.get("path")
    full = ""
    if p:
        f = expand_path(p)
        if not f.exists():
            return {"ok": False, "error": f"Path not found: {f}"}
        full = str(f)
    r = await plat.open_vscode(full)
    return {"ok": True, "message": f"Opened VS Code{f' at {full}' if full else ''}"} if r["ok"] else r


async def build_website(s, a, ctx):
    name, description = a.get("name"), a.get("description")
    slug = slugify(name or description) or f"site-{phone.now_ms()}"
    folder = SITES / slug
    model = s.coder_model or s.model
    raw, last = "", 0
    s.send({"type": "code_start", "id": ctx["id"], "file": f"sites/{slug}/index.html", "model": model})
    msgs = [{"role": "system", "content": WEB_PROMPT},
            {"role": "user", "content": f"Website name: {name or 'untitled'}\nBrief: {description or name}\nUse exactly this name for the brand."}]
    async for chunk in llm.chat(model, msgs, ctx.get("signal"), {"num_predict": 12000, "temperature": 0.7}):
        raw += chunk
        s.send({"type": "code", "id": ctx["id"], "text": chunk})   # live on the HUD
        if len(raw) - last > 300:
            last = len(raw)
            s.send({"type": "action", "id": ctx["id"], "tool": "build_website", "status": "running", "detail": f"writing code · {len(raw) / 1024:.1f} KB"})
    html = extract_html(raw)
    s.send({"type": "code_end", "id": ctx["id"], "ok": bool(html), "file": str(folder / "index.html") if html else ""})
    if not html:
        return {"ok": False, "error": "The model did not produce valid HTML"}
    folder.mkdir(parents=True, exist_ok=True)
    file = folder / "index.html"
    file.write_text(html, "utf8")
    await plat.open_path(str(file))
    return {"ok": True, "message": "Website built and opened in the browser", "folder": str(folder), "file": str(file)}


async def write_file(s, a, ctx):
    p = a.get("path")
    if not p:
        return {"ok": False, "error": "No path given"}
    full = expand_path(p)
    if WORKSPACE.resolve() not in full.parents:
        return {"ok": False, "error": "Files can only be written inside the workspace folder"}
    content = str(a.get("content") if a.get("content") is not None else "")
    full.parent.mkdir(parents=True, exist_ok=True)
    full.write_text(content, "utf8")
    from .config import ROOT
    try:
        rel = str(full.relative_to(ROOT))
    except ValueError:
        rel = str(full)
    s.send({"type": "code_start", "id": ctx["id"], "file": rel})
    s.send({"type": "code", "id": ctx["id"], "text": content})
    s.send({"type": "code_end", "id": ctx["id"], "ok": True, "file": str(full)})
    return {"ok": True, "message": f"Wrote {full}", "file": str(full)}


async def run_command(s, a, ctx):
    command = a.get("command")
    if not command:
        return {"ok": False, "error": "No command given"}
    # With auto-authorize on, commands run immediately, except ones that could wreck the machine or need admin rights, which always ask first.
    if not s.auto_approve or DANGEROUS.search(command):
        err = await _confirm(s, command, "The user did not authorize this command")
        if err:
            return err
    r = await plat.shell(command, WORKSPACE, 120)
    output = (r["stdout"] + ("\n" + r["stderr"] if r["stderr"] else "")).strip()
    return {"ok": r["code"] == 0, "exit_code": r["code"], "output": "…" + output[-2000:] if len(output) > 2000 else output}


async def run_applescript(s, a, ctx):
    script = a.get("script")
    if not script:
        return {"ok": False, "error": "No script given"}
    if IS_WIN:
        return {"ok": False, "error": "AppleScript only exists on macOS. On this PC use run_command, which runs PowerShell."}
    if not s.auto_approve or DANGEROUS.search(script):
        err = await _confirm(s, script, "The user did not authorize this script")
        if err:
            return err
    r = await plat.run_applescript(script)
    return {"ok": True, "output": r["stdout"].strip()[:2000] or "done"} if r["code"] == 0 else {"ok": False, "error": r["stderr"].strip()[:600]}


# ───────────────────────── seeing ─────────────────────────
async def look(s, a, ctx):
    frame = await s.request({"type": "request_frame"}, 10)
    if not frame:
        return {"ok": False, "error": "Camera is unavailable"}
    model = s.model if await llm.has_vision(s.model) else CONFIG["vision_model"]
    q = a.get("question") or "Describe what you see."
    r = await llm.chat_once(model, [{"role": "user", "images": [frame],
                                     "content": f"You are the optical sensor of ULTRON, viewing the user's webcam. {q} Answer factually in at most 3 sentences."}], ctx.get("signal"))
    return {"ok": True, "observation": r["text"]} if r["ok"] else r


async def read_screen(s, a, ctx):
    app = a.get("app") or ""
    lk = await ctl.look_marked(app)
    if not lk:
        return await control("ui", app)
    out = {"ok": True, "elements": "\n".join([*lk["ui"].head, *lk["ui"].items[:160]])}
    if lk["image"]:
        out["screenshot"] = lk["image"]
    return out


async def see_screen(s, a, ctx):
    r = await look_at_screen(s, ctx, a.get("question") or "Describe what is on screen. Read important text exactly. Answer in at most 4 sentences.", a.get("app") or "")
    return {"ok": True, "observation": r["text"]} if r["ok"] else r


async def verify(s, a, ctx):
    """Vision verification: did an action achieve its goal? Returns yes/no + reason."""
    goal = a.get("goal")
    if not goal:
        return {"ok": False, "error": "No goal to verify"}
    r = await look_at_screen(s, ctx, f'Looking at this screen, is the following true: "{goal}"? Start your answer with YES or NO, then one short reason.', a.get("app") or "")
    if not r["ok"]:
        return r
    return {"ok": True, "verified": bool(re.match(r"^\s*(yes|true|correct|done)\b", r["text"], re.I)), "observation": r["text"]}


async def view_image(s, a, ctx):
    p = a.get("path")
    full = expand_path(str(p or ""), Path.home())
    if not p or not full.exists():
        return {"ok": False, "error": f"Not found: {full}"}
    # Also turns iPhone HEIC photos into something the vision model can read.
    jpg = TTS_DIR / f"view-{phone.now_ms()}.jpg"
    if IS_WIN:
        await control("image", str(full), str(jpg))
    else:
        await plat.to_jpeg(str(full), str(jpg))
    if not jpg.exists():
        return {"ok": False, "error": f"Couldn't read {full.name} as an image"}
    image = base64.b64encode(jpg.read_bytes()).decode()
    jpg.unlink(missing_ok=True)
    q = a.get("question") or "Describe it. Read important text exactly."
    r = await ask_vision(s, ctx.get("signal"), f"This is an image file ({full.name}). {q} Answer in at most 4 sentences.", image)
    return {"ok": True, "observation": r["text"]} if r["ok"] else r


# ───────────────────────── operating the screen ─────────────────────────
async def click_element(s, a, ctx):
    if a.get("mark") not in (None, ""):
        return await click(s, {"mark": a["mark"]}, ctx)
    if not a.get("name"):
        return {"ok": False, "error": "No element name given"}
    return await control("press", a["name"], a.get("app") or "")


async def click(s, a, ctx):
    mark = a.get("mark")
    if mark not in (None, ""):
        m = ctl.state.marks.get(int(re.sub(r"\D", "", str(mark)) or -1))
        if not m:
            return {"ok": False, "error": f"There's no mark {mark} on the latest screenshot. Use a number from the newest one (they change every time)."}
        r = await control("click", m["x"], m["y"], a.get("button") or "left")
        return {"ok": True, "message": f"Clicked [{mark}] {m['what']}"} if r["ok"] else r
    if not has_xy(a.get("x"), a.get("y")):
        return {"ok": False, "error": "click needs a mark number, or numeric x and y"}
    return await control("click", _coord(a["x"]), _coord(a["y"]), a.get("button") or "left")


async def move_mouse(s, a, ctx):
    if not has_xy(a.get("x"), a.get("y")):
        return {"ok": False, "error": "move_mouse needs numeric x and y"}
    return await control("move", _coord(a["x"]), _coord(a["y"]))


async def drag(s, a, ctx):
    ks = ("from_x", "from_y", "to_x", "to_y")
    if not (has_xy(a.get(ks[0]), a.get(ks[1])) and has_xy(a.get(ks[2]), a.get(ks[3]))):
        return {"ok": False, "error": "drag needs from_x, from_y, to_x, to_y"}
    return await control("drag", *[_coord(a[k]) for k in ks])


async def type_text(s, a, ctx):
    text = a.get("text")
    if not isinstance(text, str) or not text:
        return {"ok": False, "error": "No text given"}
    return await control("type", text, a.get("app") or "")


async def press_keys(s, a, ctx):
    keys = a.get("keys")
    if not keys:
        return {"ok": False, "error": "No keys given"}
    # Accept sequences: "down down down", "tab, tab", "down x10" or times: 10.
    seq = [k for k in re.split(r"[\s,]+", str(keys)) if k]
    rep = re.match(r"^(\S+)\s*[x×*]\s*(\d+)$", str(keys), re.I)
    if rep:
        seq = [rep.group(1)] * int(rep.group(2))
    times = int(num(a.get("times"), 1))
    if times > 1 and len(seq) == 1:
        seq = seq * times
    seq = seq[:40]
    last = None
    for k in seq:
        last = await control("key", k, a.get("app") or "")
        if not last["ok"]:
            return last
    return {"ok": True, "message": f"Pressed {len(seq)} keys ({keys})"} if len(seq) > 1 else last


async def scroll(s, a, ctx):
    return await control("scroll", a.get("direction") or "down", a.get("amount") or 5, a.get("app") or "")


async def window(s, a, ctx):
    op = re.sub(r"\s+", " ", str(a.get("action") or "").lower()).strip()
    app = a.get("app") or ""
    if op == "move":
        return await control("window", "move", _coord(a.get("x")), _coord(a.get("y")), app)
    if op in ("size", "resize"):
        return await control("window", "size", _coord(a.get("width")), _coord(a.get("height")), app)
    ok = ["minimize", "unminimize", "restore", "fullscreen", "maximize", "zoom", "center", "left", "right", "top", "bottom",
          "left half", "right half", "top half", "bottom half"]
    if op not in ok:
        return {"ok": False, "error": f'Unknown window action "{a.get("action")}"'}
    return await control("window", op, app)


async def wake_screen(s, a, ctx):
    if IS_WIN:
        # Windows doesn't let any app type on the lock screen (it's a separate, secure desktop), so this
        # wakes the display and leaves signing in to Windows Hello or the user.
        await control("wake")
        await asyncio.sleep(0.9)
        if await plat.screen_locked():
            return {"ok": True, "message": "The display is awake. It's locked, and Windows only lets you sign in yourself (or with Windows Hello)."}
        return {"ok": True, "message": "The display is awake and unlocked"}
    return await plat.wake_screen(control)


# ───────────────────────── memory, volume, media ─────────────────────────
async def remember(s, a, ctx):
    f = store.remember_fact(a.get("text"))
    return {"ok": True, "message": f"Noted: {f['text']}"} if f else {"ok": False, "error": "Nothing to remember"}


async def forget(s, a, ctx):
    n = store.forget_facts(a.get("query"))
    return {"ok": True, "message": f"Forgotten ({n})"} if n else {"ok": False, "error": "Nothing matched"}


async def set_volume(s, a, ctx):
    v = int(clamp(round(num(a.get("level"))), 0, 100))
    if IS_WIN:
        r = await control("volume", v)
        return {"ok": True, "message": f"Volume set to {v}%"} if r["ok"] else r
    return await plat.set_volume(v)


_MEDIA = {"play": "play", "pause": "play", "playpause": "play", "resume": "play", "next": "next", "skip": "next",
          "previous": "previous", "prev": "previous", "back": "previous", "mute": "mute", "unmute": "mute",
          "volumeup": "volup", "louder": "volup", "volumedown": "voldown", "quieter": "voldown"}


async def media(s, a, ctx):
    key = _MEDIA.get(re.sub(r"[^a-z]", "", str(a.get("action") or "playpause").lower()))
    if not key:
        return {"ok": False, "error": f'Unknown media action "{a.get("action")}"'}
    return await control("media", key, a.get("times") or 1)


async def brightness(s, a, ctx):
    down = bool(re.search(r"down|dim|lower|decrease|less", a.get("direction") or "", re.I))
    return await control("media", "brightdown" if down else "brightup", a.get("steps") or 2)


async def force_quit(s, a, ctx):
    app = app_name(a.get("name"))
    if not app:
        return {"ok": False, "error": "No app named"}
    return await plat.force_quit(app)


# ───────────────────────── system ─────────────────────────
async def system_control(s, a, ctx):
    act = str(a.get("action") or "").lower()
    if re.search(r"wi-?fi.*off|off.*wi-?fi|disable wi", act):
        return await plat.wifi(False)
    if re.search(r"wi-?fi.*on|on.*wi-?fi|enable wi", act):
        return await plat.wifi(True)
    if re.search(r"bluetooth.*off|off.*bluetooth", act):
        return await plat.bluetooth(False)
    if re.search(r"bluetooth.*on|on.*bluetooth", act):
        return await plat.bluetooth(True)
    if re.search(r"sleep.*(display|screen)|(display|screen).*sleep|turn off.*(display|screen)", act):
        return await control("display", "off") if IS_WIN else await plat.sleep_display()
    if re.search(r"sleep( the mac| the pc| the computer)?$", act) or "go to sleep" in act:
        return await plat.sleep_system()
    if IS_WIN and re.search(r"empty.*(trash|recycle)", act):
        return await plat.empty_trash()
    if IS_WIN and re.search(r"do not disturb|focus|dnd", act):
        return {"ok": False, "error": 'Windows has no switch for Focus / Do Not Disturb that apps can flip. Open it with open_url "ms-settings:quiethours".'}
    if IS_WIN:
        return {"ok": False, "error": f'I can toggle Wi-Fi, Bluetooth, display/system sleep and empty the Recycle Bin. For "{a.get("action")}" use run_command (PowerShell).'}
    if re.search(r"empty.*trash", act):
        return await plat.empty_trash()
    if re.search(r"do not disturb|focus|dnd", act):
        return await plat.focus_mode(act)
    return {"ok": False, "error": f'I can toggle Wi-Fi, Bluetooth, display/system sleep, empty trash. For "{a.get("action")}" use run_command or run_applescript.'}


async def dark_mode(s, a, ctx):
    return await plat.dark_mode(a.get("mode"))


async def screenshot(s, a, ctx):
    ext = "jpg" if IS_WIN else "png"
    file = Path.home() / "Desktop" / f"ULTRON Screenshot {_stamp()}.{ext}"
    if IS_WIN:
        await control("shot", str(file), "", "screen")
    else:
        await plat.screenshot_to(str(file))
    if not file.exists():
        return {"ok": False, "error": "Screenshot failed" if IS_WIN else "Screenshot failed — check Screen Recording permission"}
    # Away from the computer, a screenshot is only useful on the phone.
    if s is not None and s.remote:
        await phone.send_to_phone(str(file))
        return {"ok": True, "message": "Screenshot taken and sent to your phone", "file": str(file)}
    return {"ok": True, "message": "Screenshot saved to your Desktop", "file": str(file)}


async def lock_screen(s, a, ctx):
    if IS_WIN:
        return await plat.lock_screen()
    return await plat.lock_screen_keys(control)


async def battery(s=None, a=None, ctx=None):
    b = await plat.battery()
    if not b:
        return {"ok": False, "error": "No battery information available (this PC runs on mains power)" if IS_WIN else "No battery information available"}
    if IS_WIN:
        state = ("charging" if b["charging"] else "charged") if b["plugged"] else "discharging"
        power = "on the charger" if b["plugged"] else "on battery"
        return {"ok": True, "message": f"Battery at {b['percent']} percent, {state}, {power}{_mins_left(b)}"}
    power = "on the charger" if b["plugged"] else "on battery"
    return {"ok": True, "message": f"Battery at {b['percent']} percent, {b.get('state', '')}, {power}{_mins_left(b)}"}


async def system_status(s, a, ctx):
    import psutil
    batt = await battery()
    try:
        free_gb = round(psutil.disk_usage(str(Path.home())).free / 2 ** 30)
    except OSError:
        free_gb = "?"
    up = int(__import__("time").time() - psutil.boot_time())
    ram = round(psutil.virtual_memory().total / 2 ** 30)
    return {"ok": True, "message": f"{batt['message'] + '. ' if batt['ok'] else ''}{free_gb} GB of disk free, {ram} GB RAM, up for {up // 86400} days {(up % 86400) // 3600} hours"}


async def weather(s, a, ctx):
    city = (a or {}).get("city") or ""
    try:
        j = json.loads(await _afetch(f"https://wttr.in/{urllib.parse.quote(city)}?format=j1", {"user-agent": "curl/8"}, 10))
    except Exception:
        return {"ok": False, "error": "Weather service unavailable"}
    c = (j.get("current_condition") or [None])[0]
    today = (j.get("weather") or [{}])[0]
    if not c:
        return {"ok": False, "error": "Weather service unavailable"}
    area = ((j.get("nearest_area") or [{}])[0].get("areaName") or [{}])[0].get("value")
    place = city or area or "your area"
    desc = (c.get("weatherDesc") or [{}])[0].get("value")
    return {"ok": True, "message": f"{place}: {desc}, {c.get('temp_C')}°C, feels like {c.get('FeelsLikeC')}°C. Today {today.get('mintempC')} to {today.get('maxtempC')}°C"}


async def clipboard(s, a, ctx):
    text = a.get("text")
    if isinstance(text, str) and text:
        await plat.set_clipboard(text)
        return {"ok": True, "message": "Copied to the clipboard"}
    v = await plat.get_clipboard()
    return {"ok": True, "message": f"Clipboard says: {v[:300]}" if v else "The clipboard is empty", "clipboard": v[:2000]}


# ───────────────────────── timers, reminders ─────────────────────────
async def set_timer(s, a, ctx):
    ms = (num(a.get("minutes")) * 60 + num(a.get("seconds"))) * 1000
    if ms <= 0:
        return {"ok": False, "error": "Give the timer a duration"}
    label = str(a.get("label") or "")
    sched.add_timer(ms, label)
    return {"ok": True, "message": f"Timer set for {sched.format_duration(ms)}{f' — {label}' if label else ''}"}


async def cancel_timer(s, a, ctx):
    label = a.get("label")
    n = sched.cancel_timers(lambda t: not label or str(label).lower() in t["label"].lower())
    return {"ok": True, "message": f"Cancelled {n} timer{'s' if n > 1 else ''}"} if n else {"ok": False, "error": "No matching timer"}


def _when_text(fire_ms: int, daily) -> str:
    d = datetime.fromtimestamp(fire_ms / 1000)
    return f"{d.strftime('%a %H:%M')}{' daily' if daily else ''}"


async def set_reminder(s, a, ctx):
    fire = store.next_fire(a.get("in_minutes"), a.get("at"), a.get("iso"), a.get("daily"))
    if not fire:
        return {"ok": False, "error": 'When should I remind you? Give a time like "18:30" or minutes from now.'}
    if not a.get("text"):
        return {"ok": False, "error": "What should I remind you about?"}
    store.add_job({"type": "reminder", "text": a["text"], "fire": fire, "daily": bool(a.get("daily"))})
    return {"ok": True, "message": f"Reminder set for {_when_text(fire, a.get('daily'))}"}


async def schedule_task(s, a, ctx):
    fire = store.next_fire(a.get("in_minutes"), a.get("at"), a.get("iso"), a.get("daily"))
    if not fire:
        return {"ok": False, "error": "When should I run it? Give a time or minutes from now."}
    if not a.get("prompt"):
        return {"ok": False, "error": "What task should I run?"}
    store.add_job({"type": "task", "prompt": a["prompt"], "fire": fire, "daily": bool(a.get("daily"))})
    return {"ok": True, "message": f"Task scheduled for {_when_text(fire, a.get('daily'))}"}


async def add_watcher(s, a, ctx):
    if not a.get("url"):
        return {"ok": False, "error": "Which page should I watch?"}
    u = normalize_url(a["url"])
    store.add_job({"type": "watch", "url": u, "keyword": a.get("keyword") or "", "label": a.get("label") or u,
                   "every_minutes": max(2, num(a.get("every_minutes"), 10) or 10), "next": 0})
    return {"ok": True, "message": f"Watching {a.get('label') or u}" + (f' for "{a["keyword"]}"' if a.get("keyword") else " for changes")}


async def cancel_reminder(s, a, ctx):
    q = str(a.get("label") or a.get("query") or "").lower()
    n = store.cancel_jobs(lambda j: not q or q in ("all", "everything") or q in (j.get("text") or j.get("prompt") or j.get("label") or "").lower())
    return {"ok": True, "message": f"Cancelled {n}"} if n else {"ok": False, "error": "No matching reminder, task or watcher"}


async def morning_briefing(s, a, ctx):
    now = datetime.now()
    w, b = await weather(s, {}, ctx), await battery()
    part = "morning" if now.hour < 12 else "afternoon" if now.hour < 18 else "evening"
    parts = [f"Good {part}, {s.title}.", f"{now.strftime('%A')} {now.day} {now.strftime('%B')}.",
             w["message"] + "." if w["ok"] else "", b["message"] + "." if b["ok"] else "",
             f"You've got {len(store.MEM['facts'])} things I'm keeping in mind." if store.MEM["facts"] else ""]
    return {"ok": True, "message": " ".join(p for p in parts if p)}


# ───────────────────────── phone link ─────────────────────────
async def send_to_phone(s, a, ctx):
    return await phone.send_to_phone(a.get("path"), a.get("message"))


async def phone_open(s, a, ctx):
    which = a.get("phone")
    p = phone.phone_target(s, which)
    if not p:
        return {"ok": False, "error": f"{which} isn't connected. Online: {phone.online_phones() or 'none'}" if which else "The phone isn't connected"}
    app = a.get("app")
    target = str(a["url"]).strip() if a.get("url") else PHONE_APPS.get(str(app or "").lower().strip())
    if not target:
        return {"ok": False, "error": f'No link for "{app}". Known apps: {", ".join(PHONE_APPS)}. Pass a url (deep link), or run a Shortcut that opens it.'}
    if re.match(r"^(javascript|data|file|blob):", target, re.I):
        return {"ok": False, "error": "That's not a link I'll open"}
    p.send({"type": "phone_open", "url": target, "label": f"Open {app}" if app else "Open"})
    return {"ok": True, "message": f"Opening {app or target} on the phone"}


async def phone_shortcut(s, a, ctx):
    which = a.get("phone")
    p = phone.phone_target(s, which)
    if not p:
        return {"ok": False, "error": f"{which} isn't connected. Online: {phone.online_phones() or 'none'}" if which else "The phone isn't connected"}
    name = a.get("name")
    if not name:
        return {"ok": False, "error": "Which Shortcut?"}
    url = f"shortcuts://run-shortcut?name={urllib.parse.quote(name)}"
    if a.get("input"):
        url += f"&input=text&text={urllib.parse.quote(str(a['input']))}"
    p.send({"type": "phone_open", "url": url, "label": f"Run {name}", "shortcut": True})
    return {"ok": True, "message": f"Running the {name} Shortcut on the phone"}


async def call_me(s, a, ctx):
    """Rings the iPhone app with the real call screen (CallKit), over Tailscale: no phone network, no cost.
    An awake app rings straight over the link; a locked or closed one is woken by Apple (VoIP push)."""
    reason, which = str(a.get("reason") or ""), a.get("phone")
    apps = phone.iphone_apps()
    app = phone.iphone_named(which) if which else (s if s.native else None) or (apps[-1] if apps else None)
    voip = [d for d in store.DEVICES if d.get("voipToken")]
    device = (app.device if app and app.device and app.device.get("voipToken") else
              phone.device_named(which) if which else (sorted(voip, key=lambda d: -d.get("seen", 0))[0] if voip else None))
    name = phone.phone_name(app) if app else (device or {}).get("name") or which or "iPhone"
    if app:
        app.call_reason = reason
        # The app answers once iOS shows the call screen, or says why iOS refused.
        r = await app.request({"type": "call", "reason": reason}, 5)
        print(f"  ☎ call {name} → {('ringing' if r.get('ok') else r.get('error')) if r else 'no reply (asleep)'}")
        if r:
            return {"ok": True, "message": f"Ringing your {name} now."} if r.get("ok") else {"ok": False, "error": f"Couldn't ring your {name}: {r.get('error')}."}
    if phone.APNS and device and device.get("voipToken"):
        device["pendingCall"] = {"reason": reason, "t": phone.now_ms()}
        p = await phone.voip_push(device["voipToken"], {"reason": reason})
        print(f"  ☎ push {device['name']} → {'sent' if p['ok'] else p['error']}")
        return {"ok": True, "message": f"Ringing your {device['name']} now."} if p["ok"] else {"ok": False, "error": f"Apple couldn't deliver the call to your {device['name']} ({p['error']})."}
    if which and not app and not device:
        known = next((d for d in store.DEVICES if re.sub(r"^iphone", "", phone.squash(d["name"])) == re.sub(r"^iphone", "", phone.squash(which))), None)
        if known:
            return {"ok": False, "error": f"Your {known['name']} is asleep and hasn't registered for calls yet: open the ULTRON app on it once, then I can ring it even when it's locked."}
        return {"ok": False, "error": f"I don't know a phone called {which}. Paired: {', '.join(d['name'] for d in store.DEVICES)}."}
    extra = " and hasn't registered for push calls yet: open ULTRON on it once" if phone.APNS else f" and push calls aren't set up on the {HOST} yet"
    return {"ok": False, "error": f"Your {name} is asleep (locked, or the app is closed){extra}."}


async def list_shortcuts(s, a, ctx):
    # The Mac sees the iPhone's Shortcuts through iCloud.
    if IS_WIN:
        return {"ok": False, "error": "Only a Mac can read the iPhone's Shortcuts list. Ask the user for the exact name."}
    return await plat.list_shortcuts()


async def recall(s, a, ctx):
    query, date = a.get("query"), a.get("date")
    rng = store.day_range(date) if date else None
    if date and not rng:
        return {"ok": False, "error": 'Give the date as today, yesterday, "3 days ago" or YYYY-MM-DD'}
    pool = [e for e in store.LOG if rng[0] <= e["t"] < rng[1]] if rng else store.LOG
    if query:
        hits = sorted((e for _, e in store.search(query, pool, 10)), key=lambda e: e["t"])
    else:
        hits = pool[-30:]
    journal = [j["summary"] for j in store.JOURNAL if j["to"] >= rng[0] and j["from"] < rng[1]] if rng else []
    if not hits and not journal:
        return {"ok": True, "message": f"Nothing found{f' about \"{query}\"' if query else ''}{f' on {date}' if date else ''}."}
    out = {"ok": True, "messages": [store.log_line(e) for e in hits]}
    if journal:
        out["journal"] = journal
    return out


async def pair_phone(s, a, ctx):
    code = phone.start_pairing()["code"]
    return {"ok": True, "message": f"Pairing code {' '.join(code)}, valid for five minutes. It's also on the {HOST} screen under Phone link."}


# ───────────────────────── her own interface ─────────────────────────
async def gui_call(s, op: str, args: dict | None = None, timeout: float = 8) -> dict:
    """Run an operation on this session's ULTRON page and wait for its result."""
    return (await s.request({"type": "gui", "op": op, "args": args or {}}, timeout)) or {"ok": False, "error": "My interface did not respond. Is the ULTRON window open?"}


async def gui_state(s, a, ctx):
    r = await gui_call(s, "state")
    if r.get("ok"):
        g = store.GUI
        r["saved"] = {"theme": (g["theme"] or {}).get("name"), "css": list(g["css"]), "edits": len(g["edits"]), "scripts": list(g["scripts"])}
    return r


async def gui_set(s, a, ctx):
    setting, value = a.get("setting"), a.get("value")
    if not setting:
        return {"ok": False, "error": "Which setting?"}
    key = re.sub(r"[\s-]+", "_", str(setting).lower().strip())
    confirmed = False
    # The model may switch auto-authorize off freely, but only the user can switch it back on.
    if re.match(r"^auto_(approve|authorize)$", key) and re.match(r"^(on|true|yes|1|enabled?)$", str(value).strip(), re.I) and not s.auto_approve:
        confirmed = bool(await s.request({"type": "confirm_request", "command": "Turn on Auto-authorize: shell commands, AppleScript and interface scripts will run without asking."}, 120))
        if not confirmed:
            return {"ok": False, "error": "The user did not authorize turning auto-authorize on"}
    return await gui_call(s, "set", {"setting": key, "value": value, "confirmed": confirmed})


async def gui_theme(s, a, ctx):
    r = await gui_call(s, "theme", a)
    if r.get("ok"):
        store.GUI["theme"] = r.pop("theme", None)
        store.save_gui()
    return r


async def gui_css(s, a, ctx):
    key = slugify(a.get("id")) or "custom"
    remove, css = a.get("remove"), a.get("css")
    if not remove and not css:
        return {"ok": False, "error": "No CSS given"}
    r = await gui_call(s, "css", {"id": key, "css": None if remove else str(css)})
    if r.get("ok"):
        if remove:
            store.GUI["css"].pop(key, None)
        else:
            store.GUI["css"][key] = str(css)
        store.save_gui()
    return r


async def gui_edit(s, a, ctx):
    selector, action, value = a.get("selector"), a.get("action"), a.get("value")
    if not selector or not action:
        return {"ok": False, "error": "gui_edit needs selector and action"}
    # Injected HTML can carry inline script; treat it like gui_js when commands need approval.
    if not s.auto_approve and isinstance(value, str) and re.search(r"<script|\bon\w+\s*=|javascript:", value, re.I):
        err = await _confirm(s, f"Interface HTML on {selector}:\n{value}", "The user did not authorize this HTML")
        if err:
            return err
    edit = {"selector": str(selector), "action": str(action).lower(), "value": value, "name": a.get("name")}
    r = await gui_call(s, "edit", edit)
    if r.get("ok") and r.get("persist") and a.get("persist") is not False:
        store.keep_edit(edit)
    r.pop("persist", None)
    return r


async def gui_js(s, a, ctx):
    code = a.get("code")
    if not code:
        return {"ok": False, "error": "No code given"}
    if not s.auto_approve:
        err = await _confirm(s, f"Interface script:\n{code}", "The user did not authorize this script")
        if err:
            return err
    r = await gui_call(s, "js", {"code": str(code)}, 15)
    if r.get("ok") and a.get("persist"):
        key = slugify(a.get("id")) or f"script-{len(store.GUI['scripts']) + 1}"
        store.GUI["scripts"][key] = str(code)
        store.save_gui()
        r["saved_as"] = key
    return r


async def gui_reset(s, a, ctx):
    w = a.get("what")
    w = w if w in ("theme", "css", "edits", "scripts") else "all"
    store.reset_gui(w)
    return await gui_call(s, "reset", {"what": w})


_HELPERS = {"gui_call", "ask_vision", "look_at_screen"}
TOOLS = {n: f for n, f in list(globals().items())
         if asyncio.iscoroutinefunction(f) and f.__module__ == __name__ and not n.startswith("_") and n not in _HELPERS}
