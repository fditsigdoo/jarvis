"""Timers, reminders, recurring tasks and URL watchers.

Timers live in memory (they survive a page reload, not a restart). Reminders, tasks and watchers are
saved in memory/schedule.json: a reminder speaks a line, a task runs a prompt through ULTRON, and a
watcher polls a page and speaks when it changes.
"""
from __future__ import annotations

import asyncio
import re
import urllib.request

from . import osplat as plat
from . import store
from .config import IS_WIN, now_ms


class Hooks:
    """Filled in by agent.py at startup, so this module doesn't import the agent (which imports tools, which import this)."""
    notice = None     # (session, text, kind) -> None
    run_turn = None   # async (session, text) -> None
    last_session = None   # the most recently active UI, used to speak/act when a job fires


hooks = Hooks()

# ───────────────────────── timers ─────────────────────────
timers: list = []
_timer_seq = 0


def format_duration(ms: float) -> str:
    t = round(ms / 1000)
    h, m, sec = t // 3600, (t % 3600) // 60, t % 60
    parts = []
    for n, unit in ((h, "hour"), (m, "minute"), (sec, "second")):
        if n:
            parts.append(f"{n} {unit}{'s' if n > 1 else ''}")
    return " ".join(parts) or "0 seconds"


def broadcast_timers():
    lst = [{"id": t["id"], "label": t["label"], "end": t["end"], "ms": t["ms"]} for t in timers]
    for c in list(store.clients):
        c.send({"type": "timers", "list": lst})


def add_timer(ms: float, label: str) -> dict:
    global _timer_seq
    _timer_seq += 1
    t = {"id": _timer_seq, "label": label, "ms": ms, "end": now_ms() + int(ms)}

    def fire():
        cancel_timers(lambda x: x is t)
        text = f"Time's up{f' for {label}' if label else ''}. Your {format_duration(ms)} timer is done."
        asyncio.ensure_future(plat.notify("ULTRON", text, True) if not IS_WIN else plat.notify("ULTRON", text))
        for c in list(store.clients):
            if hooks.notice:
                hooks.notice(c, text, "timer")
    t["handle"] = asyncio.get_running_loop().call_later(ms / 1000, fire)
    timers.append(t)
    broadcast_timers()
    return t


def cancel_timers(match) -> int:
    n = 0
    for i in range(len(timers) - 1, -1, -1):
        if match(timers[i]):
            timers[i]["handle"].cancel()
            del timers[i]
            n += 1
    if n:
        broadcast_timers()
    return n


# ───────────────────────── reminders, tasks, watchers ─────────────────────────
async def _fetch_text(url: str) -> str:
    def go():
        req = urllib.request.Request(url, headers={"user-agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=15) as r:
            return r.read().decode("utf8", "replace")
    return await asyncio.get_running_loop().run_in_executor(None, go)


async def check_watcher(job: dict):
    try:
        html = await _fetch_text(job["url"])
        text = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", html))
        kw = job.get("keyword")
        if kw:
            present = kw.lower() in text.lower()
            if present and not job.get("lastValue"):
                job["lastValue"] = "seen"
                store.save_jobs()
                return f'"{kw}" appeared.'
            if not present:
                job["lastValue"] = ""
            return None
        # No keyword: notify on any substantial change.
        sig = str(len(text))
        if job.get("lastValue") and job["lastValue"] != sig:
            job["lastValue"] = sig
            store.save_jobs()
            return "the page changed."
        job["lastValue"] = sig
        store.save_jobs()
        return None
    except Exception:
        return None


def _session_ready() -> bool:
    s = hooks.last_session
    return bool(s and s.is_open())


async def fire_job(job: dict):
    async def say(text: str):
        await plat.notify("ULTRON", text)
        if _session_ready() and hooks.notice:
            hooks.notice(hooks.last_session, text, "reminder")
    try:
        if job["type"] == "reminder":
            await say(f"Reminder: {job['text']}")
        elif job["type"] == "task":
            if _session_ready() and hooks.run_turn:
                asyncio.ensure_future(hooks.run_turn(hooks.last_session, job["prompt"]))
            else:
                await say(f"I had a task scheduled ({job['prompt']}) but no window was open.")
        elif job["type"] == "watch":
            changed = await check_watcher(job)
            if changed:
                await say(f"Heads up: {job.get('label') or job['url']} {changed}")
    except Exception:
        pass


async def job_loop():
    while True:
        await asyncio.sleep(15)
        now = now_ms()
        changed = False
        for job in list(store.JOBS):
            if job["type"] == "watch":
                if now >= (job.get("next") or 0):
                    job["next"] = now + int((job.get("every_minutes") or 5) * 60000)
                    changed = True
                    asyncio.ensure_future(fire_job(job))
                continue
            if now >= job["fire"]:
                asyncio.ensure_future(fire_job(job))
                if job.get("daily"):
                    job["fire"] += 86400000
                else:
                    store.JOBS.remove(job)
                changed = True
        if changed:
            store.save_jobs()
