"""Running other programs without blocking the event loop."""
from __future__ import annotations

import asyncio
import os
import subprocess
import sys

CREATE_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0


def _flags() -> dict:
    return {"creationflags": CREATE_NO_WINDOW} if sys.platform == "win32" else {}


async def run(cmd: str, args: list | None = None, cwd=None, timeout: float = 30, input: str | None = None, env: dict | None = None) -> dict:
    """Runs a program to completion. Resolves {code, stdout, stderr}; never raises."""
    try:
        p = await asyncio.create_subprocess_exec(
            cmd, *[str(a) for a in (args or [])], cwd=str(cwd) if cwd else None, env=env,
            stdin=asyncio.subprocess.PIPE if input is not None else asyncio.subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE, **_flags())
    except (OSError, ValueError) as e:
        return {"code": 1, "stdout": "", "stderr": str(e)}
    try:
        out, err = await asyncio.wait_for(p.communicate(input.encode("utf8") if input is not None else None), timeout)
    except asyncio.TimeoutError:
        try:
            p.kill()
        except ProcessLookupError:
            pass
        await p.wait()
        return {"code": 1, "stdout": "", "stderr": f"Timed out after {int(timeout)}s"}
    return {"code": p.returncode or 0, "stdout": out.decode("utf8", "replace"), "stderr": err.decode("utf8", "replace")}


def spawn_quiet(cmd: str, args: list | None = None, **kw) -> subprocess.Popen | None:
    """Starts a background program with no window. Returns None if it can't start."""
    try:
        return subprocess.Popen([cmd, *[str(a) for a in (args or [])]], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                stderr=subprocess.DEVNULL, **_flags(), **kw)
    except OSError:
        return None


def which(name: str) -> str | None:
    import shutil
    return shutil.which(name)


def env_with(**extra) -> dict:
    e = dict(os.environ)
    e.update({k: str(v) for k, v in extra.items()})
    return e
