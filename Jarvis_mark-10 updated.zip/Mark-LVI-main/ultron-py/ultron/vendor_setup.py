"""Fetches the browser-side libraries the UI loads from /vendor/ (three.js, xterm.js).

These used to come from npm. Python doesn't need Node, so this downloads the same tarballs
straight from the npm registry, checks their sha512 against the pinned values, and unpacks only
the folders the UI uses into ./vendor, the same layout node_modules had.
"""
from __future__ import annotations

import base64
import hashlib
import io
import tarfile
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
VENDOR = ROOT / "vendor"

PACKAGES = {
    "@xterm/addon-fit": (
        "https://registry.npmjs.org/@xterm/addon-fit/-/addon-fit-0.11.0.tgz",
        "sha512-jYcgT6xtVYhnhgxh3QgYDnnNMYTcf8ElbxxFzX0IZo+vabQqSPAjC3c1wJrKB5E19VwQei89QCiZZP86DCPF7g==",
    ),
    "@xterm/xterm": (
        "https://registry.npmjs.org/@xterm/xterm/-/xterm-6.0.0.tgz",
        "sha512-TQwDdQGtwwDt+2cgKDLn0IRaSxYu1tSUjgKarSDkUM0ZNiSRXFpjxEsvc/Zgc5kq5omJ+V0a8/kIM2WD3sMOYg==",
    ),
    "three": (
        "https://registry.npmjs.org/three/-/three-0.186.1.tgz",
        "sha512-blFeqb49wRCSGUGj7gtpfnSGHy2lwDk94RhUmS1c/hTby70kvChbWpkJ4Pm1390LqzzvTmzgXKHPEafJwCb8jA==",
    ),
}

# Only what the UI actually loads.
KEEP = {
    "three": ("build/", "examples/jsm/"),
    "@xterm/xterm": ("lib/", "css/"),
    "@xterm/addon-fit": ("lib/",),
}


def _fetch(url: str) -> bytes:
    req = urllib.request.Request(url, headers={"user-agent": "ultron-vendor/1.0"})
    with urllib.request.urlopen(req, timeout=120) as r:
        return r.read()


def _verify(data: bytes, integrity: str) -> None:
    algo, _, want = integrity.partition("-")
    got = base64.b64encode(hashlib.new(algo, data).digest()).decode()
    if got != want:
        raise RuntimeError("checksum mismatch, refusing to unpack")


def ensure(quiet: bool = False) -> bool:
    """Downloads whatever is missing. Returns False if something couldn't be fetched."""
    ok = True
    for name, (url, integrity) in PACKAGES.items():
        dest = VENDOR / name
        if (dest / ".ok").exists():
            continue
        if not quiet:
            print(f"  fetching {name}...")
        try:
            data = _fetch(url)
            _verify(data, integrity)
            with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tar:
                for m in tar.getmembers():
                    rel = m.name.split("/", 1)[1] if "/" in m.name else ""
                    if not m.isfile() or not rel.startswith(KEEP[name]):
                        continue
                    target = (dest / rel).resolve()
                    if dest.resolve() not in target.parents:
                        continue  # path traversal guard
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(tar.extractfile(m).read())
            (dest / ".ok").write_text("ok")
        except Exception as e:  # offline, registry down, bad checksum...
            print(f"  could not set up {name}: {e}")
            ok = False
    return ok


if __name__ == "__main__":
    raise SystemExit(0 if ensure() else 1)
