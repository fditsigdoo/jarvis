"""Windows: what the Mac side does with osascript, open, pmset and pbcopy, done with PowerShell
and the Windows APIs. Windows PowerShell 5.1 ships with every Windows 10/11 install, so that is
what runs the scripts; anything simple enough is plain Python instead (no PowerShell start-up).
"""
from __future__ import annotations

import asyncio
import base64
import ctypes
import os
import re
import sys
import tempfile
import zipfile
from pathlib import Path

from .config import app_name as _generic_app_name
from .proc import run, spawn_quiet

PRELUDE = ("$ErrorActionPreference = 'Stop'\n$ProgressPreference = 'SilentlyContinue'\n"
           "try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}\n")


def psq(s) -> str:
    """A PowerShell single-quoted string literal."""
    return "'" + str("" if s is None else s).replace("'", "''") + "'"


def _clean_err(text: str) -> str:
    """PowerShell 5.1 reports errors as CLIXML when its output is piped. Turn that back into text."""
    text = text or ""
    if not text.startswith("#< CLIXML"):
        return text.strip()
    parts = re.findall(r'<S S="Error">([\s\S]*?)</S>', text)
    t = "".join(parts).replace("_x000D_", "").replace("_x000A_", "\n")
    for a, b in (("&lt;", "<"), ("&gt;", ">"), ("&quot;", '"'), ("&#39;", "'"), ("&amp;", "&")):
        t = t.replace(a, b)
    return "\n".join(l for l in t.split("\n") if l.strip() and not re.match(r"^\s*(At line:|\+|CategoryInfo|FullyQualifiedErrorId)", l)).strip()


async def ps(script: str, timeout: float = 30, cwd=None) -> dict:
    """Runs a PowerShell script. Resolves {code, stdout, stderr}, never raises."""
    encoded = base64.b64encode((PRELUDE + script).encode("utf-16-le")).decode()
    r = await run("powershell.exe", ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", encoded],
                  cwd=cwd, timeout=timeout)
    return {"code": r["code"], "stdout": r["stdout"], "stderr": _clean_err(r["stderr"])}


async def shell(command: str, cwd=None, timeout: float = 120) -> dict:
    """A shell command typed by the user or the model: runs as PowerShell."""
    r = await run("powershell.exe", ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command",
                                     f"try {{ [Console]::OutputEncoding = [Text.Encoding]::UTF8 }} catch {{}}; {command}"],
                  cwd=cwd, timeout=timeout)
    return {"code": r["code"], "stdout": r["stdout"], "stderr": _clean_err(r["stderr"])}


def _result(r: dict, message: str) -> dict:
    return {"ok": True, "message": r["stdout"].strip() or message} if r["code"] == 0 else {"ok": False, "error": r["stderr"] or "Failed"}


# Mac app names people (and the model) still use, mapped to what Windows calls them.
WIN_APPS = {
    "system settings": "Settings", "system preferences": "Settings", "finder": "File Explorer", "explorer": "File Explorer",
    "safari": "Microsoft Edge", "edge": "Microsoft Edge", "terminal": "Terminal", "textedit": "Notepad", "notes": "Notepad",
    "activity monitor": "Task Manager", "calculator": "Calculator", "music": "Spotify", "mail": "Outlook",
}


def win_app(name) -> str:
    n = str(name or "").strip()
    return WIN_APPS.get(n.lower(), n)


async def open_app(name) -> dict:
    """Opens an app by the name it has in the Start menu (desktop and Store apps alike)."""
    n = win_app(name)
    if n == "Task Manager":
        return _result(await ps("Start-Process taskmgr; 'Opened Task Manager'"), "Opened Task Manager")
    script = """
$n = @@N@@
$apps = @(Get-StartApps)
$app = $apps | Where-Object { $_.Name -eq $n } | Select-Object -First 1
if (-not $app) { $app = $apps | Where-Object { $_.Name -like "*$n*" } | Sort-Object { $_.Name.Length } | Select-Object -First 1 }
if ($app) { Start-Process ("shell:AppsFolder\\" + $app.AppID); "Opened " + $app.Name; exit 0 }
try { Start-Process $n; "Opened $n" } catch { throw "There's no app called $n on this PC" }
""".replace("@@N@@", psq(n))
    return _result(await ps(script), f"Opened {n}")


# Processes with a window that match an app name: by process name, window title or description.
# (Reading a protected process's details throws, so errors are ignored while matching.)
def _match_procs(n: str) -> str:
    return """
$n = @@N@@
$q = ($n -replace '[^a-zA-Z0-9]', '').ToLower()
$ErrorActionPreference = 'SilentlyContinue'
$procs = @(Get-Process | Where-Object {
  $_.MainWindowHandle -ne 0 -and $_.MainWindowTitle -notlike '*ULTRON*' -and (
    $_.ProcessName -like "*$n*" -or $_.MainWindowTitle -like "*$n*" -or $_.Description -like "*$n*" -or
    ($q.Length -ge 4 -and $q.Contains($_.ProcessName.ToLower())))
})
$ErrorActionPreference = 'Stop'
""".replace("@@N@@", psq(n))


async def close_app(name) -> dict:
    n = win_app(name).replace('"', "")
    s = _match_procs(n) + """
if (-not $procs.Count) { throw "$n isn't open" }
foreach ($p in $procs) { [void]$p.CloseMainWindow() }
"Closed $n"
"""
    return _result(await ps(s), f"Closed {n}")


async def force_quit(name) -> dict:
    n = win_app(name)
    s = _match_procs(n) + """
$names = @($procs | ForEach-Object { $_.ProcessName } | Sort-Object -Unique)
if (-not $names.Count) { $names = @(Get-Process -Name $n -ErrorAction SilentlyContinue | ForEach-Object { $_.ProcessName } | Sort-Object -Unique) }
if (-not $names.Count) { throw "Couldn't find $n running" }
foreach ($x in $names) { Stop-Process -Name $x -Force }
"Force quit $n"
"""
    return _result(await ps(s), f"Force quit {n}")


def _walk_find(query: str, kind: str | None) -> list:
    q = query.lower()
    root = Path.home()
    hits: list = []
    base_depth = len(root.parts)
    for dirpath, dirs, files in os.walk(root):
        depth = len(Path(dirpath).parts) - base_depth
        dirs[:] = [d for d in dirs if d != "AppData" and d != "node_modules" and not d.startswith(".")] if depth < 7 else []
        names = list(dirs) if kind == "folder" else list(dirs) + [f for f in files if not f.startswith(".")]
        for n in names:
            if q in n.lower():
                hits.append(os.path.join(dirpath, n))
                if len(hits) >= 40:
                    return hits
    return hits


async def find_files(query: str, kind: str | None = None) -> list:
    return await asyncio.get_running_loop().run_in_executor(None, _walk_find, query, kind)


async def open_path(target, app: str = "") -> dict:
    """Opens a file, folder or URL with its default app, or with the app named."""
    target = str(target)
    if app:
        a = win_app(app)
        if re.match(r"^(visual studio code|vs ?code|code)$", a, re.I):
            return await open_vscode(target)
        s = """
$a = @@A@@
$exe = @{ 'google chrome' = 'chrome'; 'chrome' = 'chrome'; 'microsoft edge' = 'msedge'; 'firefox' = 'firefox'; 'brave' = 'brave'; 'notepad' = 'notepad' }[$a.ToLower()]
if (-not $exe) { $exe = $a }
Start-Process -FilePath $exe -ArgumentList ('"' + @@T@@ + '"')
"Opened in $a"
""".replace("@@A@@", psq(a)).replace("@@T@@", psq(target))
        return _result(await ps(s), f"Opened {target}")
    if re.match(r"^https?://", target, re.I) or not os.path.exists(target):
        return _result(await ps(f"Start-Process {psq(target)}; 'Opened'"), f"Opened {target}")
    try:
        os.startfile(target)   # type: ignore[attr-defined]  (Windows only; same as double-clicking it)
        return {"ok": True, "message": f"Opened {target}"}
    except (OSError, AttributeError):
        return _result(await ps(f"Invoke-Item -LiteralPath {psq(target)}; 'Opened'"), f"Opened {target}")


async def open_url(url: str, browser: str = "") -> dict:
    if browser:
        return await open_path(url, browser)
    return _result(await ps(f"Start-Process {psq(url)}; 'Opened'"), f"Opened {url}")


async def open_in_browser(url: str, browser: str = "") -> dict:
    """Opens a normal browser window; the ULTRON app window never takes regular tabs."""
    r = await open_url(url, browser)
    if not r["ok"]:
        return r
    await asyncio.sleep(1.2)
    return {"ok": True, "message": f"Opened {url}" + (f" in {browser}" if browser else "")}


async def open_vscode(target: str = "") -> dict:
    arg = f" -ArgumentList ('\"' + {psq(target)} + '\"')" if target else ""
    s = """
$code = (Get-Command code.cmd -ErrorAction SilentlyContinue).Source
if (-not $code) { $code = Join-Path $env:LOCALAPPDATA 'Programs\\Microsoft VS Code\\Code.exe' }
if (-not (Test-Path $code)) { throw 'Visual Studio Code is not installed' }
Start-Process -FilePath $code -WindowStyle Hidden@@ARG@@
'Opened VS Code'
""".replace("@@ARG@@", arg)
    return _result(await ps(s), "Opened VS Code")


async def notify(title: str, text: str, sound: bool = False):
    s = """
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null
$xml = [Windows.UI.Notifications.ToastNotificationManager]::GetTemplateContent([Windows.UI.Notifications.ToastTemplateType]::ToastText02)
$t = $xml.GetElementsByTagName('text')
[void]$t.Item(0).AppendChild($xml.CreateTextNode(@@TITLE@@))
[void]$t.Item(1).AppendChild($xml.CreateTextNode(@@TEXT@@))
$app = '{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\\WindowsPowerShell\\v1.0\\powershell.exe'
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($app).Show([Windows.UI.Notifications.ToastNotification]::new($xml))
""".replace("@@TITLE@@", psq(title)).replace("@@TEXT@@", psq(text))
    return await ps(s)


def _dark_mode_sync(mode) -> dict:
    import winreg
    m = str(mode or "toggle").lower()
    key = r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key, 0, winreg.KEY_READ | winreg.KEY_SET_VALUE) as k:
            try:
                light = winreg.QueryValueEx(k, "AppsUseLightTheme")[0]
            except OSError:
                light = 1
            v = 0 if re.match(r"^(on|dark|true)$", m) else 1 if re.match(r"^(off|light|false)$", m) else 1 - int(light)
            winreg.SetValueEx(k, "AppsUseLightTheme", 0, winreg.REG_DWORD, v)
            winreg.SetValueEx(k, "SystemUsesLightTheme", 0, winreg.REG_DWORD, v)
        return {"ok": True, "message": "Dark mode is on" if v == 0 else "Dark mode is off"}
    except OSError as e:
        return {"ok": False, "error": str(e)}


async def dark_mode(mode) -> dict:
    return await asyncio.get_running_loop().run_in_executor(None, _dark_mode_sync, mode)


async def radio(kind: str, on: bool) -> dict:
    """Turns the Wi-Fi or Bluetooth radio on or off (no admin rights needed)."""
    label = "Wi-Fi" if kind == "WiFi" else "Bluetooth"
    s = """
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
  $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Await($op, $type) { $asTask.MakeGenericMethod($type).Invoke($null, @($op)).GetAwaiter().GetResult() }
[Windows.Devices.Radios.Radio, Windows.System.Devices, ContentType = WindowsRuntime] | Out-Null
[Windows.Devices.Radios.RadioAccessStatus, Windows.System.Devices, ContentType = WindowsRuntime] | Out-Null
[Windows.Devices.Radios.RadioState, Windows.System.Devices, ContentType = WindowsRuntime] | Out-Null
[void](Await ([Windows.Devices.Radios.Radio]::RequestAccessAsync()) ([Windows.Devices.Radios.RadioAccessStatus]))
$radios = Await ([Windows.Devices.Radios.Radio]::GetRadiosAsync()) ([System.Collections.Generic.IReadOnlyList[Windows.Devices.Radios.Radio]])
$r = $radios | Where-Object { $_.Kind -eq @@KIND@@ } | Select-Object -First 1
if (-not $r) { throw 'This PC has no @@LABEL@@ radio' }
$s = Await ($r.SetStateAsync(@@STATE@@)) ([Windows.Devices.Radios.RadioAccessStatus])
if ("$s" -ne 'Allowed') { throw "Windows refused ($s)" }
'@@LABEL@@ @@WORD@@'
""".replace("@@KIND@@", psq(kind)).replace("@@LABEL@@", label).replace("@@STATE@@", "'On'" if on else "'Off'").replace("@@WORD@@", "on" if on else "off")
    return _result(await ps(s), "Done")


async def wifi(on: bool) -> dict:
    return await radio("WiFi", on)


async def bluetooth(on: bool) -> dict:
    return await radio("Bluetooth", on)


async def sleep_system() -> dict:
    s = "Add-Type -AssemblyName System.Windows.Forms\n[void][System.Windows.Forms.Application]::SetSuspendState('Suspend', $false, $false)\n'Sleeping'"
    return _result(await ps(s), "Sleeping")


async def empty_trash() -> dict:
    return _result(await ps("Clear-RecycleBin -Force -ErrorAction SilentlyContinue; 'Recycle Bin emptied'"), "Recycle Bin emptied")


async def lock_screen() -> dict:
    try:
        ctypes.windll.user32.LockWorkStation()   # type: ignore[attr-defined]
        return {"ok": True, "message": "Screen locked"}
    except (OSError, AttributeError):
        return _result(await ps("rundll32.exe user32.dll,LockWorkStation; 'Screen locked'"), "Screen locked")


async def screen_locked() -> bool:
    """True while the lock screen (LogonUI) is up."""
    try:
        import psutil
        return any((p.info["name"] or "").lower() == "logonui.exe" for p in psutil.process_iter(["name"]))
    except Exception:
        r = await ps("if (Get-Process LogonUI -ErrorAction SilentlyContinue) { 'yes' } else { 'no' }")
        return r["stdout"].strip() == "yes"


async def battery() -> dict | None:
    """{percent, charging, plugged, minutes_left} for laptops, None on desktops."""
    try:
        import psutil
        b = psutil.sensors_battery()
    except Exception:
        b = None
    if b is None:
        return None
    left = b.secsleft // 60 if not b.power_plugged and isinstance(b.secsleft, int) and b.secsleft > 0 else None
    return {"percent": round(b.percent), "charging": bool(b.power_plugged) and b.percent < 100, "plugged": bool(b.power_plugged), "minutes_left": left}


async def set_clipboard(text: str) -> bool:
    fd, tmp = tempfile.mkstemp(prefix="ultron-clip-", suffix=".txt")
    try:
        with os.fdopen(fd, "w", encoding="utf8") as f:
            f.write(text)
        r = await ps(f"Get-Content -LiteralPath {psq(tmp)} -Raw -Encoding UTF8 | Set-Clipboard")
        return r["code"] == 0
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass


async def get_clipboard() -> str:
    return (await ps("Get-Clipboard -Raw"))["stdout"].replace("\r\n", "\n").strip()


def _zip_sync(folder: str, dest: str):
    root = Path(folder)
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        for p in root.rglob("*"):
            z.write(p, Path(root.name) / p.relative_to(root))


async def zip_folder(folder: str, dest: str) -> dict:
    try:
        await asyncio.get_running_loop().run_in_executor(None, _zip_sync, folder, dest)
        return {"code": 0, "stderr": ""}
    except OSError as e:
        return {"code": 1, "stderr": str(e)}


async def shell_here(command: str, cwd, timeout: float = 120) -> dict:
    return await shell(command, cwd, timeout)


# Mac-style shortcuts (the model and the UI both think in cmd+...) to what Windows uses.
COMBOS = {
    "ctrl+cmd+f": "f11", "cmd+ctrl+f": "f11", "cmd+[": "alt+left", "cmd+]": "alt+right",
    "cmd+up": "ctrl+home", "cmd+down": "ctrl+end", "cmd+left": "home", "cmd+right": "end",
    "cmd+shift+z": "ctrl+y", "cmd+space": "win+s", "cmd+q": "alt+f4", "cmd+h": "win+down",
    "cmd+m": "win+down", "cmd+backspace": "shift+delete", "cmd+,": "ctrl+,", "ctrl+cmd+q": "win+l",
}


def win_combo(combo) -> str:
    c = re.sub(r"\s+", "", str(combo or "").lower())
    c = re.sub(r"command|⌘", "cmd", c)
    c = re.sub(r"option|opt|⌥", "alt", c)
    return COMBOS.get(c) or re.sub(r"\bcmd\b", "ctrl", c)


def keep_awake_process(control_exe) -> "object | None":
    return spawn_quiet(str(control_exe), ["awake"])
