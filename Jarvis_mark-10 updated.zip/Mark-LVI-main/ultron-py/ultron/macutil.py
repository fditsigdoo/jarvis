"""macOS: the same interface as winutil, done with osascript, open, pmset, pbcopy and friends.
(Also what runs on Linux while developing: whatever isn't there simply reports a failure.)"""
from __future__ import annotations

import asyncio
import os
import re
import tempfile
from pathlib import Path

from .config import app_name
from .proc import run, spawn_quiet


def _ok(r: dict, message: str) -> dict:
    return {"ok": True, "message": message} if r["code"] == 0 else {"ok": False, "error": r["stderr"].strip() or "Failed"}


async def shell(command: str, cwd=None, timeout: float = 120) -> dict:
    return await run("/bin/zsh" if os.path.exists("/bin/zsh") else "/bin/sh", ["-c", command], cwd=cwd, timeout=timeout)


async def open_app(name) -> dict:
    app = app_name(name)
    r = await run("open", ["-a", app])
    if r["code"] != 0:
        return {"ok": False, "error": f'Could not open "{app}": {r["stderr"].strip()}'}
    await asyncio.sleep(1.2)   # let the window appear
    return {"ok": True, "message": f"Opened {app}"}


async def close_app(name) -> dict:
    app = app_name(name).replace('"', "")
    r = await run("osascript", ["-e", f'quit app "{app}"'])
    return {"ok": True, "message": f"Closed {app}"} if r["code"] == 0 else {"ok": False, "error": r["stderr"].strip()}


async def force_quit(name) -> dict:
    app = app_name(name)
    if (await run("killall", [app]))["code"] == 0 or (await run("pkill", ["-f", app]))["code"] == 0:
        return {"ok": True, "message": f"Force quit {app}"}
    return {"ok": False, "error": f"Couldn't force quit {app}"}


async def find_files(query: str, kind: str | None = None) -> list:
    q = (f'kMDItemFSName == "*{query}*"c && kMDItemContentType == public.folder' if kind == "folder"
         else f'kMDItemFSName == "*{query}*"c')
    home = str(Path.home())
    r = await run("mdfind", ["-onlyin", home, q], timeout=15)
    return [l for l in r["stdout"].split("\n") if l and not re.search(r"/(Library|node_modules|\.)", l.replace(home, ""))]


async def open_path(target, app: str = "") -> dict:
    r = await run("open", ["-a", app_name(app), str(target)] if app else [str(target)])
    return {"ok": True, "message": f"Opened {target}"} if r["code"] == 0 else {"ok": False, "error": r["stderr"].strip()}


async def open_vscode(target: str = "") -> dict:
    r = await run("open", ["-a", "Visual Studio Code", *([target] if target else [])])
    return {"ok": True, "message": "Opened VS Code" + (f" at {target}" if target else "")} if r["code"] == 0 else {"ok": False, "error": r["stderr"].strip()}


async def open_in_browser(url: str, browser: str = "") -> dict:
    """Opens a URL without ever navigating away from the ULTRON tab: in Chrome it uses (or creates)
    a regular window that isn't showing ULTRON."""
    b = app_name(browser) if browser else ""
    chrome_running = (await run("pgrep", ["-x", "Google Chrome"]))["code"] == 0
    if re.search("chrome", b, re.I) or (not b and chrome_running):
        u = url.replace("\\", "\\\\").replace('"', '\\"')
        script = """tell application "Google Chrome"
  set target to missing value
  repeat with w in windows
    set t to title of active tab of w
    if mode of w is "normal" and t does not contain "ULTRON" then
      set target to w
      exit repeat
    end if
  end repeat
  if target is missing value then
    set target to make new window
    set URL of active tab of target to "@@U@@"
  else
    tell target to make new tab with properties {URL:"@@U@@"}
  end if
  set index of target to 1
  activate
end tell""".replace("@@U@@", u)
        if (await run("osascript", ["-e", script]))["code"] == 0:
            await asyncio.sleep(1.2)
            return {"ok": True, "message": f"Opened {url} in Google Chrome"}
    r = await run("open", ["-a", b, url] if b else [url])
    if r["code"] != 0:
        return {"ok": False, "error": r["stderr"].strip()}
    await asyncio.sleep(1.2)
    return {"ok": True, "message": f"Opened {url}" + (f" in {b}" if b else "")}


async def notify(title: str, text: str, sound: bool = False):
    t = text.replace('"', "'")
    s = f'display notification "{t}" with title "{title}"' + (' sound name "Glass"' if sound else "")
    return await run("osascript", ["-e", s])


async def dark_mode(mode) -> dict:
    m = str(mode or "toggle").lower()
    value = "true" if re.match(r"^(on|dark|true)$", m) else "false" if re.match(r"^(off|light|false)$", m) else "not dark mode"
    prefs = 'tell application "System Events" to tell appearance preferences to'
    r = await run("osascript", ["-e", f"{prefs} set dark mode to {value}"])
    if r["code"] != 0:
        return {"ok": False, "error": r["stderr"].strip()}
    now = (await run("osascript", ["-e", f"{prefs} get dark mode"]))["stdout"].strip() == "true"
    return {"ok": True, "message": f"Dark mode is {'on' if now else 'off'}"}


async def wifi(on: bool) -> dict:
    out = (await run("networksetup", ["-listallhardwareports"]))["stdout"]
    m = re.search(r"Wi-Fi\n\s*Device:\s*(\w+)", out)
    r = await run("networksetup", ["-setairportpower", m.group(1) if m else "en0", "on" if on else "off"])
    return {"ok": True, "message": f"Wi-Fi {'on' if on else 'off'}"} if r["code"] == 0 else {"ok": False, "error": r["stderr"].strip() or "Failed"}


async def bluetooth(on: bool) -> dict:
    if (await run("which", ["blueutil"]))["code"] == 0:
        r = await run("blueutil", ["--power", "1" if on else "0"])
        return {"ok": True, "message": f"Bluetooth {'on' if on else 'off'}"} if r["code"] == 0 else {"ok": False, "error": r["stderr"].strip()}
    return {"ok": False, "error": "Bluetooth toggle needs blueutil (brew install blueutil)"}


async def sleep_system() -> dict:
    await run("pmset", ["sleepnow"])
    return {"ok": True, "message": "Sleeping"}


async def sleep_display() -> dict:
    await run("pmset", ["displaysleepnow"])
    return {"ok": True, "message": "Display asleep"}


async def empty_trash() -> dict:
    r = await run("osascript", ["-e", 'tell application "Finder" to empty trash'])
    return {"ok": True, "message": "Trash emptied"} if r["code"] == 0 else {"ok": False, "error": r["stderr"].strip()}


async def focus_mode(action: str) -> dict:
    on = not re.search(r"off|disable|stop", action)
    r = await run("shortcuts", ["run", "Turn On Do Not Disturb" if on else "Turn Off Do Not Disturb"])
    return ({"ok": True, "message": f"Do Not Disturb {'on' if on else 'off'}"} if r["code"] == 0 else
            {"ok": False, "error": 'Needs a Shortcut named "Turn On/Off Do Not Disturb" (macOS blocks direct Focus control)'})


async def screen_locked() -> bool:
    r = await run("ioreg", ["-n", "Root", "-d1"])
    return bool(re.search(r'CGSSessionScreenIsLocked"\s*=\s*Yes', r["stdout"]))


async def battery() -> dict | None:
    r = await run("pmset", ["-g", "batt"])
    m = re.search(r"(\d+)%;\s*([^;]+);\s*([^\n]*)", r["stdout"])
    if not m:
        return None
    plugged = "AC Power" in r["stdout"]
    left = re.search(r"(\d+):(\d+) remaining", m.group(3))
    mins = int(left.group(1)) * 60 + int(left.group(2)) if left else None
    return {"percent": int(m.group(1)), "charging": plugged and not re.search("discharging", m.group(2), re.I), "plugged": plugged,
            "minutes_left": mins if mins else None, "state": m.group(2).strip()}


async def set_clipboard(text: str) -> bool:
    return (await run("pbcopy", [], input=text))["code"] == 0


async def get_clipboard() -> str:
    return (await run("pbpaste", []))["stdout"].strip()


async def zip_folder(folder: str, dest: str) -> dict:
    r = await run("ditto", ["-c", "-k", "--sequesterRsrc", "--keepParent", folder, dest], timeout=300)
    return {"code": r["code"], "stderr": r["stderr"]}


async def set_volume(v: int) -> dict:
    await run("osascript", ["-e", f"set volume output volume {v}"])
    return {"ok": True, "message": f"Volume set to {v}%"}


async def lock_screen_keys(control) -> dict:
    r = await control("key", "ctrl+cmd+q")
    return {"ok": True, "message": "Screen locked"} if r["ok"] else r


async def run_applescript(script: str, timeout: float = 60) -> dict:
    return await run("osascript", ["-"], input=script, timeout=timeout)


async def type_secret(secret: str) -> bool:
    """Types into the focused field (the lock screen password box). The script goes in through stdin
    so the password never appears in the process list."""
    esc = secret.replace("\\", "\\\\").replace('"', '\\"')
    r = await run("osascript", ["-"], input=f'tell application "System Events"\n  keystroke "{esc}"\n  delay 0.2\n  key code 36\nend tell')
    return r["code"] == 0


async def wake_screen(control) -> dict:
    spawn_quiet("caffeinate", ["-u", "-t", "3"])   # wake the display
    await asyncio.sleep(0.9)
    if not await screen_locked():
        return {"ok": True, "message": "The display is awake and unlocked"}
    pw = await run("security", ["find-generic-password", "-s", "ultron-unlock", "-w"])
    if pw["code"] != 0:
        return {"ok": False, "error": "No unlock password saved. Run ./set-unlock-password.sh"}
    await asyncio.sleep(0.4)
    await type_secret(pw["stdout"].rstrip("\n"))
    for _ in range(8):
        await asyncio.sleep(0.5)
        if not await screen_locked():
            return {"ok": True, "message": "Screen woken and unlocked"}
    return {"ok": False, "error": "Still locked. macOS may be blocking keystrokes: give Terminal Accessibility permission in System Settings → Privacy & Security."}


async def list_shortcuts() -> dict:
    r = await run("shortcuts", ["list"], timeout=15)
    if r["code"] != 0:
        return {"ok": False, "error": r["stderr"].strip() or "Couldn't read Shortcuts"}
    names = [x.strip() for x in r["stdout"].split("\n") if x.strip()]
    return {"ok": True, "count": len(names), "shortcuts": names[:200]}


async def computer_name() -> str | None:
    r = await run("scutil", ["--get", "ComputerName"])
    return r["stdout"].strip() if r["code"] == 0 and r["stdout"].strip() else None


def keep_awake_process(_control_exe=None):
    return spawn_quiet("caffeinate", ["-s"])   # prevent system sleep while on AC power


async def screenshot_to(path: str) -> bool:
    await run("screencapture", ["-x", path])
    return os.path.exists(path)


async def to_jpeg(src: str, dst: str) -> bool:
    await run("sips", ["-s", "format", "jpeg", "-s", "formatOptions", "80", "-Z", "1600", src, "--out", dst])
    return os.path.exists(dst)
