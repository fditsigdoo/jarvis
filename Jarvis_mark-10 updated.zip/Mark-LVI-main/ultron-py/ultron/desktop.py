"""ULTRON desktop shell, the JARVIS way: a Qt window on the main thread, the agent on an asyncio loop in a
background thread. Nothing listens on a port and no browser is opened.

The UI in public/ is NOT modified. It is loaded from a private in-app scheme (ultron://localhost/), and the
calls it already makes are routed in-process:

    fetch('/api/...')      -> server.handle_api        (a script injected before the page runs)
    WebSocket('/ws')       -> server.serve_agent       (same script, over a Qt web channel)
    WebSocket('/term')     -> server.serve_term
    GET /, /app.js, /tts/, /vendor/, /sites/, /files/  -> served straight from disk by the scheme handler
"""
from __future__ import annotations

import asyncio
import base64
import json
import signal
import sys
import threading
from pathlib import Path
from urllib.parse import parse_qsl, unquote, urlsplit

try:
    from PyQt6.QtCore import QByteArray, QFile, QIODevice, QObject, Qt, QTimer, QUrl, pyqtSignal, pyqtSlot
    from PyQt6.QtGui import QColor, QDesktopServices, QIcon
    from PyQt6.QtWebChannel import QWebChannel
    from PyQt6.QtWebEngineCore import (QWebEnginePage, QWebEngineProfile, QWebEngineScript, QWebEngineSettings,
                                       QWebEngineUrlRequestJob, QWebEngineUrlScheme, QWebEngineUrlSchemeHandler)
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    from PyQt6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget
except ImportError as _e:   # pragma: no cover
    sys.exit(f"ULTRON's desktop window needs PyQt6 and PyQt6-WebEngine:  pip install -r requirements.txt\n({_e})")

from . import server, settings
from .config import INBOX, MEM_DIR, MOUNTS, PUBLIC, mime_of
from .qtscheme import SCHEME, register_scheme
HOME_URL = "ultron://localhost/index.html"

# Injected into every page before its own scripts run (main world). It only swaps the transport underneath
# fetch('/api/...') and WebSocket('/ws' | '/term'); the UI code never knows.
SHIM_JS = r"""
(() => {
  if (window.__ultronShim) return;
  window.__ultronShim = true;
  let bridge = null; const waiting = [];
  const ready = new Promise(res => {
    const init = () => {
      if (typeof qt === 'undefined' || !qt.webChannelTransport || typeof QWebChannel === 'undefined') return void setTimeout(init, 10);
      new QWebChannel(qt.webChannelTransport, ch => {
        bridge = ch.objects.bridge;
        bridge.ws_event.connect(onWs);
        bridge.http_done.connect(onHttp);
        res(bridge);
      });
    };
    init();
  });
  const b64 = buf => { let s = ''; const u = new Uint8Array(buf); for (let i = 0; i < u.length; i += 0x8000) s += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000)); return btoa(s); };
  const unb64 = s => { const bin = atob(s), u = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i); return u.buffer; };

  // ── fetch('/api/...') ──
  const nativeFetch = window.fetch.bind(window), pending = new Map(); let rid = 0;
  function onHttp(id, status, text) {
    const r = pending.get(id); if (!r) return; pending.delete(id);
    r(new Response(text, { status, headers: { 'content-type': 'application/json', 'cache-control': 'no-store' } }));
  }
  window.fetch = async (input, init = {}) => {
    const req = input instanceof Request ? input : null;
    let url; try { url = new URL(req ? req.url : String(input), location.href); } catch { return nativeFetch(input, init); }
    if (url.host !== location.host || !url.pathname.startsWith('/api/')) return nativeFetch(input, init);
    const method = (init.method || (req && req.method) || 'GET').toUpperCase();
    const headers = new Headers(init.headers || (req && req.headers) || {});
    let buf = new ArrayBuffer(0);
    if (init.body != null) buf = await new Response(init.body).arrayBuffer();
    else if (req && method !== 'GET' && method !== 'HEAD') buf = await req.arrayBuffer();
    const b = await ready, id = 'h' + (++rid);
    return new Promise(res => { pending.set(id, res); b.http(id, method, url.pathname + url.search, headers.get('content-type') || '', b64(buf)); });
  };

  // ── WebSocket('/ws' | '/term') ──
  const NativeWS = window.WebSocket, socks = new Map(); let sid = 0;
  class BridgeSocket {
    constructor(path) {
      this.url = 'ultron://localhost' + path; this.readyState = 0; this.binaryType = 'blob'; this.protocol = ''; this.extensions = '';
      this.bufferedAmount = 0; this._l = {}; this.onopen = this.onmessage = this.onclose = this.onerror = null;
      this.id = 's' + (++sid); socks.set(this.id, this);
      ready.then(b => b.ws_open(this.id, path));
    }
    addEventListener(t, f) { (this._l[t] = this._l[t] || []).push(f); }
    removeEventListener(t, f) { this._l[t] = (this._l[t] || []).filter(x => x !== f); }
    dispatchEvent(e) { const h = this['on' + e.type]; if (h) h.call(this, e); (this._l[e.type] || []).slice().forEach(f => f.call(this, e)); return true; }
    _emit(type, props) { const e = new Event(type); Object.assign(e, props); this.dispatchEvent(e); }
    send(d) { if (this.readyState !== 1) throw new DOMException('Not open', 'InvalidStateError'); if (typeof d === 'string') ready.then(b => b.ws_send(this.id, d)); }
    close() { if (this.readyState >= 2) return; this.readyState = 3; socks.delete(this.id); ready.then(b => b.ws_close(this.id)); setTimeout(() => this._emit('close', { code: 1000, reason: '', wasClean: true }), 0); }
  }
  Object.assign(BridgeSocket, { CONNECTING: 0, OPEN: 1, CLOSING: 2, CLOSED: 3 });
  function onWs(id, kind, payload) {
    const s = socks.get(id); if (!s) return;
    if (kind === 'open') { s.readyState = 1; s._emit('open', {}); }
    else if (kind === 'text') s._emit('message', { data: payload });
    else if (kind === 'bytes') { const ab = unb64(payload); s._emit('message', { data: s.binaryType === 'arraybuffer' ? ab : new Blob([ab]) }); }
    else if (kind === 'close') { if (s.readyState === 3) return; s.readyState = 3; socks.delete(id); s._emit('close', { code: 1000, reason: '', wasClean: true }); }
  }
  window.WebSocket = function (url, protocols) {
    let u; try { u = new URL(url, location.href); } catch { return new NativeWS(url, protocols); }
    if (u.hostname === location.hostname && (u.pathname === '/ws' || u.pathname === '/term')) return new BridgeSocket(u.pathname);
    return new NativeWS(url, protocols);
  };
  Object.assign(window.WebSocket, { CONNECTING: 0, OPEN: 1, CLOSING: 2, CLOSED: 3 });

  // Hosted inside JARVIS: the CONFINE ULTRON button asks the host to take over again.
  window.__ultronHost = { confine: () => ready.then(b => b.confine()) };

  // Desktop window: no OS share sheet, and the browser speech API isn't in Qt WebEngine (Whisper is used instead).
  try { Object.defineProperty(navigator, 'canShare', { value: undefined }); } catch {}
  try { window.SpeechRecognition = undefined; window.webkitSpeechRecognition = undefined; } catch {}
})();
"""


# ───────────────────────── the agent loop (background thread) ─────────────────────────
class Backend:
    def __init__(self):
        self.loop = asyncio.new_event_loop()
        self.thread = threading.Thread(target=self._run, name="ultron-backend", daemon=True)

    def _run(self):
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def start(self):
        self.thread.start()

    def submit(self, coro):
        return asyncio.run_coroutine_threadsafe(coro, self.loop)

    def stop(self):
        try:
            self.submit(server.shutdown()).result(timeout=5)
        except Exception:
            pass
        self.loop.call_soon_threadsafe(self.loop.stop)


class BridgeSocket(server.Socket):
    """One UI WebSocket, as far as server.py is concerned."""

    def __init__(self, bridge: "Bridge", sid: str):
        self.bridge, self.sid, self.closed = bridge, sid, False
        self._q: asyncio.Queue = asyncio.Queue()

    def push(self, text: str):   # Qt thread
        self.bridge.backend.loop.call_soon_threadsafe(self._q.put_nowait, text)

    async def recv(self):
        return await self._q.get()

    def send_text(self, text: str):
        if not self.closed:
            self.bridge.ws_event.emit(self.sid, "text", text)

    def send_bytes(self, data: bytes):
        if not self.closed:
            self.bridge.ws_event.emit(self.sid, "bytes", base64.b64encode(data).decode())

    def close(self):   # asyncio thread
        if self.closed:
            return
        self.closed = True
        self.bridge.ws_event.emit(self.sid, "close", "")
        self._q.put_nowait(None)

    def shutdown(self):   # the window side let go
        self.closed = True
        self.bridge.backend.loop.call_soon_threadsafe(self._q.put_nowait, None)


class Bridge(QObject):
    ws_event = pyqtSignal(str, str, str)    # socket id, open | text | bytes | close, payload
    http_done = pyqtSignal(str, int, str)   # request id, status, json text
    confine_requested = pyqtSignal()        # the page's CONFINE ULTRON button

    def __init__(self, backend: Backend):
        super().__init__()
        self.backend = backend
        self.socks: dict[str, BridgeSocket] = {}

    @pyqtSlot()
    def confine(self):
        self.confine_requested.emit()

    @pyqtSlot(str, str)
    def ws_open(self, sid: str, path: str):
        self.backend.submit(self._serve(sid, path))

    @pyqtSlot(str, str)
    def ws_send(self, sid: str, text: str):
        s = self.socks.get(sid)
        if s:
            s.push(text)

    @pyqtSlot(str)
    def ws_close(self, sid: str):
        s = self.socks.pop(sid, None)
        if s:
            s.shutdown()

    @pyqtSlot(str, str, str, str, str)
    def http(self, rid: str, method: str, target: str, ctype: str, body_b64: str):
        self.backend.submit(self._http(rid, method, target, ctype, body_b64))

    def close_all(self):   # the page is reloading: its sockets are gone
        for sid in list(self.socks):
            self.ws_close(sid)

    async def _serve(self, sid: str, path: str):
        sock = BridgeSocket(self, sid)
        self.socks[sid] = sock
        self.ws_event.emit(sid, "open", "")
        try:
            if path == "/ws":
                await server.serve_agent(sock)
            elif path == "/term":
                await server.serve_term(sock)
        except Exception as e:
            print(f"  {path} ended: {e}")
        finally:
            sock.close()
            self.socks.pop(sid, None)

    async def _http(self, rid: str, method: str, target: str, ctype: str, body_b64: str):
        u = urlsplit(target)
        try:
            body = base64.b64decode(body_b64) if body_b64 else b""
            status, obj = await server.handle_api(server.Request(method, u.path, dict(parse_qsl(u.query, keep_blank_values=True)), body, ctype))
        except Exception as e:
            status, obj = 500, {"ok": False, "error": str(e)}
        self.http_done.emit(rid, status, json.dumps(obj, ensure_ascii=False))


# ───────────────────────── files straight from disk ─────────────────────────
def resolve(path: str):
    """URL path -> (file, mime), with the same mounts the old server used."""
    if path.startswith("/api/"):
        return None
    out = server.file_for(path)
    if out:
        return out[0], out[1]
    for prefix, d in MOUNTS:
        if not path.startswith(prefix):
            continue
        base = Path(d).resolve()
        f = (base / path[len(prefix):]).resolve()
        if base not in f.parents or not f.is_file():
            break
        return f, mime_of(f.name)
    return None


class SchemeHandler(QWebEngineUrlSchemeHandler):
    def requestStarted(self, job):
        if bytes(job.requestMethod()).decode() not in ("GET", "HEAD"):
            return job.fail(QWebEngineUrlRequestJob.Error.RequestAborted)
        path = unquote(job.requestUrl().path()) or "/"
        if path.endswith("/"):
            path += "index.html"
        hit = resolve(path)
        if not hit:
            return job.fail(QWebEngineUrlRequestJob.Error.UrlNotFound)
        f = QFile(str(hit[0]))
        if not f.open(QIODevice.OpenModeFlag.ReadOnly):
            return job.fail(QWebEngineUrlRequestJob.Error.RequestFailed)
        f.setParent(job)   # lives as long as the request
        job.reply(QByteArray(hit[1].encode()), f)


# ───────────────────────── page, window ─────────────────────────
class ExternalPage(QWebEnginePage):
    """target=_blank / window.open: hand the link to the system browser, never open a second ULTRON window."""

    def acceptNavigationRequest(self, url, nav_type, is_main_frame):
        if url.scheme() in ("http", "https", "mailto"):
            QDesktopServices.openUrl(url)
        return False


class Page(QWebEnginePage):
    def acceptNavigationRequest(self, url, nav_type, is_main_frame):
        if url.scheme() == "ultron":
            return True
        if url.scheme() in ("http", "https", "mailto"):
            QDesktopServices.openUrl(url)
        return False

    def createWindow(self, _type):
        return ExternalPage(self.profile(), self)


def _grant(page: QWebEnginePage):
    """Microphone (hearing) and camera (face / vision) are asked for once by Chromium; this is the user's own app."""
    if hasattr(page, "permissionRequested"):   # Qt 6.8+
        page.permissionRequested.connect(lambda perm: perm.grant())
    else:
        def ask(origin, feature):
            page.setFeaturePermission(origin, feature, QWebEnginePage.PermissionPolicy.PermissionGrantedByUser)
        page.featurePermissionRequested.connect(ask)


class UltronView(QWidget):
    """ULTRON's whole UI as one widget: the standalone window wraps it, JARVIS hosts it. The agent behind it
    runs on `backend` (an asyncio thread). `state` is loading | ready | error."""
    backend_ready = pyqtSignal(str)
    confine_requested = pyqtSignal()

    def __init__(self, backend: Backend, parent=None, embedded: bool = False):
        super().__init__(parent)
        self.embedded = embedded
        self.state, self.error = "loading", ""
        self._home = False

        profile = QWebEngineProfile("ultron", self)
        store_dir = MEM_DIR / "webdata"
        store_dir.mkdir(parents=True, exist_ok=True)
        profile.setPersistentStoragePath(str(store_dir))
        profile.setCachePath(str(store_dir / "cache"))
        profile.installUrlSchemeHandler(SCHEME, SchemeHandler(self))
        profile.downloadRequested.connect(self._download)

        self.bridge = Bridge(backend)
        self.bridge.confine_requested.connect(self.confine_requested)
        channel = QWebChannel(self)
        channel.registerObject("bridge", self.bridge)

        self.page = Page(profile, self)
        self.page.setWebChannel(channel)
        self.page.setBackgroundColor(QColor("#040506"))
        _grant(self.page)
        st = self.page.settings()
        st.setAttribute(QWebEngineSettings.WebAttribute.PlaybackRequiresUserGesture, False)   # her voice plays by itself
        st.setAttribute(QWebEngineSettings.WebAttribute.JavascriptCanAccessClipboard, True)

        scripts = profile.scripts()
        wc = QFile(":/qtwebchannel/qwebchannel.js")
        if not wc.open(QIODevice.OpenModeFlag.ReadOnly):
            sys.exit("Qt web channel script not found (reinstall PyQt6 and PyQt6-WebEngine)")
        js = bytes(wc.readAll()).decode("utf8") + "\n" + SHIM_JS
        wc.close()
        script = QWebEngineScript()
        script.setName("ultron-shim")
        script.setSourceCode(js)
        script.setInjectionPoint(QWebEngineScript.InjectionPoint.DocumentCreation)
        script.setWorldId(QWebEngineScript.ScriptWorldId.MainWorld)
        script.setRunsOnSubFrames(False)
        scripts.insert(script)

        self.view = QWebEngineView(self)
        self.view.setPage(self.page)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self.view)
        self.view.loadStarted.connect(self.bridge.close_all)
        self.view.loadFinished.connect(self._loaded)
        self.view.setHtml("<body style='margin:0;background:#040506'></body>")   # until the engines are up
        self.backend_ready.connect(self._ready)

    def _ready(self, err: str):
        if err:
            print(f"  startup failed: {err}")
            self.state, self.error = "error", err
            return
        self._home = True
        self.view.load(QUrl(HOME_URL))

    def _loaded(self, ok: bool):
        if not self._home:
            return
        if not ok:
            self.state, self.error = "error", "the ULTRON page did not load"
            return
        if self.embedded:   # shows the CONFINE ULTRON button
            self.page.runJavaScript("document.documentElement.classList.add('embedded')")
        self.state = "ready"

    def set_active(self, on: bool):
        """Hosted and hidden: silence her and stop whatever she was doing; shown again: let her speak."""
        self.page.setAudioMuted(not on)
        if not on:
            self.page.runJavaScript("window.UltronBridge && window.UltronBridge.stopAll && window.UltronBridge.stopAll()")

    def _download(self, dl):
        INBOX.mkdir(parents=True, exist_ok=True)
        dl.setDownloadDirectory(str(INBOX))
        dl.accept()


class Window(QMainWindow):
    """ULTRON on its own (python run.py)."""

    def __init__(self, backend: Backend):
        super().__init__()
        self.setWindowTitle("ULTRON")
        self.resize(1400, 900)
        icon = PUBLIC / "icon-180.png"
        if icon.exists():
            self.setWindowIcon(QIcon(str(icon)))
        self.pane = UltronView(backend, self)
        self.setCentralWidget(self.pane)


def _prefer_whisper():
    """Qt WebEngine has no browser speech recognizer, so a fresh install that still says 'browser' would not hear.
    Move it to local Whisper once; anything the user picked themselves is left alone."""
    try:
        if settings.get()["stt"]["engine"] == "browser":
            settings.save({"stt": {"engine": "local"}})
            print("  hearing: switched from 'browser' to local Whisper (pip install faster-whisper, or pick Groq/OpenAI in Settings → Voice)")
    except Exception as e:
        print(f"  hearing: could not update settings ({e})")


def boot_backend(backend: Backend, on_done):
    """Starts the agent on `backend`; on_done(err_text) is called from the asyncio thread when it is up."""
    async def boot():
        _prefer_whisper()
        await server.startup()
    backend.submit(boot()).add_done_callback(lambda f: on_done(str(f.exception() or "")))


def run():
    register_scheme()   # must happen before QApplication exists

    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("ULTRON")

    backend = Backend()
    backend.start()
    win = Window(backend)
    win.show()
    boot_backend(backend, win.pane.backend_ready.emit)

    app.aboutToQuit.connect(backend.stop)
    signal.signal(signal.SIGINT, lambda *_: app.quit())
    tick = QTimer()   # lets Python see Ctrl+C while Qt is running
    tick.start(250)
    tick.timeout.connect(lambda: None)
    sys.exit(app.exec())
