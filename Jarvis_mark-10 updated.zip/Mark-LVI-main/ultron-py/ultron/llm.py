"""Model calls: Ollama and Google Gemini, both as async generators of text.

Gemini models (named "gemini-...", no ":tag") go to Google; everything else goes to Ollama. If
Gemini fails before saying anything (offline, quota used up, bad key) the fallback model answers.
Messages come in Ollama's shape. Outbound HTTP uses only the standard library, in worker threads,
so a cancel just closes the connection.
"""
from __future__ import annotations

import asyncio
import json
import os
import re
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import AsyncIterator

from . import settings
from .config import CONFIG, NUM_CTX

# ───────────────────────── Gemini settings ─────────────────────────
GEMINI_API = "https://generativelanguage.googleapis.com/v1beta/models"
GEMINI_KEY_FILE = Path.home() / ".ultron-gemini-key"
GEMINI_MODELS = [m.strip() for m in os.environ.get("ULTRON_GEMINI_MODELS", "gemini-3.5-flash-lite,gemini-3.5-flash").split(",") if m.strip()]


def is_gemini(model: str) -> bool:
    return bool(re.match(r"^gemini-", model or "")) and ":" not in model


def gemini_key() -> str:
    """Read on every call, so a new key works without restarting."""
    if os.environ.get("GEMINI_API_KEY"):
        return os.environ["GEMINI_API_KEY"].strip()
    try:
        k = GEMINI_KEY_FILE.read_text("utf8").strip()
        if k:
            return k
    except OSError:
        pass
    return settings.gemini_key_saved() or os.environ.get("GOOGLE_API_KEY", "").strip()


def is_api(model: str) -> bool:
    """Models of the OpenAI-compatible service picked in Settings are named "api:<model>"."""
    return (model or "").startswith("api:")


def default_model() -> str:
    prov = settings.provider()
    if prov == "api":
        m = settings.api_service()["model"]
        if m:
            return "api:" + m
    elif prov == "gemini" and GEMINI_MODELS:
        return GEMINI_MODELS[0]
    elif prov == "ollama":
        return CONFIG["model"] if CONFIG["model"] and not is_gemini(CONFIG["model"]) else CONFIG["fallback_model"]
    return CONFIG["model"] or (GEMINI_MODELS[0] if gemini_key() and GEMINI_MODELS else "gemma3:12b")


class Cancelled(Exception):
    """The caller cancelled (the user talked over ULTRON, or pressed stop)."""


class Signal:
    """Stands in for AbortController: cancel() stops whatever is streaming."""

    def __init__(self):
        self.aborted = False
        self._closers: list = []

    def cancel(self):
        self.aborted = True
        for c in list(self._closers):
            try:
                c()
            except Exception:
                pass

    def _watch(self, closer):
        self._closers.append(closer)
        if self.aborted:
            closer()

    def _unwatch(self, closer):
        if closer in self._closers:
            self._closers.remove(closer)


# ───────────────────────── streaming over urllib ─────────────────────────
async def _stream_lines(url: str, body: dict, headers: dict, signal: Signal | None, timeout: float = 600) -> AsyncIterator[str]:
    """POSTs JSON and yields the response line by line, reading in a worker thread."""
    loop = asyncio.get_running_loop()
    q: asyncio.Queue = asyncio.Queue()
    state = {"resp": None}

    def close():
        r = state["resp"]
        if r is not None:
            try:
                r.close()
            except Exception:
                pass

    def worker():
        try:
            req = urllib.request.Request(url, data=json.dumps(body).encode(), headers={"content-type": "application/json", **headers}, method="POST")
            try:
                resp = urllib.request.urlopen(req, timeout=timeout)
            except urllib.error.HTTPError as e:
                loop.call_soon_threadsafe(q.put_nowait, ("http_error", (e.code, e.read().decode("utf8", "replace"))))
                return
            state["resp"] = resp
            if signal and signal.aborted:
                resp.close()
                loop.call_soon_threadsafe(q.put_nowait, ("end", None))
                return
            for raw in resp:
                loop.call_soon_threadsafe(q.put_nowait, ("line", raw.decode("utf8", "replace")))
            loop.call_soon_threadsafe(q.put_nowait, ("end", None))
        except Exception as e:  # closed by cancel, network failure...
            loop.call_soon_threadsafe(q.put_nowait, ("error", e))

    if signal:
        signal._watch(close)
    task = loop.run_in_executor(None, worker)
    try:
        while True:
            kind, val = await q.get()
            if kind == "line":
                yield val
            elif kind == "end":
                return
            elif kind == "http_error":
                yield f"\0HTTP {val[0]} {val[1]}"
                return
            else:
                if signal and signal.aborted:
                    raise Cancelled()
                raise val
        
    finally:
        close()
        if signal:
            signal._unwatch(close)
        del task



async def _get_json(url: str, body: dict | None = None, timeout: float = 10):
    def go():
        req = urllib.request.Request(url, data=json.dumps(body).encode() if body is not None else None,
                                     headers={"content-type": "application/json"}, method="POST" if body is not None else "GET")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf8", "replace"))
    return await asyncio.get_running_loop().run_in_executor(None, go)


async def _fire(url: str, body: dict, timeout: float = 300):
    def go():
        try:
            req = urllib.request.Request(url, data=json.dumps(body).encode(), headers={"content-type": "application/json"}, method="POST")
            urllib.request.urlopen(req, timeout=timeout).read()
        except Exception:
            pass
    await asyncio.get_running_loop().run_in_executor(None, go)


# ───────────────────────── Ollama ─────────────────────────
async def ollama_chat(model: str, messages: list, signal: Signal | None = None, options: dict | None = None, stats: dict | None = None):
    t0 = time.time()
    body = {"model": model, "messages": messages, "stream": True, "keep_alive": "30m",
            "options": {"temperature": 0.6, "num_ctx": NUM_CTX, **(options or {})}}
    first = True
    async for line in _stream_lines(f"{CONFIG['ollama']}/api/chat", body, {}, signal):
        if line.startswith("\0HTTP"):
            raise RuntimeError(f"Ollama {line[6:].split(' ', 1)[0]}: {line.split(' ', 2)[2][:200]}")
        line = line.strip()
        if not line:
            continue
        j = json.loads(line)
        if j.get("error"):
            raise RuntimeError(j["error"])
        content = (j.get("message") or {}).get("content")
        if content:
            if first and stats is not None:
                stats["firstTokenMs"] = int((time.time() - t0) * 1000)
                first = False
            yield content
        if j.get("done") and stats is not None and j.get("eval_duration"):
            stats["tokensPerSec"] = j["eval_count"] / (j["eval_duration"] / 1e9)


# ───────────────────────── Gemini ─────────────────────────
_SIGNATURES = {"/9j/": "image/jpeg", "iVBOR": "image/png", "UklGR": "image/webp", "R0lGO": "image/gif"}


def _image_mime(b64: str) -> str:
    return next((m for sig, m in _SIGNATURES.items() if b64.startswith(sig)), "image/jpeg")


def to_gemini(messages: list):
    """System messages become the system instruction, "assistant" becomes "model", images become
    inline parts, and back-to-back messages from one side are merged."""
    system, contents = [], []
    for m in messages:
        if m.get("role") == "system":
            if m.get("content"):
                system.append(m["content"])
            continue
        role = "model" if m.get("role") == "assistant" else "user"
        parts = []
        if m.get("content"):
            parts.append({"text": m["content"]})
        for img in m.get("images") or []:
            parts.append({"inlineData": {"mimeType": _image_mime(img), "data": img}})
        if not parts:
            continue
        if contents and contents[-1]["role"] == role:
            contents[-1]["parts"].extend(parts)
        else:
            contents.append({"role": role, "parts": parts})
    return "\n\n".join(system), contents


def _error_text(body: str) -> str:
    try:
        msg = json.loads(body).get("error", {}).get("message")
    except Exception:
        msg = None
    return (msg or body).split("\n")[0][:200]


_no_minimal: set = set()   # models that refuse thinkingLevel "minimal"


async def gemini_chat(model: str, messages: list, signal: Signal | None = None, options: dict | None = None, stats: dict | None = None):
    options = options or {}
    key = gemini_key()
    if not key:
        raise RuntimeError("No Gemini API key (set GEMINI_API_KEY or write it to ~/.ultron-gemini-key)")
    system, contents = to_gemini(messages)
    gen = {"temperature": options.get("temperature", 0.6)}
    if options.get("stop"):
        gen["stopSequences"] = options["stop"][:5]
    if (options.get("num_predict") or 0) > 0:
        gen["maxOutputTokens"] = options["num_predict"]
    url = f"{GEMINI_API}/{urllib.request.quote(model, safe='')}:streamGenerateContent?alt=sse"
    t0 = time.time()
    t_first, out_tokens, finish = 0.0, 0, ""
    # Keep thinking short: this is a voice assistant. Models that refuse "minimal" get "low".
    for level in (["low"] if model in _no_minimal else ["minimal", "low"]):
        gen["thinkingConfig"] = {"thinkingLevel": level}
        body = {**({"systemInstruction": {"parts": [{"text": system}]}} if system else {}), "contents": contents, "generationConfig": gen}
        retry = False
        started = False
        async for line in _stream_lines(url, body, {"x-goog-api-key": key}, signal):
            if line.startswith("\0HTTP"):
                status = int(line[6:].split(" ", 1)[0])
                text = line.split(" ", 2)[2] if line.count(" ") >= 2 else ""
                if status == 400 and level == "minimal" and re.search(r"thinking level", text, re.I):
                    _no_minimal.add(model)
                    retry = True
                    break
                raise RuntimeError(f"Gemini {status}: {_error_text(text)}")
            line = line.strip()
            if not line.startswith("data:"):
                continue
            j = json.loads(line[5:])
            if j.get("error"):
                raise RuntimeError(f"Gemini: {j['error'].get('message')}")
            block = (j.get("promptFeedback") or {}).get("blockReason")
            if block:
                raise RuntimeError(f"Gemini blocked the request ({block})")
            cand = (j.get("candidates") or [{}])[0]
            if cand.get("finishReason"):
                finish = cand["finishReason"]
            tok = (j.get("usageMetadata") or {}).get("candidatesTokenCount")
            if tok:
                out_tokens = tok
            for p in (cand.get("content") or {}).get("parts") or []:
                if p.get("thought") or not p.get("text"):
                    continue
                if not t_first:
                    t_first = time.time()
                    if stats is not None:
                        stats["firstTokenMs"] = int((t_first - t0) * 1000)
                started = True
                yield p["text"]
        if retry:
            continue
        break
    # Nothing said and not a normal stop (safety block, recitation...): an error, so the caller can fall back.
    if not t_first and finish and finish != "STOP":
        raise RuntimeError(f"Gemini returned no text ({finish})")
    if stats is not None and t_first and out_tokens:
        stats["tokensPerSec"] = out_tokens / max(time.time() - t_first, 0.05)


# ───────────────────────── OpenAI-compatible services (OpenAI, Groq, OpenRouter, LM Studio...) ─────────────────────────
def to_openai(messages: list) -> list:
    """Ollama-shaped messages -> OpenAI chat messages (images become data: URLs)."""
    out = []
    for m in messages:
        imgs = m.get("images") or []
        if imgs and m.get("role") == "user":
            parts = [{"type": "text", "text": m.get("content") or ""}]
            parts += [{"type": "image_url", "image_url": {"url": f"data:{_image_mime(i)};base64,{i}"}} for i in imgs]
            out.append({"role": "user", "content": parts})
        else:
            out.append({"role": m.get("role", "user"), "content": m.get("content") or ""})
    return out


async def openai_chat(model: str, messages: list, signal: Signal | None = None, options: dict | None = None, stats: dict | None = None):
    options = options or {}
    svc = settings.api_service()
    if not svc["base_url"]:
        raise RuntimeError("No address set for the AI service (Settings → AI engine)")
    if not svc["key"] and not svc["local"]:
        raise RuntimeError(f"No API key for {svc['label']} (Settings → AI engine)")
    body = {"model": model, "messages": to_openai(messages), "stream": True, "temperature": options.get("temperature", 0.6)}
    if options.get("stop"):
        body["stop"] = options["stop"][:4]
    if (options.get("num_predict") or 0) > 0:
        body["max_tokens"] = options["num_predict"]
    headers = {"Authorization": f"Bearer {svc['key']}"} if svc["key"] else {}
    t0 = time.time()
    t_first = 0.0
    n = 0
    async for line in _stream_lines(f"{svc['base_url']}/chat/completions", body, headers, signal):
        if line.startswith("\0HTTP"):
            status = int(line[6:].split(" ", 1)[0])
            text = line.split(" ", 2)[2] if line.count(" ") >= 2 else ""
            raise RuntimeError(f"{svc['label']} {status}: {_error_text(text)}")
        line = line.strip()
        if not line.startswith("data:"):
            continue
        data = line[5:].strip()
        if data == "[DONE]":
            break
        try:
            j = json.loads(data)
        except ValueError:
            continue
        if j.get("error"):
            raise RuntimeError(f"{svc['label']}: {j['error'].get('message') if isinstance(j['error'], dict) else j['error']}")
        delta = ((j.get("choices") or [{}])[0].get("delta") or {}).get("content")
        if delta:
            if not t_first:
                t_first = time.time()
                if stats is not None:
                    stats["firstTokenMs"] = int((t_first - t0) * 1000)
            n += 1
            yield delta
    if stats is not None and t_first and n:
        stats["tokensPerSec"] = n / max(time.time() - t_first, 0.05)


async def api_models() -> list:
    svc = settings.api_service()
    if not svc["base_url"] or (not svc["key"] and not svc["local"]):
        return []

    def go():
        req = urllib.request.Request(f"{svc['base_url']}/models", headers={"Authorization": f"Bearer {svc['key']}"} if svc["key"] else {})
        with urllib.request.urlopen(req, timeout=8) as r:
            return json.loads(r.read().decode("utf8", "replace"))
    try:
        j = await asyncio.get_running_loop().run_in_executor(None, go)
        ids = sorted({m.get("id") for m in (j.get("data") or []) if m.get("id")})
    except Exception:
        ids = []
    if svc["model"] and svc["model"] not in ids:
        ids.insert(0, svc["model"])
    return ["api:" + i for i in ids[:200]]


async def test_api(service: dict | None = None) -> dict:
    """The TEST button: one tiny round trip. Returns {ok, message}."""
    svc = settings.api_service()
    model = svc["model"]
    if not model:
        ms = await api_models()
        model = ms[0][4:] if ms else ""
    if not model:
        return {"ok": False, "message": "Pick a model first (or press LIST)."}
    t0 = time.time()
    try:
        text = ""
        async for t in openai_chat(model, [{"role": "user", "content": "Reply with the single word: ok"}], None, {"num_predict": 8}):
            text += t
        return {"ok": True, "message": f"{svc['label']} answered in {time.time() - t0:.1f}s"}
    except Exception as e:
        msg = str(e)
        if re.search(r"\b40[13]\b", msg):
            msg = "The server refused the key."
        elif "404" in msg:
            msg = f"No model called '{model}' at that address."
        elif isinstance(e, (urllib.error.URLError, OSError)):
            msg = "Nothing answered at that address."
        return {"ok": False, "message": msg[:200]}


async def test_gemini() -> dict:
    if not gemini_key():
        return {"ok": False, "message": "No Gemini key set."}
    t0 = time.time()
    try:
        async for _ in gemini_chat(GEMINI_MODELS[0], [{"role": "user", "content": "Reply with the single word: ok"}], None, {"num_predict": 8}):
            break
        return {"ok": True, "message": f"Gemini answered in {time.time() - t0:.1f}s"}
    except Exception as e:
        return {"ok": False, "message": str(e)[:200]}


# ───────────────────────── the one entry point ─────────────────────────
async def chat(model: str, messages: list, signal: Signal | None = None, options: dict | None = None, stats: dict | None = None):
    if not is_gemini(model) and not is_api(model):
        async for t in ollama_chat(model, messages, signal, options, stats):
            yield t
        return
    said = False
    try:
        remote = openai_chat(model[4:], messages, signal, options, stats) if is_api(model) else gemini_chat(model, messages, signal, options, stats)
        async for t in remote:
            said = True
            yield t
    except Exception as e:
        if said or isinstance(e, Cancelled) or (signal and signal.aborted):
            raise
        print(f"  ⚠ {model}: {e} — answering with {CONFIG['fallback_model']}")
        if stats is not None:
            stats["fallback"] = CONFIG["fallback_model"]
        async for t in ollama_chat(CONFIG["fallback_model"], messages, signal, options, stats):
            yield t


async def chat_once(model: str, messages: list, signal: Signal | None = None, options: dict | None = None) -> dict:
    """One whole reply, not streamed. Model errors come back as {ok: False}; a cancel still raises."""
    try:
        text = ""
        async for t in chat(model, messages, signal, options):
            text += t
        return {"ok": True, "text": text.strip()}
    except Cancelled:
        raise
    except Exception as e:
        if signal and signal.aborted:
            raise Cancelled()
        return {"ok": False, "error": str(e)}


async def list_models() -> list:
    gem = list(GEMINI_MODELS) if gemini_key() else []
    prov = settings.provider()
    if prov == "api":
        return await api_models() + gem
    try:
        j = await _get_json(f"{CONFIG['ollama']}/api/tags")
        return gem + [m["name"] for m in j.get("models", [])]
    except Exception:
        return gem


_caps: dict = {}


async def has_vision(model: str) -> bool:
    if is_gemini(model):
        return True
    if is_api(model):
        return settings.api_has_vision(model[4:])
    if model in _caps:
        return _caps[model]
    v = False
    try:
        j = await _get_json(f"{CONFIG['ollama']}/api/show", {"model": model})
        v = "vision" in (j.get("capabilities") or [])
    except Exception:
        pass
    _caps[model] = v
    return v


def warm_up(model: str):
    if is_gemini(model) or is_api(model):
        return
    asyncio.ensure_future(_fire(f"{CONFIG['ollama']}/api/generate", {"model": model, "prompt": "", "keep_alive": "30m", "options": {"num_ctx": NUM_CTX}}))
