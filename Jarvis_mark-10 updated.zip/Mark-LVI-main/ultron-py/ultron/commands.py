"""Slash commands typed in the chat box. They never reach the model: a command runs instantly, and
the answer comes back as a plain notice. Secrets are deliberately NOT settable from here, because
whatever is typed in the chat ends up in the conversation log; keys go through Settings only.
"""
from __future__ import annotations

import re

from . import llm, settings, store
from .config import CONFIG

HELP = (
    "Commands:\n"
    "/status — what I'm running on\n"
    "/provider auto|ollama|gemini|<service> — AI engine (services: "
    + ", ".join(s["id"] for s in settings.SERVICES) + ")\n"
    "/model <name> — pick the model (use /models to list)\n"
    "/models — list what the current engine offers\n"
    "/voice on|off — spoken replies\n"
    "/tts local|elevenlabs|openai — speaking engine\n"
    "/stt browser|groq|openai|local — hearing engine (push-to-talk)\n"
    "/auto on|off — auto-authorize commands\n"
    "/settings — open the settings window\n"
    "/reset — forget this conversation\n"
    "Keys are set in the settings window, never in chat."
)

_ON = re.compile(r"^(on|true|yes|1|켜|켬)$", re.I)
_OFF = re.compile(r"^(off|false|no|0|꺼|끔)$", re.I)


def is_command(text: str) -> bool:
    return bool(re.match(r"^/[a-z]+(\s|$)", text.strip(), re.I))


def _status(s) -> str:
    S = settings.get()
    prov = S["llm"]["provider"]
    svc = settings.api_service()
    eng = f"{svc['label']} (API)" if prov == "api" else {"auto": "auto (Gemini key → Gemini, else Ollama)", "ollama": "Ollama", "gemini": "Gemini"}[prov]
    return (f"Engine: {eng}\nModel: {s.model}\nVoice out: {'on' if s.tts else 'off'} · {S['tts']['engine']}\n"
            f"Hearing: {S['stt']['engine']}\nAuto-authorize: {'on' if s.auto_approve else 'off'}")


async def _apply_engine(s, prov: str, service: str = "") -> str:
    patch = {"llm": {"provider": prov, **({"service": service, "model": ""} if service else {})}}
    settings.save(patch)
    if prov == "api":
        svc = settings.api_service()
        if not svc["key"] and not svc["local"]:
            return f"{svc['label']} selected, but it has no API key yet. Open /settings → AI engine."
    s.model = llm.default_model()
    store.save_prefs({**store.PREFS, "model": s.model})
    await refresh_models(s)
    return f"Engine → {prov if prov != 'api' else settings.api_service()['label']} · model {s.model}"


async def refresh_models(s):
    """Re-sends the model list so every open window's dropdown follows the change."""
    from .config import VOICES
    for c in list(store.clients) or [s]:
        c.model = s.model if c is s else c.model
        c.send({"type": "models", "models": await llm.list_models(), "current": c.model, "coder": c.coder_model,
                "voices": VOICES, "voice": c.voice, "pitch": c.pitch, "speed": c.speed, "force": c is s or c.model == s.model})


async def run(s, text: str) -> str:
    """Executes one command and returns the reply text. May also send UI messages."""
    parts = text.strip().split()
    cmd, args = parts[0][1:].lower(), parts[1:]
    arg = " ".join(args)

    if cmd in ("help", "h", "?"):
        return HELP
    if cmd == "status":
        return _status(s)
    if cmd == "settings":
        s.send({"type": "open_settings"})
        return "Opening settings."
    if cmd == "reset":
        store.CONVO.clear()
        return "Conversation cleared."
    if cmd == "voice":
        if _ON.match(arg):
            s.tts = True
        elif _OFF.match(arg):
            s.tts = False
        else:
            return f"Voice output is {'on' if s.tts else 'off'}. Use /voice on or /voice off."
        s.send({"type": "voice_state", "on": s.tts})
        return f"Voice output {'on' if s.tts else 'off'}."
    if cmd == "auto":
        if _ON.match(arg):
            s.auto_approve = True
        elif _OFF.match(arg):
            s.auto_approve = False
        else:
            return f"Auto-authorize is {'on' if s.auto_approve else 'off'}."
        return f"Auto-authorize {'on' if s.auto_approve else 'off'}."
    if cmd == "tts":
        if arg not in ("local", "elevenlabs", "openai"):
            return f"Speaking engine: {settings.get()['tts']['engine']}. Choose local, elevenlabs or openai."
        settings.save({"tts": {"engine": arg}})
        return f"Speaking engine → {arg}." + ("" if arg == "local" else " (key and voice are set in /settings)")
    if cmd == "stt":
        if arg not in ("browser", "groq", "openai", "local"):
            return f"Hearing engine: {settings.get()['stt']['engine']}. Choose browser, groq, openai or local."
        settings.save({"stt": {"engine": arg}})
        s.send({"type": "settings_changed"})
        return f"Hearing engine → {arg}." + (" Hold the mic button (or Space) to talk." if arg != "browser" else "")
    if cmd == "provider":
        ids = {x["id"] for x in settings.SERVICES}
        if arg in ("auto", "ollama", "gemini"):
            return await _apply_engine(s, arg)
        if arg in ids:
            return await _apply_engine(s, "api", arg)
        return "Choose: auto, ollama, gemini, " + ", ".join(sorted(ids))
    if cmd == "models":
        ms = await llm.list_models()
        return "Models:\n" + "\n".join(ms[:40]) if ms else "No models found for this engine."
    if cmd == "model":
        if not arg:
            return f"Model: {s.model}"
        ms = await llm.list_models()
        pick = arg if arg in ms else next((m for m in ms if m.endswith(arg) or arg.lower() in m.lower()), "")
        if not pick and settings.provider() == "api":
            pick = "api:" + arg          # a model the list doesn't show but the service accepts
        if not pick:
            return f"No model like '{arg}'. Try /models."
        s.model = pick
        llm.warm_up(pick)
        store.save_prefs({**store.PREFS, "model": pick})
        await refresh_models(s)
        return f"Model → {pick}"
    return f"Unknown command /{cmd}. Try /help."
