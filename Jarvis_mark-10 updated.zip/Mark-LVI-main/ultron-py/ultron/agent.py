"""The agent: one Session per connected UI, the system prompt, the tool loop, dictation and quick actions."""
from __future__ import annotations

import asyncio
import json
import random
import re
import time
from datetime import datetime

from . import control as ctl
from . import llm, phone, store
from . import osplat as plat
from . import scheduler as sched
from .config import CONFIG, HOST, INBOX, IS_WIN, PROMPTS, SITES, VOICES, WORKSPACE, app_name, clamp, now_ms
from .speech import Speech, default_voice, speak
from .streamparse import StreamParser, parse_action
from .tools import TOOLS

OBSERVE_AFTER = {"open_app", "open_url", "click_element", "click", "type_text", "press_keys", "scroll", "drag", "move_mouse"}
_action_seq = 0
call_session = None   # while a call is up on a phone, every other screen goes quiet


# ───────────────────────── session ─────────────────────────
class Session:
    def __init__(self, send_fn, close_fn, is_open_fn, remote: bool, device: dict | None):
        self._send, self._close, self._is_open = send_fn, close_fn, is_open_fn
        self.remote, self.device = remote, device
        self.native = False
        self.phone_name = None
        self.call_reason = ""
        self.model = llm.default_model()
        self.coder_model = CONFIG["coder_model"]
        self.voice = default_voice()
        self.pitch = float(__import__("os").environ.get("ULTRON_PITCH") or 1)
        self.speed = float(__import__("os").environ.get("ULTRON_SPEED") or 1)
        self.title = CONFIG["title"]
        self.tts = True
        self.auto_approve = CONFIG["auto_approve"]
        self.history = store.CONVO
        self.turn = 0
        self.signal: llm.Signal | None = None
        self.pending: dict = {}
        self.req_id = 0
        self.tts_chain = None
        self.recall: list = []
        self.dictation_app = None

    def attach_loop(self):
        self.tts_chain = asyncio.get_running_loop().create_future()
        self.tts_chain.set_result(None)

    def send(self, obj: dict):
        if self._is_open():
            self._send(obj)

    def is_open(self) -> bool:
        return self._is_open()

    def close(self):
        self._close()

    def request(self, obj: dict, timeout: float):
        """Asks the UI something and waits for its reply (None on timeout)."""
        self.req_id += 1
        rid = self.req_id
        fut = asyncio.get_running_loop().create_future()
        self.pending[rid] = fut
        self.send({**obj, "id": rid})

        async def wait():
            try:
                return await asyncio.wait_for(asyncio.shield(fut), timeout)
            except asyncio.TimeoutError:
                return None
            finally:
                self.pending.pop(rid, None)
        return wait()

    def reply(self, rid, value):
        f = self.pending.pop(rid, None)
        if f and not f.done():
            f.set_result(value)

    def cancel(self):
        if self.signal:
            self.signal.cancel()
            self.signal = None
        for f in self.pending.values():
            if not f.done():
                f.set_result(None)
        self.pending.clear()

    def new_turn(self) -> int:
        self.cancel()
        self.turn += 1
        self.send({"type": "turn", "turn": self.turn})
        return self.turn

    def phone_log(self, text: str):
        line = f"{phone.phone_name(self)}: {text}"
        print(f"  📱 {line}")
        try:
            with open(WORKSPACE / ".phone.log", "a", encoding="utf8") as f:
                f.write(f"{datetime.now():%Y-%m-%d %H:%M:%S} {line}\n")
        except OSError:
            pass


def hand_off(ph, on_call: bool):
    """While a call is up on a phone, every other screen (the Mac above all) goes quiet and stops
    listening, so it doesn't answer you talking into the phone; hanging up hands it back."""
    global call_session
    if not on_call and call_session is not ph:
        return
    call_session = ph if on_call else None
    for c in list(store.clients):
        if c is ph:
            continue
        if on_call:
            c.new_turn()
            c.send({"type": "busy", "busy": False, "turn": c.turn})
        c.send({"type": "handoff", "to": "phone" if on_call else "mac", "phone": phone.phone_name(ph)})


# ───────────────────────── system prompt ─────────────────────────
_prompt_cache: dict = {}


def _p(name: str) -> str:
    if name not in _prompt_cache:
        _prompt_cache[name] = (PROMPTS / f"{name}.txt").read_text("utf8")
    return _prompt_cache[name]


def _date_text(now: datetime) -> str:
    return f"{now.strftime('%A')} {now.day} {now.strftime('%B %Y')} at {now.strftime('%H:%M')}"


def system_prompt(s: Session) -> str:
    base = "system_win" if IS_WIN else "system_mac"
    profile = store.profile_text()
    # memory/profile.md is who she IS. Without it, she's the stock ULTRON.
    if profile:
        identity = ("=== WHO YOU ARE. This is your identity, voice and personality. Stay in it in every single reply, including short ones and "
                    f"ones with actions. ===\n{profile}\n=== END OF WHO YOU ARE ===")
    else:
        identity = (f"You are ULTRON, an AI running locally on your user's {HOST}. You are quick, sharp, confident and a little cheeky, and you get things done. "
                    f"You may call the user \"{s.title}\" now and then, but most replies should not address them at all: never more than once in a reply, "
                    "and never twice in a row.")
    n_phones = len(phone.phones())
    link = _p(f"{base}_phone_remote") if s.remote else _p(f"{base}_phone_connected") if n_phones else _p(f"{base}_phone_none")
    text = _p(base)
    # Longest placeholders first; the phone-link text itself holds more placeholders, so it goes in before them.
    text = text.replace("{{PHONE_LINK}}", link)
    subs = {
        "{{IDENTITY}}": identity, "{{NOW}}": _date_text(datetime.now()), "{{SITES}}": str(SITES), "{{WORKSPACE}}": str(WORKSPACE),
        "{{MEMORY}}": store.memory_text(), "{{PAST}}": store.past_text(s), "{{ONLINE_PHONES}}": phone.online_phones() or "none",
        "{{INBOX}}": str(INBOX), "{{TITLE}}": s.title, "{{HOST}}": HOST,
        "{{PROFILE_TAIL}}": _p(f"{base}_profile_tail") if profile else "",
    }
    # One pass, so text a user put in memory or profile is never treated as a placeholder.
    return re.sub(r"\{\{[A-Z_]+\}\}", lambda m: subs.get(m.group(0), m.group(0)), text)


# ───────────────────────── running a tool ─────────────────────────
def brief(args) -> dict:
    out = {}
    for k, v in (args or {}).items():
        sv = v if isinstance(v, str) else json.dumps(v)
        out[k] = sv[:140] + "…" if sv and len(sv) > 140 else sv
    return out


async def run_tool(s: Session, call: dict, signal, observe: bool = True) -> dict:
    global _action_seq
    tool, args = call["tool"], call.get("args") or {}
    _action_seq += 1
    aid = _action_seq
    s.send({"type": "action", "id": aid, "tool": tool, "args": brief(args), "status": "running"})
    watch = observe and tool in OBSERVE_AFTER and ctl.available()
    target = app_name(args.get("name")) if tool == "open_app" else (app_name(args["browser"]) if args.get("browser") else "") if tool == "open_url" else args.get("app") or ""
    before = None
    if watch and tool not in ("open_app", "open_url"):
        lv = ctl.state.last_view
        if lv and lv["target"] == target and time.time() - lv["t"] < 8:
            before = lv["ui"]
        else:
            v = await ctl.control("ui", target)
            if v["ok"]:
                before = ctl.split_ui(v["message"])
    try:
        result = await TOOLS[tool](s, args, {"id": aid, "signal": signal})
    except llm.Cancelled:
        result = {"ok": False, "error": "Cancelled"}
    except Exception as e:
        result = {"ok": False, "error": str(e) or type(e).__name__}
    # After touching the UI, show the model what the screen looks like now (the element list, what changed, and an
    # actual screenshot), so it checks each step before taking the next one.
    if watch and not (signal and signal.aborted):
        view = await ctl.observe_after(tool, target, before)
        if view:
            result["screen_now"] = view["text"]
        shot = view["image"] if view and view["image"] else (await ctl.capture_screen(target, True) or {}).get("image")
        if shot:
            result["screenshot"] = shot
    print(f"  ▸ {tool} {json.dumps(brief(args), ensure_ascii=False)[:160]} → {'ok' if result.get('ok') else 'FAILED'} {(result.get('error') or result.get('message') or '')[:160]}")
    s.send({"type": "action", "id": aid, "tool": tool, "status": "done" if result.get("ok") else "failed",
            "detail": result.get("error") or result.get("message") or result.get("observation") or ""})
    return result


def spoken_status(text: str) -> str:
    t = re.sub(r"<think>[\s\S]*?(</think>|$)", "", str(text or "")).strip()
    m = re.match(r"^[^.!?\n]+[.!?]?", t)
    first = m.group(0).strip() if m else ""
    return first if first and len(first.split()) <= 7 else ""


def notice(s: Session, text: str, kind: str = ""):
    """A standalone spoken line that doesn't interrupt whatever ULTRON is doing."""
    s.send({"type": "notice", "text": text, "kind": kind})
    speak(s, s.turn, text)


# ───────────────────────── the turn loop ─────────────────────────
async def run_turn(s: Session, user_text: str, interrupted: bool = False):
    turn = s.new_turn()
    sig = llm.Signal()
    s.signal = sig
    s.send({"type": "busy", "busy": True, "turn": turn})
    s.recall = store.recall_for(user_text)
    # Tell the model it got cut off, so it drops the old thread instead of finishing its speech.
    s.history.push({"role": "user", "content": f"(I talked over you and cut you off.) {user_text}" if interrupted else user_text})
    print(f"\n  ◂ {user_text}")

    last_sig, repeats, action_count = "", 0, 0
    screenshot = last_shot = None
    screen_acts, checked = 0, False
    typed: set = set()
    try:
        for step in range(15):
            actions: list = []
            # Only the first reply speaks as it streams. Later steps are held: before another action only a short
            # status gets said ("Following her."), then the final answer.
            speech = Speech(s, turn, step > 0)
            stats: dict = {}
            # Once an action is emitted, anything else the model writes is a guess at the result (small models love
            # to hallucinate "[TOOL RESULTS]"). Drop it and stop generating.
            st = {"kept": "", "after": False, "halluc": False}

            def on_text(text):
                if st["after"]:
                    if text.strip():
                        st["halluc"] = True
                    return
                st["kept"] += text
                speech.add(text)
                s.send({"type": "token", "text": text, "turn": turn})

            def on_block(kind, body):
                if kind not in ("action", "code"):
                    return
                a = parse_action(body, lambda n: n in TOOLS)
                if not a:
                    return
                actions.append(a)
                st["kept"] += f"\n<action>{json.dumps(a, ensure_ascii=False)}</action>"
                st["after"] = True

            parser = StreamParser(on_text, on_block)
            s.send({"type": "state", "state": "thinking", "turn": turn})
            # Only the latest tool result keeps its full screen snapshot; older ones are compacted.
            hist = s.history[-24:]
            recent = [{"role": m["role"], "content": m["compact"] if m.get("compact") and i < len(hist) - 1 else m["content"]} for i, m in enumerate(hist)]
            # The screen right after the last action: the model looks at it before choosing the next one.
            if screenshot and recent and await llm.has_vision(s.model):
                recent[-1]["images"] = [screenshot]
            screenshot = None
            messages = [{"role": "system", "content": system_prompt(s)}, *recent]
            async for chunk in llm.chat(s.model, messages, sig, {"stop": ["[TOOL RESULTS]"]}, stats):
                parser.push(chunk)
                if st["halluc"]:
                    break
            if not st["halluc"]:
                parser.end()
            if turn != s.turn:
                return
            s.send({"type": "stats", **stats, "model": stats.get("fallback") or s.model})
            # About to say it's done after working the screen: first make her check the screenshot against every part
            # of the request. Catches "sent" when it wasn't, or a forgotten follow.
            if not actions and screen_acts and not checked:
                checked = True
                speech.buf = ""
                s.history.push({
                    "role": "user", "compact": "[TOOL RESULTS]\n(checked the screen before finishing)",
                    "content": ("[TOOL RESULTS]\nBefore you tell me it's done, check the attached screenshot (the screen right now). "
                                f"My request was: \"{user_text}\". Go through each part of it: does the screen actually show it happened (e.g. the button now says "
                                "Following, the message bubble is in the chat, the right person's chat is open)? If any part is missing or went to the wrong place, "
                                "do it now: write a 2-5 word status and the next action. If everything is really done, reply with ONE short sentence saying so.")})
                screenshot = last_shot
                continue
            if actions:
                status = spoken_status(speech.buf)
                speech.buf = ""
                if step > 0 and status:
                    speak(s, turn, status)
            else:
                speech.release()
            speech.flush()
            s.history.push({"role": "assistant", "content": st["kept"].strip() or "…"})
            if not actions:
                break

            s.send({"type": "token", "text": " ", "turn": turn})
            results, touched = [], False
            for a in actions:
                if turn != s.turn:
                    return
                # One tap at a time: after any screen action, the rest waits until she's seen the result.
                if touched:
                    results.append({"tool": a["tool"], "ok": False, "skipped": True, "error": "Not run yet: check the screen after every action first. Look at screen_now and the screenshot, then send this (or a better) next action."})
                    continue
                # Loop guard: small models sometimes repeat the same step forever.
                sg = a["tool"] + json.dumps(a.get("args") or {}, sort_keys=True)
                repeats = repeats + 1 if sg == last_sig else 0
                last_sig = sg
                action_count += 1
                if repeats >= 2 or action_count > 30:
                    results.append({"tool": a["tool"], "ok": False, "error": "Stopped: you keep repeating this action. Look at screen_now, try a different approach (scroll tool, click_element, a direct URL), or tell me what is blocking you."})
                    continue
                # Typing the same text twice in one task is the classic double-send.
                text = str((a.get("args") or {}).get("text") or "").strip() if a["tool"] == "type_text" else ""
                if text and text in typed:
                    results.append({"tool": a["tool"], "ok": False, "error": "Not typed: you already typed exactly this text in this task. Look at the screenshot: it is probably already in the box or already sent. If it is in the box, send it (press return or click the send mark); never type it twice."})
                    continue
                r = await run_tool(s, a, sig)
                if text and r.get("ok"):
                    typed.add(text)
                if r.get("screenshot"):
                    screenshot = last_shot = r.pop("screenshot")
                if a["tool"] in OBSERVE_AFTER:
                    touched = True
                    screen_acts += 1
                results.append({"tool": a["tool"], **r})
            if turn != s.turn:
                return
            compact = json.dumps([{k: v for k, v in r.items() if k != "screen_now"} for r in results], ensure_ascii=False)
            note = ("The attached image is the screen right now, after that action, with a numbered box on everything clickable. Check it: did the action do "
                    "what you meant? Is the right page, chat, popup or field showing? Only then pick the next action.\n") if screenshot else ""
            s.history.push({
                "role": "user", "compact": f"[TOOL RESULTS]\n{compact}",
                "content": f"[TOOL RESULTS]\n{json.dumps(results, indent=1, ensure_ascii=False)}\n{note}"
                           "If my request isn't fully done yet, continue with the next action now. When it is done, tell me the outcome in ONE short spoken sentence "
                           "with the actual facts and numbers (I can't see the output). While still working, write only a 2-5 word status of what you're doing now "
                           "(\"Opening her profile.\", \"Following her.\", \"Typing the message.\"), then the action. Never repeat an action that already succeeded."})
    except (llm.Cancelled, asyncio.CancelledError):
        return
    except Exception as e:
        if sig.aborted or turn != s.turn:
            return
        print("[turn error]", e)
        s.send({"type": "error", "message": str(e)})
        speak(s, turn, "Apologies. I'm having trouble reaching my language core.")
    finally:
        if turn == s.turn:
            s.send({"type": "busy", "busy": False, "turn": turn})


# ───────────────────────── dictation ─────────────────────────
async def dictate(s: Session, text: str):
    """Types the user's exact words into the focused field (no AI involved) and reads them back.
    Sending only happens when the user says "send it"."""
    turn = s.new_turn()
    if not text.strip():
        return
    r = await run_tool(s, {"tool": "type_text", "args": {"text": text}}, None, False)
    # Remember where the text went, so "send it" / "delete that" hit the same app.
    m = re.match(r"^Typed \d+ characters into (.+?) — ", r.get("message") or "") if r.get("ok") else None
    if m:
        s.dictation_app = m.group(1)
    if turn != s.turn:
        return
    end = "" if re.search(r"[.!?]$", text.strip()) else "."
    reply = f"Typed: {text}{end} Say send it when you're ready." if r.get("ok") else f"I couldn't type that. {r.get('error')}"
    s.send({"type": "token", "text": reply, "turn": turn})
    speak(s, turn, reply)


async def dictate_key(s: Session, key: str):
    turn = s.new_turn()
    app = s.dictation_app
    if not app:
        reply = "Dictate something first by saying type, followed by your message."
        s.send({"type": "token", "text": reply, "turn": turn})
        return speak(s, turn, reply)

    async def press(keys):
        return await run_tool(s, {"tool": "press_keys", "args": {"keys": keys, "app": app}}, None, False)
    if key == "clear":
        r = await press("cmd+a")
        r = await press("delete") if r.get("ok") else r
    else:
        r = await press(key)
    if turn != s.turn:
        return
    done = {"return": "Sent.", "shift+return": "New line.", "clear": "Cleared.", "option+delete": "Deleted the last word."}.get(key, "Done.")
    reply = done if r.get("ok") else f"That didn't work. {r.get('error')}"
    s.send({"type": "token", "text": reply, "turn": turn})
    speak(s, turn, reply)


# ───────────────────────── quick actions, direct commands, greeting ─────────────────────────
QUICK = {"media", "brightness", "dark_mode", "screenshot", "lock_screen", "battery", "system_status", "weather", "clipboard", "set_timer", "set_volume"}
SILENT = {"media", "brightness", "set_volume"}
DIRECT_TOOLS = {"click_element", "click", "scroll", "press_keys", "move_mouse", "drag", "type_text", "remember", "forget", "cancel_reminder", "cancel_timer",
                "set_reminder", "schedule_task", "add_watcher", "morning_briefing", "window", "gui_reset"}
DIRECT_CONFIRM = {"remember", "forget", "cancel_reminder", "set_reminder", "schedule_task", "add_watcher", "morning_briefing", "gui_reset"}


async def direct_do(s: Session, tool: str, args: dict):
    """Direct on-screen UI commands (tap/scroll/shortcut), run immediately, no LLM, no new tabs."""
    if tool not in DIRECT_TOOLS:
        return
    s.new_turn()
    r = await run_tool(s, {"tool": tool, "args": args}, None, False)
    if not r.get("ok"):
        notice(s, f"I couldn't do that. {r.get('error') or ''}".strip())
    elif tool in DIRECT_CONFIRM:
        notice(s, "Got it. I'll remember that." if tool == "remember" else (r.get("message") or "Done."))


async def quick(s: Session, tool: str, args: dict):
    """Toolkit buttons: run one tool directly, no LLM round-trip."""
    if tool not in QUICK:
        return
    r = await run_tool(s, {"tool": tool, "args": args}, None)
    if r.get("ok") and tool in SILENT:
        return
    notice(s, (r.get("message") or "Done.") if r.get("ok") else f"That didn't work. {r.get('error')}")


def greet(s: Session):
    h = datetime.now().hour
    part = "evening" if h < 5 else "morning" if h < 12 else "afternoon" if h < 18 else "evening"
    turn = s.new_turn()
    lines = store.profile_greetings()
    text = random.choice(lines) if lines else f"Good {part}, {s.title}. ULTRON here, all systems online. What are we doing today?"
    s.send({"type": "token", "text": text, "turn": turn})
    s.history.push({"role": "assistant", "content": text})
    speak(s, turn, text)


def transcript_lines() -> list:
    out = []
    for m in [m for m in store.CONVO if not m["content"].startswith("[TOOL RESULTS]")][-12:]:
        t = re.sub(r"<action>[\s\S]*?</action>|<think>[\s\S]*?</think>", "", m["content"])
        t = re.sub(r"^\(I talked over you and cut you off\.\) ", "", t)
        t = re.sub(r"\n\[Files I just sent you[\s\S]*$", "", t).strip()
        if t and t != "…":
            out.append({"who": "user" if m["role"] == "user" else "ultron", "text": t})
    return out


def install_hooks():
    sched.hooks.notice = notice
    sched.hooks.run_turn = run_turn
