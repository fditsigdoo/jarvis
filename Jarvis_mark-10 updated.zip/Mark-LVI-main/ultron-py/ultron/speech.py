"""Speech. Two persistent engines, both speaking the same line protocol
("<id>\\t<voice>\\t<out.wav>\\t<text>"):
  kokoro  Kokoro-82M neural TTS (tts/kokoro_server.py): smooth, natural voices.
  sys     System.Speech on Windows (tts/speak.ps1) or AVSpeechSynthesizer on the Mac (tts/speak.swift): instant, but robotic.
If an engine is missing or still loading, speech falls back to the next one, then to `say` on the Mac.
"""
from __future__ import annotations

import asyncio
import os
import re
import subprocess
import sys
import time
import json
import urllib.error
import urllib.request
from pathlib import Path

from . import settings
from .config import CONFIG, IS_WIN, KOKORO_PY, ROOT, SYS_VOICE, TTS_DIR, VOICES, clamp
from .proc import CREATE_NO_WINDOW, run

_CTRL = re.compile(r"[\t\n\r]+")
DEBUG = bool(os.environ.get("ULTRON_DEBUG"))


class Engine:
    """A long-running speech helper process talking the line protocol."""

    def __init__(self, name: str, cmd: str, args: list):
        self.name = name
        self.ready = False
        self.gave_up = False
        self.proc: subprocess.Popen | None = None
        self.waiters: dict = {}
        self.seq = 0
        self._ready_ev: asyncio.Event | None = None
        self._loop = asyncio.get_running_loop()
        self._ready_ev = asyncio.Event()
        try:
            self.proc = subprocess.Popen([cmd, *args], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                         creationflags=CREATE_NO_WINDOW if IS_WIN else 0)
        except OSError as e:
            print(f"  {name} voice engine failed to start ({e})")
            return
        import threading
        threading.Thread(target=self._read_stdout, args=(self.proc,), daemon=True).start()
        threading.Thread(target=self._drain_stderr, args=(self.proc,), daemon=True).start()

    # Reader threads hand results back to the event loop.
    def _read_stdout(self, p):
        for raw in p.stdout:
            line = raw.decode("utf8", "replace").strip()
            self._loop.call_soon_threadsafe(self._on_line, line)
        self._loop.call_soon_threadsafe(self._on_exit, p)

    def _drain_stderr(self, p):
        # Always drain stderr, or a chatty engine blocks once the pipe buffer fills.
        for raw in p.stderr:
            if DEBUG:
                sys.stderr.write(raw.decode("utf8", "replace"))

    def _on_line(self, line: str):
        if line == "ready":
            self.ready = True
            self._ready_ev.set()
            print(f"  {self.name} voice engine ready")
            return
        parts = line.split(" ")
        fut = self.waiters.pop(parts[0], None)
        if fut and not fut.done():
            fut.set_result(len(parts) > 1 and parts[1] == "ok")

    def _on_exit(self, p):
        if self.proc is not p:
            return
        print(f"  {self.name} voice engine exited ({p.poll()})")
        self.proc = None
        self.ready = False
        for f in self.waiters.values():
            if not f.done():
                f.set_result(False)
        self.waiters.clear()

    async def wait_ready(self, timeout: float):
        try:
            await asyncio.wait_for(self._ready_ev.wait(), timeout)
        except asyncio.TimeoutError:
            pass

    async def synth(self, fields: list, out: str, text: str) -> bool:
        """fields: leading tab-separated columns (voice, and engine-specific speed/pitch) before out+text."""
        if not self.proc or not self.ready:
            return False
        self.seq += 1
        i = str(self.seq)
        fut = self._loop.create_future()
        self.waiters[i] = fut
        try:
            flat = _CTRL.sub(" ", text)
            line = f"{i}\t" + "\t".join(str(f) for f in fields) + f"\t{out}\t{flat}\n"
            self.proc.stdin.write(line.encode("utf8"))
            self.proc.stdin.flush()
        except (OSError, ValueError):
            self.waiters.pop(i, None)
            return False
        try:
            return await asyncio.wait_for(fut, 20)
        except asyncio.TimeoutError:
            self.waiters.pop(i, None)
            return False

    def kill(self):
        if self.proc:
            try:
                self.proc.kill()
            except OSError:
                pass


engines: dict = {}


async def ensure_swift_helper(src: Path, binp: Path) -> None:
    if binp.exists() and binp.stat().st_mtime >= src.stat().st_mtime:
        return
    print("  compiling macOS speech engine…")
    r = await run("swiftc", ["-O", str(src), "-o", str(binp)], timeout=300)
    if r["code"] != 0:
        raise OSError(r["stderr"] or "swiftc failed")


async def start_engines():
    if IS_WIN:
        engines["sys"] = Engine("Windows", "powershell.exe", ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", str(ROOT / "tts" / "speak.ps1")])
    elif sys.platform == "darwin":
        try:
            binp = ROOT / "tts" / "speak"
            await ensure_swift_helper(ROOT / "tts" / "speak.swift", binp)
            engines["sys"] = Engine("macOS", str(binp), ["Daniel", str(CONFIG["speech_rate"])])
        except OSError:
            print("  (swiftc unavailable — macOS voice will use `say`)")
    if KOKORO_PY.exists():
        print("  loading Kokoro neural voice…")
        engines["kokoro"] = Engine("Kokoro", str(KOKORO_PY), [str(ROOT / "tts" / "kokoro_server.py")])
    else:
        print(f"  (Kokoro not installed — run {'setup-voice.bat' if IS_WIN else './setup-voice.sh'} for the smooth neural voice)")


def stop_engines():
    for e in engines.values():
        e.kill()


def default_voice() -> str:
    sysname = SYS_VOICE.split(":")[0]
    v = CONFIG["voice"]
    if ":" not in v:
        v = f"kokoro:{v}" if re.match(r"^[a-z][fm]_", v) else f"{sysname}:{v}"
    if v.startswith("kokoro:") and not KOKORO_PY.exists():
        return SYS_VOICE
    return v if any(x["id"] == v for x in VOICES) or v.startswith(f"{sysname}:") else SYS_VOICE


async def say_fallback(text: str, out: str, voice: str, rate: float, pitch: float) -> bool:
    wpm = round(CONFIG["rate"] * rate)
    r = await run("say", ["-v", voice, "-r", str(wpm), "-o", out, "--data-format=LEI16@22050", "-f", "-"],
                  input=f"[[pbas {round(50 * pitch)}]] {text}")   # pbas = baseline pitch
    return r["code"] == 0


_tts_seq = 0


# ───────────────────────── cloud voices (ElevenLabs, OpenAI) ─────────────────────────
ELEVEN_DEFAULT_MODEL = "eleven_flash_v2_5"
OPENAI_TTS_VOICES = ["alloy", "ash", "ballad", "coral", "echo", "fable", "nova", "onyx", "sage", "shimmer"]


def _tts_key(engine: str) -> str:
    S = settings.get()
    return (S["tts"]["api_key"] or (S["llm"]["keys"].get("openai") if engine == "openai" else "") or "").strip()


def _cloud_request(text: str, speed: float) -> tuple[bytes, str]:
    """One blocking HTTP call (runs in a worker thread). Returns (audio bytes, file extension)."""
    T = settings.get()["tts"]
    engine = T["engine"]
    key = _tts_key(engine)
    if not key:
        raise RuntimeError(f"No API key for {engine} voice (Settings → Voice)")
    if engine == "elevenlabs":
        if not T["voice_id"]:
            raise RuntimeError("Pick an ElevenLabs voice id (Settings → Voice)")
        url = f"https://api.elevenlabs.io/v1/text-to-speech/{urllib.request.quote(T['voice_id'], safe='')}?output_format=mp3_44100_128"
        body = {"text": text, "model_id": T["model"] or ELEVEN_DEFAULT_MODEL}
        headers = {"xi-api-key": key}
    else:   # openai (or anything that speaks /audio/speech)
        base = (T["base_url"] or "https://api.openai.com/v1").rstrip("/")
        url = f"{base}/audio/speech"
        body = {"model": T["model"] or "gpt-4o-mini-tts", "voice": T["voice_id"] or "alloy", "input": text, "response_format": "mp3", "speed": clamp(speed, 0.5, 2)}
        headers = {"Authorization": f"Bearer {key}"}
    req = urllib.request.Request(url, data=json.dumps(body).encode(), headers={"content-type": "application/json", **headers}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=40) as r:
            return r.read(), "mp3"
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"{engine} voice {e.code}: {e.read().decode('utf8', 'replace')[:160]}") from None


async def cloud_synth(text: str, speed: float, name_stub: str) -> dict | None:
    try:
        data, ext = await asyncio.get_running_loop().run_in_executor(None, _cloud_request, text, speed)
    except Exception as e:
        print(f"  ⚠ cloud voice: {e} — using the built-in voice")
        return None
    name = f"{name_stub}.{ext}"
    (TTS_DIR / name).write_bytes(data)
    return {"url": f"/tts/{name}", "rate": 1}


async def test_cloud() -> dict:
    T = settings.get()["tts"]
    if T["engine"] == "local":
        return {"ok": True, "message": "Built-in voice (nothing to test)."}
    r = await cloud_synth("Voice check.", 1, f"test-{int(time.time() * 1000)}")
    return {"ok": bool(r), "message": "Voice works." if r else "The voice service refused or couldn't be reached. See the console."}


async def list_eleven_voices() -> list:
    key = _tts_key("elevenlabs")
    if not key:
        return []

    def go():
        req = urllib.request.Request("https://api.elevenlabs.io/v1/voices", headers={"xi-api-key": key})
        with urllib.request.urlopen(req, timeout=10) as r:
            return json.loads(r.read().decode("utf8", "replace"))
    try:
        j = await asyncio.get_running_loop().run_in_executor(None, go)
        return [{"id": v["voice_id"], "label": v.get("name", v["voice_id"])} for v in j.get("voices", [])]
    except Exception:
        return []




async def synth(text: str, voice_id: str, pitch: float = 1, speed: float = 1) -> dict | None:
    """pitch/speed are independent: Kokoro's `speed` sets tempo (pitch-preserving); the residual pitch
    shift is applied in the browser via playbackRate, and the Kokoro speed is pre-divided by pitch so
    the net tempo stays exactly `speed`. The system voices shift pitch natively."""
    global _tts_seq
    _tts_seq += 1
    stub = f"{int(time.time() * 1000)}-{_tts_seq}"
    if settings.get()["tts"]["engine"] != "local":
        r = await cloud_synth(text, speed, stub)
        if r:
            return r
    name = f"{stub}.wav"
    out = str(TTS_DIR / name)
    engine, _, voice = voice_id.partition(":")
    sys_voice = voice if engine in ("mac", "win") else SYS_VOICE.split(":")[1]
    ok, rate = False, 1
    k = engines.get("kokoro")
    if engine == "kokoro" and k and k.proc:
        if not k.ready and not k.gave_up:
            await k.wait_ready(12)
            if not k.ready:
                k.gave_up = True
        ok = await k.synth([voice, f"{clamp(speed / pitch, 0.5, 2):.3f}"], out, text)
        if ok:
            rate = pitch   # browser lifts/drops pitch; tempo already compensated
    s = engines.get("sys")
    if not ok and s:
        ok = await s.synth([sys_voice, f"{CONFIG['speech_rate'] * speed:.3f}", f"{pitch:.3f}"], out, text)
    if not ok and not IS_WIN:
        ok = await say_fallback(text, out, sys_voice, speed, pitch)
    return {"url": f"/tts/{name}", "rate": rate} if ok else None


async def cleanup_loop():
    """Clean up old audio files."""
    while True:
        await asyncio.sleep(60)
        cutoff = time.time() - 600
        for f in TTS_DIR.iterdir():
            try:
                if f.stat().st_mtime < cutoff:
                    f.unlink()
            except OSError:
                pass


_PICTO = re.compile("[\U0001F300-\U0001FAFF\U00002600-\U000027BF\U0001F000-\U0001F2FF\U0000FE0F\U0000200D]")


def clean_for_speech(t: str) -> str:
    t = re.sub(r"https?://\S+", " link ", t)
    t = re.sub(r"[*_#>`~|\[\]{}]", " ", t)
    t = _PICTO.sub("", t)
    return re.sub(r"\s+", " ", t).strip()


def speak(s, turn: int, text: str):
    clean = clean_for_speech(text)
    if not clean or not re.search(r"[^\W_]", clean) or not s.tts:
        return
    job = asyncio.ensure_future(synth(clean, s.voice, s.pitch, s.speed))   # parallel; delivered in order
    prev = s.tts_chain

    async def deliver():
        try:
            await prev
        except Exception:
            pass
        r = await job
        if r and turn == s.turn:
            s.send({"type": "audio", "url": r["url"], "rate": r["rate"], "turn": turn})
        if s.native and turn == s.turn:
            s.phone_log(f'Mac: sent voice clip "{text[:40]}"{"" if r else " (speech FAILED)"}')
    s.tts_chain = asyncio.ensure_future(deliver())


class Speech:
    """Splits streamed text into sentences so speech starts before the reply finishes."""
    _END = re.compile(r"[.!?]+(?=\s)|\n")

    def __init__(self, s, turn: int, hold: bool = False):
        self.s, self.turn, self.buf, self.hold = s, turn, "", hold

    def add(self, t: str):
        self.buf += t
        if self.hold:
            return
        while True:
            cut = -1
            for m in self._END.finditer(self.buf):
                end = m.end()
                if end >= 14 or m.group(0) == "\n":
                    cut = end
                    break
            if cut < 0:
                break
            speak(self.s, self.turn, self.buf[:cut])
            self.buf = self.buf[cut:]

    def flush(self):
        if not self.hold:
            speak(self.s, self.turn, self.buf)
        self.buf = ""

    def release(self):
        t, self.buf, self.hold = self.buf, "", False
        self.add(t)
        self.flush()
