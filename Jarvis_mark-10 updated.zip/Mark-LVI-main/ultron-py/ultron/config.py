"""Settings, constants and small helpers shared by everything else."""
from __future__ import annotations

import os
import re
import sys
import time
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
IS_WIN = sys.platform == "win32"
IS_MAC = sys.platform == "darwin"
HOST = "PC" if IS_WIN else "Mac"   # what the machine is called in prompts and messages


def _num(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, "")) or default
    except ValueError:
        return default


CONFIG = {
    "port": int(_num("PORT", 7777)),
    "ollama": os.environ.get("ULTRON_OLLAMA_URL", "http://127.0.0.1:11434").rstrip("/"),
    "model": os.environ.get("ULTRON_MODEL", ""),   # filled in by llm.py once it knows about a Gemini key
    "fallback_model": os.environ.get("ULTRON_FALLBACK_MODEL", "gemma3:12b"),
    "vision_model": os.environ.get("ULTRON_VISION_MODEL", "gemma3:12b"),
    "coder_model": os.environ.get("ULTRON_CODER_MODEL", ""),   # empty = use the active chat model
    "voice": os.environ.get("ULTRON_VOICE", "kokoro:af_heart"),   # kokoro:<voice>, win:<voice> or mac:<voice>
    "rate": _num("ULTRON_RATE", 188),                 # words/min for the `say` fallback
    "speech_rate": _num("ULTRON_SPEECH_RATE", 0.52),  # 0..1 for the native speech engines
    "title": os.environ.get("ULTRON_TITLE", "boss"),
    "auto_approve": os.environ.get("ULTRON_AUTO_APPROVE") != "0",
}

# One context size for every call; changing num_ctx makes Ollama reload the model.
NUM_CTX = int(_num("ULTRON_NUM_CTX", 16384))

PUBLIC = ROOT / "public"
VENDOR = ROOT / "vendor"
TTS_DIR = ROOT / ".tts"
SITES = ROOT / "sites"
WORKSPACE = ROOT / "workspace"
MEM_DIR = ROOT / "memory"
OUTBOX_DIR = ROOT / ".outbox"
INBOX = Path.home() / "Downloads" / "ULTRON"
PROMPTS = Path(__file__).resolve().parent / "prompts"
for _d in (TTS_DIR, SITES, WORKSPACE, MEM_DIR):
    _d.mkdir(parents=True, exist_ok=True)

KOKORO_PY = ROOT / "tts" / "venv" / ("Scripts/python.exe" if IS_WIN else "bin/python")
# The built-in voice when Kokoro isn't installed: System.Speech on Windows, AVSpeechSynthesizer on the Mac.
SYS_VOICE = "win:default" if IS_WIN else "mac:Daniel"

_KOKORO = [
    ("bm_george", "George · British male"), ("bm_fable", "Fable · British male"),
    ("bm_lewis", "Lewis · British male"), ("bm_daniel", "Daniel · British male"),
    ("am_michael", "Michael · American male"), ("am_fenrir", "Fenrir · American male"),
    ("am_puck", "Puck · American male"), ("bf_emma", "Emma · British female"),
    ("bf_isabella", "Isabella · British female"), ("af_heart", "Heart · American female"),
    ("af_bella", "Bella · American female"),
]
VOICES = [{"id": f"kokoro:{v}", "label": label} for v, label in _KOKORO] + [
    {"id": "win:default", "label": "Windows voice (classic)"} if IS_WIN
    else {"id": "mac:Daniel", "label": "Daniel · macOS (classic)"}
]

MIME = {
    ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".mjs": "text/javascript; charset=utf-8",
    ".css": "text/css; charset=utf-8", ".json": "application/json", ".wav": "audio/wav", ".svg": "image/svg+xml",
    ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif", ".webp": "image/webp",
    ".heic": "image/heic", ".ico": "image/x-icon", ".webmanifest": "application/manifest+json",
    ".pdf": "application/pdf", ".txt": "text/plain; charset=utf-8", ".md": "text/plain; charset=utf-8",
    ".zip": "application/zip", ".mp3": "audio/mpeg", ".m4a": "audio/mp4", ".mp4": "video/mp4", ".mov": "video/quicktime",
}


def mime_of(name: str) -> str:
    return MIME.get(os.path.splitext(name)[1].lower(), "application/octet-stream")


# URL prefix -> folder. Same layout node_modules had, so the UI's import map is unchanged.
MOUNTS = [
    ("/vendor/three/", VENDOR / "three" / "build"),
    ("/vendor/three-addons/", VENDOR / "three" / "examples" / "jsm"),
    ("/vendor/xterm/", VENDOR / "@xterm"),
    ("/tts/", TTS_DIR),
    ("/sites/", SITES),
    ("/", PUBLIC),
]

# The UI shell is public (no secrets in it); everything else needs this machine or a paired phone.
OPEN_PATHS = re.compile(
    r"^/(?:index\.html|app\.js|orb\.js|ultron\.js|deck\.js|sfx\.js|settings\.js|earth-data\.js|face\.js|face-mesh\.js|style\.css|"
    r"manifest\.webmanifest|icon\.svg|icon-180\.png|vendor/.*|api/whoami|api/pair)$")

# The model and the UI still think in Mac app names; these are the names the machine itself uses.
APP_ALIASES = {
    "vscode": "Visual Studio Code", "vs code": "Visual Studio Code", "code": "Visual Studio Code",
    "visual studio": "Visual Studio Code", "chrome": "Google Chrome", "google": "Google Chrome",
    "settings": "System Settings", "system preferences": "System Settings", "mail": "Mail",
    "messages": "Messages", "music": "Music", "terminal": "Terminal", "finder": "Finder",
}

DANGEROUS = re.compile("|".join([
    r"\brm\s+(-\w+\s+)*(\/|~|\$HOME)(\/?\*?)?(\s|$)",
    r"\b(sudo|mkfs|shutdown|reboot|halt)\b",
    r"\bdiskutil\s+(erase|zero|partition|reformat)",
    r"\bdd\b.*\bof=\/dev\/",
    r":\(\)\s*\{",
    r">\s*\/dev\/disk",
    r"\bcsrutil\b",
    # Windows
    r"(^|[;&|]\s*)(format\s+[a-z]:|diskpart|bcdedit)",
    r"\bcipher\s+\/w|\bvssadmin\s+delete",
    r"\b(Stop-Computer|Restart-Computer|Clear-Disk|Format-Volume|Remove-Partition|Initialize-Disk)\b",
    r"\b(Remove-Item|rm|del|rd|rmdir|erase|ri)\b[^;|&]*\s['\"]?([a-z]:\\?|\$env:(USERPROFILE|SystemRoot|windir|HOMEDRIVE)\\?|~\\?)['\"]?(\s|$)",
    r"\breg(\.exe)?\s+delete\s+HKLM",
    r"\b(Start-Process\b.*-Verb\s+RunAs|runas)\b",
]), re.I)

# iOS lets nothing tap or type inside other apps, so controlling the phone means opening apps,
# deep links and running the user's Shortcuts.
PHONE_APPS = {
    "spotify": "spotify:", "youtube": "youtube://", "instagram": "instagram://app", "whatsapp": "whatsapp://",
    "tiktok": "snssdk1233://", "snapchat": "snapchat://", "telegram": "tg://", "messenger": "fb-messenger://",
    "facebook": "fb://", "x": "twitter://", "twitter": "twitter://", "discord": "discord://", "netflix": "nflx://",
    "gmail": "googlegmail://", "chrome": "googlechrome://", "google maps": "comgooglemaps://", "linkedin": "linkedin://",
    "slack": "slack://", "zoom": "zoomus://", "uber": "uber://", "shazam": "shazam://", "maps": "maps://",
    "apple maps": "maps://", "music": "music://", "apple music": "music://", "messages": "sms:", "phone": "tel:",
    "mail": "message://", "calendar": "calshow://", "notes": "mobilenotes://", "facetime": "facetime://",
    "app store": "itms-apps://", "shortcuts": "shortcuts://", "photos": "photos-redirect://", "podcasts": "podcasts://",
    "books": "ibooks://", "wallet": "shoebox://", "settings": "App-prefs:", "safari": "x-web-search://",
}

IPHONE_MODELS = {
    "iPhone10,3": "iPhone X", "iPhone10,6": "iPhone X", "iPhone11,2": "iPhone XS", "iPhone11,6": "iPhone XS Max",
    "iPhone11,8": "iPhone XR", "iPhone12,1": "iPhone 11", "iPhone12,3": "iPhone 11 Pro", "iPhone12,5": "iPhone 11 Pro Max",
    "iPhone13,2": "iPhone 12", "iPhone13,3": "iPhone 12 Pro", "iPhone13,4": "iPhone 12 Pro Max", "iPhone14,5": "iPhone 13",
    "iPhone14,2": "iPhone 13 Pro", "iPhone14,3": "iPhone 13 Pro Max", "iPhone14,7": "iPhone 14", "iPhone15,2": "iPhone 14 Pro",
    "iPhone15,3": "iPhone 14 Pro Max", "iPhone15,4": "iPhone 15", "iPhone16,1": "iPhone 15 Pro", "iPhone16,2": "iPhone 15 Pro Max",
    "iPhone17,3": "iPhone 16", "iPhone17,1": "iPhone 16 Pro", "iPhone17,2": "iPhone 16 Pro Max",
}


def now_ms() -> int:
    return int(time.time() * 1000)


def sha(text) -> str:
    return hashlib.sha256(str(text).encode()).hexdigest()


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def slugify(s) -> str:
    return re.sub(r"^-+|-+$", "", re.sub(r"[^a-z0-9]+", "-", str(s or "").lower()))[:40]


def app_name(n) -> str:
    n = str(n or "").strip()
    return APP_ALIASES.get(n.lower(), n)


def expand_path(p, base: Path | str = WORKSPACE) -> Path:
    p = str(p or "").strip()
    if p.startswith("~"):
        p = str(Path.home()) + p[1:]
    return (Path(base) / p).resolve() if not os.path.isabs(p) else Path(p).resolve()


def normalize_url(u) -> str:
    u = str(u or "").strip()
    if not re.match(r"^https?://", u, re.I):
        u = "https://" + u.lstrip("/")
    return u


def has_xy(x, y) -> bool:
    try:
        float(x), float(y)
    except (TypeError, ValueError):
        return False
    return x != "" and y != ""


def num(v, default=0.0) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return default
