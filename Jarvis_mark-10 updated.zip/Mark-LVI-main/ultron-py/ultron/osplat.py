"""Picks the operating-system module once, so the rest of the code says plat.open_app(...)
and never asks which OS it is on. Windows is the primary target; macOS implements the same functions."""
from __future__ import annotations

import sys

if sys.platform == "win32":
    from .winutil import *          # noqa: F401,F403
    from .winutil import win_combo  # noqa: F401
else:
    from .macutil import *          # noqa: F401,F403
