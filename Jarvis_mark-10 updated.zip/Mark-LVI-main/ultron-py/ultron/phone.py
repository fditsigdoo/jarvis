"""Phone link: pairing, which phones are connected, calls (APNs VoIP push) and files in both directions.

The phone opens this same UI over Tailscale. This server can run anything on the computer, so every
request that doesn't come from the computer itself needs a paired device token.
"""
from __future__ import annotations

import asyncio
import base64
import json
import os
import re
import secrets
import socket
import time
from pathlib import Path

from . import store
from .config import HOST, INBOX, MEM_DIR, OUTBOX_DIR, expand_path, mime_of, now_ms, sha
from . import osplat as plat

PHONE_LINKS: list = []        # where the phone can reach this computer, filled in at startup
pairing: dict | None = None   # {code, expires, tries} while a pairing code is showing on the computer
MAC_NAME = socket.gethostname().split(".")[0] or HOST


def set_machine_name(n: str):
    global MAC_NAME
    MAC_NAME = n


def phones() -> list:
    return [c for c in store.clients if c.remote]


def iphone_apps() -> list:
    return [c for c in store.clients if c.native]


def phone_name(c) -> str:
    return getattr(c, "phone_name", None) or (c.device or {}).get("name") or "iPhone"


def squash(t) -> str:
    return re.sub(r"[^a-z0-9]", "", re.sub(r"^(?:my|the)\s+", "", str(t or "").lower()))


def _find_named(pairs: list, q: str):
    return next((c for c, n in pairs if n == q), None) or next((c for c, n in pairs if n.startswith(q)), None) \
        or next((c for c, n in pairs if q in n), None)


def iphone_named(name):
    """The iPhone app session for "iPhone X" / "the 13" / "x"; None if none of the connected ones match."""
    q = re.sub(r"^iphone", "", squash(name))
    if not q:
        return None
    return _find_named([(c, re.sub(r"^iphone", "", squash(phone_name(c)))) for c in iphone_apps()], q)


def phone_target(s, name=None):
    """Which phone an action goes to: the one named, else the phone you're talking from, else the latest."""
    if name:
        return iphone_named(name)
    if s.remote:
        return s
    p = phones()
    return p[-1] if p else None


def online_phones() -> str:
    return ", ".join(phone_name(c) for c in iphone_apps())


def device_named(name):
    """A paired iPhone that can be woken by push ("iPhone X", "the 13"...), online or not."""
    q = re.sub(r"^iphone", "", squash(name))
    if not q:
        return None
    return _find_named([(d, re.sub(r"^iphone", "", squash(d["name"]))) for d in store.DEVICES if d.get("voipToken")], q)


# ───────────────────────── pairing ─────────────────────────
def start_pairing() -> dict:
    global pairing
    pairing = {"code": f"{secrets.randbelow(10**6):06d}", "expires": now_ms() + 5 * 60000, "tries": 0}
    broadcast_devices()
    return pairing


def pair_device(code, name) -> dict:
    global pairing
    if not pairing or now_ms() > pairing["expires"]:
        return {"ok": False, "error": f"No pairing code is active. On the {HOST}, open Phone link and press Pair a phone."}
    if str(code or "").strip() != pairing["code"]:
        pairing["tries"] += 1
        if pairing["tries"] >= 5:   # no brute-forcing six digits
            pairing = None
        broadcast_devices()
        return {"ok": False, "error": "Wrong code"}
    pairing = None
    token = secrets.token_urlsafe(32)
    device = {"id": secrets.token_hex(6), "name": str(name or "Phone")[:60], "hash": sha(token), "paired": now_ms(), "seen": now_ms()}
    store.DEVICES.append(device)
    store.save_devices()
    broadcast_devices()
    return {"ok": True, "token": token, "name": device["name"]}


def revoke_device(dev_id: str):
    store.DEVICES[:] = [d for d in store.DEVICES if d["id"] != dev_id]
    store.save_devices()
    for c in list(store.clients):
        if c.device and c.device["id"] == dev_id:
            c.close()
    broadcast_devices()


def device_by_token(token: str | None):
    if not token:
        return None
    h = sha(token)
    return next((d for d in store.DEVICES if d["hash"] == h), None)


def broadcast_devices():
    lst = [{**{k: v for k, v in d.items() if k != "hash"}, "online": any(c.device and c.device["id"] == d["id"] for c in store.clients)}
           for d in store.DEVICES]
    code = {"code": pairing["code"], "expires": pairing["expires"]} if pairing and pairing["expires"] > now_ms() else None
    for c in list(store.clients):
        if not c.remote:
            c.send({"type": "devices", "list": lst, "pairing": code, "links": PHONE_LINKS})


# ───────────────────────── VoIP push (APNs): rings a locked iPhone, or one whose app is closed ─────────────────────────
# memory/apns.json: {"keyId": "...", "teamId": "YOURTEAMID", "keyFile": "apns-key.p8", "bundle": "com.example.ultron", "sandbox": true}
APNS: dict | None = None
try:
    APNS = json.loads((MEM_DIR / "apns.json").read_text("utf8"))
    APNS["key"] = (MEM_DIR / APNS["keyFile"]).resolve().read_text("utf8")
except (OSError, ValueError, KeyError):
    APNS = None

_apns_jwt: tuple | None = None


def _b64u(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def apns_auth() -> str:
    global _apns_jwt
    if _apns_jwt and time.time() - _apns_jwt[1] < 40 * 60:   # Apple wants a fresh one at least hourly
        return _apns_jwt[0]
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.hazmat.primitives.asymmetric.utils import decode_dss_signature
    head = f"{_b64u(json.dumps({'alg': 'ES256', 'kid': APNS['keyId']}).encode())}.{_b64u(json.dumps({'iss': APNS['teamId'], 'iat': int(time.time())}).encode())}"
    key = serialization.load_pem_private_key(APNS["key"].encode(), None)
    r, s = decode_dss_signature(key.sign(head.encode(), ec.ECDSA(hashes.SHA256())))
    _apns_jwt = (f"{head}.{_b64u(r.to_bytes(32, 'big') + s.to_bytes(32, 'big'))}", time.time())
    return _apns_jwt[0]


async def voip_push(token: str, payload: dict) -> dict:
    try:
        import httpx   # pip install "httpx[http2]"  (only needed for ringing a locked iPhone)
    except ImportError:
        return {"ok": False, "error": 'push calls need: pip install "httpx[http2]"'}
    host = APNS.get("host") or ("https://api.push.apple.com" if APNS.get("sandbox") is False else "https://api.sandbox.push.apple.com")
    try:
        async with httpx.AsyncClient(http2=True, timeout=10) as c:
            r = await c.post(f"{host}/3/device/{token}", content=json.dumps(payload), headers={
                "authorization": f"bearer {apns_auth()}", "apns-topic": f"{APNS.get('bundle') or 'com.example.ultron'}.voip",
                "apns-push-type": "voip", "apns-priority": "10", "apns-expiration": "0"})
        if r.status_code == 200:
            return {"ok": True}
        try:
            return {"ok": False, "error": r.json().get("reason")}
        except ValueError:
            return {"ok": False, "error": f"HTTP {r.status_code}"}
    except Exception as e:
        return {"ok": False, "error": str(e) or "Apple push failed"}


# ───────────────────────── files between the computer and the phone ─────────────────────────
# Phone -> computer lands in ~/Downloads/ULTRON. Computer -> phone goes through short-lived download links.
OUTBOX: dict = {}    # id -> file entry, for /files/<id>
FILES: list = []     # recent transfers in both directions, for the UI
MAX_UPLOAD = 2 * 1024 ** 3


def public_file(e: dict) -> dict:
    out = {k: v for k, v in e.items() if k != "file"}
    out["url"] = f"/files/{e['id']}" if e["dir"] == "to_phone" else None
    if e["dir"] == "to_mac":
        out["path"] = e["file"]
    return out


def record_file(entry: dict):
    FILES.insert(0, entry)
    del FILES[40:]
    for c in list(store.clients):
        c.send({"type": "files", "list": [public_file(f) for f in FILES]})


def unique_path(d: Path, name: str) -> Path:
    stem, ext = os.path.splitext(name)
    p, i = d / name, 1
    while p.exists():
        i += 1
        p = d / f"{stem} {i}{ext}"
    return p


async def send_to_phone(p, note: str = "") -> dict:
    full = expand_path(str(p or ""), Path.home())
    if not p or not full.exists():
        return {"ok": False, "error": f"Not found: {full}"}
    file, name = full, full.name
    if full.is_dir():
        OUTBOX_DIR.mkdir(exist_ok=True)
        file = OUTBOX_DIR / f"{secrets.token_hex(4)}-{name}.zip"
        r = await plat.zip_folder(str(full), str(file))
        if r["code"] != 0:
            return {"ok": False, "error": f"Couldn't zip the folder: {r['stderr'].strip()}"}
        name += ".zip"
    entry = {"id": secrets.token_urlsafe(12), "dir": "to_phone", "file": str(file), "name": name, "size": file.stat().st_size,
             "mime": mime_of(name), "time": now_ms(), "note": str(note or "")}
    OUTBOX[entry["id"]] = entry
    record_file(entry)
    ps = phones()
    for c in ps:
        c.send({"type": "file", "file": public_file(entry)})
    return {"ok": True, "message": f"Sent {name} to the phone" if ps else f"{name} is ready and shows up on the phone when it connects"}


async def outbox_cleanup_loop():
    """Outbox links last a day; zips made for folders are deleted with them."""
    while True:
        await asyncio.sleep(3600)
        for i, e in list(OUTBOX.items()):
            if now_ms() - e["time"] > 24 * 3600_000:
                OUTBOX.pop(i, None)
                if str(e["file"]).startswith(str(OUTBOX_DIR)):
                    try:
                        os.remove(e["file"])
                    except OSError:
                        pass
