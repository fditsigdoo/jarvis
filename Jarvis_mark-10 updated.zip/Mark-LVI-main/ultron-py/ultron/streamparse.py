"""Separates spoken text from <action>{json}</action>, <think>...</think> and ``` code fences
as the model streams, and turns an action body into {tool, args}."""
from __future__ import annotations

import json
from typing import Callable

BLOCKS = [
    {"open": "<action>", "close": "</action>", "kind": "action"},
    {"open": "<think>", "close": "</think>", "kind": "think"},
    {"open": "```", "close": "```", "kind": "code"},
]


class StreamParser:
    def __init__(self, on_text: Callable[[str], None], on_block: Callable[[str, str], None]):
        self.on_text, self.on_block = on_text, on_block
        self.buf = ""
        self.block = None

    def push(self, chunk: str):
        self.buf += chunk
        self._process(False)

    def end(self):
        self._process(True)

    def _process(self, final: bool):
        while self.buf:
            if self.block:
                i = self.buf.find(self.block["close"])
                if i < 0:
                    if final:
                        self.on_block(self.block["kind"], self.buf)
                        self.buf = ""
                    return
                self.on_block(self.block["kind"], self.buf[:i])
                self.buf = self.buf[i + len(self.block["close"]):]
                self.block = None
                continue
            best, at = None, float("inf")
            for b in BLOCKS:
                i = self.buf.find(b["open"])
                if 0 <= i < at:
                    at, best = i, b
            if best:
                if at > 0:
                    self.on_text(self.buf[:at])
                self.buf = self.buf[at + len(best["open"]):]
                self.block = best
                continue
            if not final:
                # hold back a possible partial opener at the end of the buffer
                for k in range(min(8, len(self.buf)), 0, -1):
                    tail = self.buf[-k:]
                    if any(b["open"].startswith(tail) for b in BLOCKS):
                        if len(self.buf) > k:
                            self.on_text(self.buf[:-k])
                        self.buf = tail
                        return
            self.on_text(self.buf)
            self.buf = ""


def escape_control_in_strings(s: str) -> str:
    """LLMs sometimes put raw newlines inside JSON strings; escape them."""
    out, in_str, esc = [], False, False
    for ch in s:
        if in_str:
            if esc:
                esc = False
                out.append(ch)
            elif ch == "\\":
                esc = True
                out.append(ch)
            elif ch == '"':
                in_str = False
                out.append(ch)
            elif ch == "\n":
                out.append("\\n")
            elif ch == "\r":
                continue
            elif ch == "\t":
                out.append("\\t")
            else:
                out.append(ch)
        else:
            if ch == '"':
                in_str = True
            out.append(ch)
    return "".join(out)


def parse_action(body: str, is_tool: Callable[[str], bool]):
    import re
    t = re.sub(r"^json\s*", "", body.strip(), flags=re.I)
    a, b = t.find("{"), t.rfind("}")
    if a < 0 or b < a:
        return None
    try:
        j = json.loads(escape_control_in_strings(t[a:b + 1]))
    except Exception:
        return None
    if not isinstance(j, dict):
        return None
    key = next((k for k in ("tool", "action", "function", "name") if isinstance(j.get(k), str) and is_tool(j[k])), None)
    if not key:
        return None
    args = next((j[k] for k in ("args", "arguments", "parameters", "input") if j.get(k) is not None), None)
    if isinstance(args, str):
        try:
            args = json.loads(args)
        except Exception:
            args = {}
    if not isinstance(args, dict):
        args = {k: v for k, v in j.items() if k != key}
    return {"tool": j[key], "args": args}
