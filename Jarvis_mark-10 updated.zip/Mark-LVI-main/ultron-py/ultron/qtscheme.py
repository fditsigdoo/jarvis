"""The private ultron:// URL scheme. Kept apart from desktop.py because Qt wants it registered BEFORE the
QApplication exists, and a host app (JARVIS) has to do that without importing the whole agent."""
from __future__ import annotations

from PyQt6.QtWebEngineCore import QWebEngineUrlScheme

SCHEME = b"ultron"
_done = False


def register_scheme() -> None:
    global _done
    if _done:
        return
    scheme = QWebEngineUrlScheme(SCHEME)
    scheme.setSyntax(QWebEngineUrlScheme.Syntax.Host)
    flags = QWebEngineUrlScheme.Flag.SecureScheme | QWebEngineUrlScheme.Flag.LocalAccessAllowed | QWebEngineUrlScheme.Flag.CorsEnabled
    if hasattr(QWebEngineUrlScheme.Flag, "FetchApiAllowed"):
        flags |= QWebEngineUrlScheme.Flag.FetchApiAllowed
    scheme.setFlags(flags)
    QWebEngineUrlScheme.registerScheme(scheme)
    _done = True
