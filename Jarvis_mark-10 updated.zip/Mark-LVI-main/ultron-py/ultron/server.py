"""The backend core. No network server: the desktop window (desktop.py) calls these functions in-process.
Same endpoints and message protocol as before, so the UI in public/ works unchanged.

  handle_api(...)    what the UI's fetch('/api/...') used to hit
  serve_agent(sock)  what the UI's WebSocket('/ws') used to hit
  serve_term(sock)   what the UI's WebSocket('/term') used to hit
  startup()/shutdown() background loops and engines (was main())

`sock` is any object with the small Socket interface below (desktop.py provides it)."""
from __future__ import annotations

import asyncio
import json
import os
import platform as pyplatform
import re
import secrets
import socket
import subprocess
import sys
import threading
import time
from pathlib import Path

from . import agent, commands, control as ctl, llm, phone, scheduler as sched, settings, speech, stt, store, vendor_setup
from . import osplat as plat
from .config import CONFIG, HOST, INBOX, IPHONE_MODELS, IS_WIN, ROOT, VOICES, clamp, mime_of, now_ms
from .phone import MAX_UPLOAD


# ───────────────────────── in-process request / socket types ─────────────────────────
class Request:
    """What fetch('/api/...') sends. Everything comes from this computer's own window, so there is no pairing,
    origin or loopback check any more."""
    __slots__ = ("method", "path", "query", "body", "content_type")

    def __init__(self, method: str, path: str, query: dict | None = None, body: bytes = b"", content_type: str = ""):
        self.method, self.path, self.query, self.body, self.content_type = method.upper(), path, query or {}, body, content_type

    def json(self):
        return json.loads(self.body.decode("utf8") or "{}")


class Socket:
    """What a WebSocket was to the UI. desktop.BridgeSocket implements it over the Qt web channel."""
    closed: bool = False

    async def recv(self):   # next text message from the UI, or None once it is gone
        raise NotImplementedError

    def send_text(self, text: str): ...
    def send_bytes(self, data: bytes): ...
    def close(self): ...


def jres(code: int, obj):
    return code, obj


# ───────────────────────── HTTP ─────────────────────────
async def sysinfo() -> dict:
    import psutil
    nets = [{"name": n, "address": a.address} for n, lst in psutil.net_if_addrs().items() for a in lst
            if a.family == socket.AF_INET and not a.address.startswith("127.")]
    vm = psutil.virtual_memory()
    return {
        "host": socket.gethostname(), "user": os.environ.get("USERNAME") or os.environ.get("USER") or "user",
        "os": f"{pyplatform.system()} {pyplatform.release()}", "arch": pyplatform.machine(),
        "cpu": pyplatform.processor() or "cpu", "cores": psutil.cpu_count() or 1, "memGB": vm.total / 2 ** 30, "freeGB": vm.available / 2 ** 30,
        "node": "", "runtime": f"python {pyplatform.python_version()}", "nets": nets, "port": CONFIG["port"],
        "model": store.PREFS.get("model") or llm.default_model(), "ollama": CONFIG["ollama"],
        "shell": "powershell" if IS_WIN else os.environ.get("SHELL", "/bin/zsh"), "root": str(ROOT).replace(str(Path.home()), "~"),
    }


def _list_dir(d: Path) -> list:
    out = []
    for e in os.scandir(d):
        if e.name.startswith("."):
            continue
        try:
            is_dir = e.is_dir()
        except OSError:
            is_dir = False
        out.append({"name": e.name, "dir": is_dir})
    out.sort(key=lambda x: (not x["dir"], [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", x["name"])]))
    return out[:600]


async def receive_upload(req: Request):
    raw = re.sub(r"[\0:]", "_", os.path.basename(str(req.query.get("name", "")))).strip()
    INBOX.mkdir(parents=True, exist_ok=True)
    name = raw if raw and raw not in (".", "..") else f"Phone {time.strftime('%Y-%m-%d %H.%M.%S')}"
    dest = phone.unique_path(INBOX, name)
    size = len(req.body)
    try:
        if size > MAX_UPLOAD:
            raise ValueError("File too large (2 GB max)")
        dest.write_bytes(req.body)
    except (ValueError, OSError) as e:
        dest.unlink(missing_ok=True)
        return jres(400, {"ok": False, "error": str(e)})
    n = dest.name
    phone.record_file({"id": secrets.token_hex(6), "dir": "to_mac", "file": str(dest), "name": n, "size": size, "mime": mime_of(n), "time": now_ms()})
    ask = str(req.query.get("ask", "")).strip()
    ps = phone.phones()
    target = ps[-1] if ps else sched.hooks.last_session
    if ask and target and target.is_open():
        asyncio.ensure_future(agent.run_turn(target, f"{ask}\n[Files I just sent you, now saved on the Mac: {dest}]"))
    return jres(200, {"ok": True, "path": str(dest), "name": n, "size": size})


async def handle_api(req: Request):
    """Every /api/* call the UI makes. Returns (status, json-able)."""
    p = req.path
    if p == "/api/gui":
        return jres(200, store.GUI)
    if p == "/api/sysinfo":
        return jres(200, await sysinfo())
    if p == "/api/fs":   # the file browser beside the terminal
        d = Path(req.query.get("path") or Path.home()).resolve()
        base = {"path": str(d), "parent": str(d.parent), "home": str(Path.home())}
        try:
            return jres(200, {"ok": True, **base, "entries": await asyncio.get_running_loop().run_in_executor(None, _list_dir, d)})
        except PermissionError:
            return jres(200, {"ok": False, **base, "error": f"{'Windows' if IS_WIN else 'macOS'} has not given ULTRON access to this folder"})
        except OSError:
            return jres(200, {"ok": False, **base, "error": "That folder cannot be opened"})
    if p.startswith("/api/settings"):
        return await handle_settings(req, p)
    if p == "/api/stt" and req.method == "POST":
        return jres(200, await stt.transcribe(req.body, req.content_type or "audio/webm"))
    if p == "/api/whoami":   # always this computer itself; there is no remote device any more
        return jres(200, {"local": True, "paired": True, "device": None, "mac": phone.MAC_NAME})
    if p == "/api/pair":
        return jres(403, {"ok": False, "error": "Phone pairing needs the network server, which this desktop edition does not run"})
    if p == "/api/upload" and req.method == "POST":
        return await receive_upload(req)
    return jres(404, {"ok": False, "error": "Not found"})


def file_for(path: str):
    """URL path -> (file, mime) for /files/<id> (the outbox). Static files and /tts/ are served by desktop.py."""
    e = phone.OUTBOX.get(path[7:]) if path.startswith("/files/") else None
    if not e or not os.path.exists(e["file"]):
        return None
    return Path(e["file"]), e["mime"], e["name"]


# ───────────────────────── settings API ─────────────────────────
async def _engine_changed():
    """After the AI engine changed: every open window moves to the new default model."""
    model = llm.default_model()
    store.save_prefs({**store.PREFS, "model": model})
    cs = list(store.clients)
    for c in cs:
        c.model = model
    if cs:
        await commands.refresh_models(cs[0])
        llm.warm_up(model)


async def handle_settings(req: Request, p: str):
    if p == "/api/settings" and req.method == "GET":
        return jres(200, {"ok": True, "settings": settings.public(), "openai_voices": speech.OPENAI_TTS_VOICES})
    try:
        body = req.json() if req.body else {}
    except ValueError:
        body = {}
    if p == "/api/settings" and req.method == "POST":
        patch = body.get("settings") if isinstance(body.get("settings"), dict) else {}
        before = (settings.get()["llm"]["provider"], settings.get()["llm"]["service"], settings.get()["llm"]["model"])
        settings.save(patch)
        L = settings.get()["llm"]
        if (L["provider"], L["service"], L["model"]) != before or "llm" in patch:
            await _engine_changed()
        for c in list(store.clients):
            c.send({"type": "settings_changed"})
        return jres(200, {"ok": True, "settings": settings.public()})
    if p == "/api/settings/forget" and req.method == "POST":
        settings.forget_key(str(body.get("section") or ""), str(body.get("service") or ""))
        return jres(200, {"ok": True, "settings": settings.public()})
    if p == "/api/settings/test" and req.method == "POST":
        what = body.get("target")
        if what == "llm":
            prov = settings.provider()
            if prov == "gemini":
                r = await llm.test_gemini()
            elif prov == "api":
                r = await llm.test_api()
            else:
                up = bool(await llm.list_models())
                r = {"ok": up, "message": "Ollama answered." if up else "Nothing answered. Is Ollama running?"}
        elif what == "stt":
            r = await stt.test()
        elif what == "tts":
            r = await speech.test_cloud()
        else:
            r = {"ok": False, "message": "Unknown test"}
        return jres(200, r)
    if p == "/api/settings/models" and req.method == "GET":
        return jres(200, {"ok": True, "models": await llm.list_models()})
    if p == "/api/settings/voices" and req.method == "GET":
        return jres(200, {"ok": True, "elevenlabs": await speech.list_eleven_voices(), "openai": speech.OPENAI_TTS_VOICES})
    return jres(404, {"ok": False, "error": "Not found"})


# ───────────────────────── the agent websocket ─────────────────────────
async def serve_agent(sock: Socket):
    """One UI window <-> the agent. Runs until the window closes."""
    loop = asyncio.get_running_loop()
    out: asyncio.Queue = asyncio.Queue()

    def send(obj):
        out.put_nowait(json.dumps(obj, ensure_ascii=False))

    async def pump():
        while True:
            msg = await out.get()
            if msg is None or sock.closed:
                return
            sock.send_text(msg)

    s = agent.Session(send, lambda: sock.close(), lambda: not sock.closed, False, None)
    s.attach_loop()
    store.clients.add(s)
    pump_task = loop.create_task(pump())
    phone.broadcast_devices()
    # Before anything async, so the conversation so far lands ahead of the greeting.
    s.send({"type": "hello", "remote": False, "device": None})
    s.send({"type": "transcript", "lines": agent.transcript_lines()})
    sched.hooks.last_session = s
    init = loop.create_task(_send_initial(s))
    try:
        while True:
            raw = await sock.recv()
            if raw is None:
                break
            try:
                m = json.loads(raw)
            except ValueError:
                continue
            if isinstance(m, dict):
                sched.hooks.last_session = s
                handle_message(s, m)
    finally:
        init.cancel()
        s.cancel()
        store.clients.discard(s)
        agent.hand_off(s, False)
        phone.broadcast_devices()
        out.put_nowait(None)
        await pump_task


async def _send_initial(s: agent.Session):
    s.send({"type": "models", "models": await llm.list_models(), "current": s.model, "coder": s.coder_model, "voices": VOICES,
            "voice": s.voice, "pitch": s.pitch, "speed": s.speed})
    sched.broadcast_timers()
    s.send({"type": "memory", "facts": store.MEM["facts"][-60:]})
    s.send({"type": "jobs", "list": store.jobs_public()})
    s.send({"type": "files", "list": [phone.public_file(f) for f in phone.FILES]})
    phone.broadcast_devices()


CALL_RE = re.compile(r"^(?:hey\s+)?(?:ultron[\s,]*)?(?:call|ring)\s+(?:me(?:\s+on)?|my|the)?\s*(?:(?:my|the)\s+)?((?:iphone|phone)?\s*(?:x[sr]?|\d{1,2})?(?:\s+pro)?(?:\s+max)?)?(?:\s+(?:now|please))?[.!]?$", re.I)


def _spawn(coro):
    return asyncio.ensure_future(coro)


def handle_message(s: agent.Session, m: dict):
    t = m.get("type")
    if t == "user":
        files = [f for f in (m.get("files") if isinstance(m.get("files"), list) else []) if isinstance(f, str)][:20]
        text = str(m.get("text") or "").strip()
        if not text and not files:
            return
        # "/provider groq", "/model ...", "/voice off"...: run instantly, no model involved.
        if not files and commands.is_command(text):
            async def run_cmd():
                try:
                    reply = await commands.run(s, text)
                except Exception as e:
                    reply = f"Command failed: {e}"
                s.send({"type": "notice", "text": reply, "kind": "cmd"})
            return _spawn(run_cmd())
        # "Call me" / "call my iPhone X" / "ring me on the 13" rings straight away, no model involved.
        call = None if files else CALL_RE.match(text)
        if call:
            which = (call.group(1) or "").strip()
            s.history.push({"role": "user", "content": text})

            async def ring():
                r = await agent.run_tool(s, {"tool": "call_me", "args": {"phone": which} if re.search(r"\d|x", which, re.I) else {}}, None)
                agent.notice(s, r["message"] if r.get("ok") else r.get("error", ""))
            return _spawn(ring())
        attached = f"\n[Files I just sent you, now saved on the Mac: {', '.join(files)}]" if files else ""
        _spawn(agent.run_turn(s, (text or "Sent you something.") + attached, bool(m.get("interrupted"))))
    elif t == "native":   # the iPhone app: takes calls, speaks with the computer's voice settings
        s.native = True
        _apply_prefs(s)
        model = str(m.get("model") or "")
        s.phone_name = IPHONE_MODELS.get(model) or (model if model.startswith("iPhone") else "iPhone")
        if s.device and s.device["name"] != s.phone_name and re.match(r"^(iphone( app)?|phone)$", s.device["name"], re.I):
            s.device["name"] = s.phone_name
            store.save_devices()
            phone.broadcast_devices()
    elif t == "history":
        s.send({"type": "transcript", "lines": agent.transcript_lines(), "replace": True})
    elif t == "call_answered":
        # Woken by push, this is a brand-new connection: the reason was kept on the device.
        pend = (s.device or {}).get("pendingCall")
        pending = pend["reason"] if pend and now_ms() - pend["t"] < 5 * 60000 else ""
        reason = s.call_reason or pending
        if s.device:
            s.device.pop("pendingCall", None)
        s.phone_log(f"Mac: call picked up, Ultron starts talking (voice output {'on' if s.tts else 'OFF'})")
        agent.hand_off(s, True)
        _spawn(agent.run_turn(s, f"(I picked up the phone call you placed to me{f'. You were calling about: {reason}' if reason else ''}. Talk.)"))
    elif t == "voip_token":
        tok = m.get("token")
        if s.device and isinstance(tok, str) and re.match(r"^[0-9a-f]{64,200}$", tok) and s.device.get("voipToken") != tok:
            s.device["voipToken"] = tok
            store.save_devices()
    elif t == "call_declined":
        s.history.push({"role": "user", "content": "(I declined your call.)"})
    elif t == "call_ended":
        s.new_turn()
        s.history.push({"role": "user", "content": "(I hung up.)"})
        agent.hand_off(s, False)
    # Pairing and revoking are computer-only, so a phone can't let in more devices.
    elif t == "pair_start":
        if not s.remote:
            phone.start_pairing()
    elif t == "device_revoke":
        if not s.remote:
            phone.revoke_device(str(m.get("id") or ""))
    elif t == "stop":
        s.new_turn()
        s.send({"type": "busy", "busy": False, "turn": s.turn})
    elif t == "reply":
        s.reply(m.get("id"), m.get("value"))
    elif t == "greet":
        agent.greet(s)
    elif t == "quick":
        _spawn(agent.quick(s, str(m.get("tool") or ""), m.get("args") or {}))
    elif t == "cancel_timer":
        sched.cancel_timers(lambda x: x["id"] == m.get("id"))
    elif t == "dictate":
        _spawn(agent.dictate(s, str(m.get("text") or "")))
    elif t == "dictate_key":
        _spawn(agent.dictate_key(s, str(m.get("key") or "")))
    elif t == "preview":
        speech.speak(s, s.new_turn(), "Voice matrix recalibrated. How do I sound?")
    elif t == "voice_test":
        turn = s.new_turn()
        line = str(m.get("text") or "")[:160] or "How's this?"
        s.send({"type": "token", "text": line, "turn": turn})
        speech.speak(s, turn, line)
    elif t == "wake":
        s.new_turn()

        async def wake():
            r = await agent.run_tool(s, {"tool": "wake_screen"}, None)
            if r.get("ok"):
                agent.notice(s, f"Welcome back, {s.title}.", "wake")
        _spawn(wake())
    elif t == "keep_awake":
        set_keep_awake(bool(m.get("on")))
    elif t == "do":
        _spawn(agent.direct_do(s, str(m.get("tool") or ""), m.get("args") or {}))
    elif t == "reset":
        store.CONVO.clear()
    elif t == "config":
        _apply_config(s, m)
    elif t == "client_log":
        if s.remote:
            s.phone_log(str(m.get("text") or "")[:300])   # the iPhone app's diagnostics


def _is_num(v) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _apply_config(s: agent.Session, m: dict):
    if isinstance(m.get("model"), str) and m["model"] and m["model"] != s.model:
        s.model = m["model"]
        llm.warm_up(m["model"])
    if isinstance(m.get("coderModel"), str):
        s.coder_model = m["coderModel"]
    if isinstance(m.get("tts"), bool):
        s.tts = m["tts"]
    if isinstance(m.get("autoApprove"), bool):
        s.auto_approve = m["autoApprove"]
    if any(v["id"] == m.get("voice") for v in VOICES):
        s.voice = m["voice"]
    if _is_num(m.get("pitch")):
        s.pitch = clamp(float(m["pitch"]), 0.5, 2)
    if _is_num(m.get("speed")):
        s.speed = clamp(float(m["speed"]), 0.5, 2)
    if not s.remote:
        store.save_prefs({"voice": s.voice, "pitch": s.pitch, "speed": s.speed, "model": s.model, "coderModel": s.coder_model})
        for c in list(store.clients):
            if c.native:
                _apply_prefs(c)


def _apply_prefs(s: agent.Session):
    """What's picked in the computer's UI (voice, pitch, speed, models) is what the iPhone app uses too."""
    p = store.PREFS
    if any(v["id"] == p.get("voice") for v in VOICES):
        s.voice = p["voice"]
    if _is_num(p.get("pitch")):
        s.pitch = p["pitch"]
    if _is_num(p.get("speed")):
        s.speed = p["speed"]
    if p.get("model"):
        s.model = p["model"]
    if isinstance(p.get("coderModel"), str):
        s.coder_model = p["coderModel"]


# ───────────────────────── keep-awake ─────────────────────────
_awake = None


def set_keep_awake(on: bool):
    """Keeps the computer from fully sleeping so the microphone stays alive for clap-to-wake. The display can
    still turn off; only deep system sleep (which halts everything) is prevented."""
    global _awake
    if on and not _awake:
        _awake = plat.keep_awake_process(ctl.CONTROL)
        if _awake:
            print(f"  keep-awake on (the {HOST} will not deep-sleep)")
    elif not on and _awake:
        try:
            _awake.kill()
        except OSError:
            pass
        _awake = None
        print("  keep-awake off")


# ───────────────────────── built-in terminal ─────────────────────────
async def serve_term(sock: Socket):
    """The built-in terminal: the UI's xterm <-> a shell behind term/pty_bridge*.py."""
    loop = asyncio.get_running_loop()
    bridge = ROOT / "term" / ("pty_bridge_win.py" if IS_WIN else "pty_bridge.py")
    env = {**os.environ, "TERM": "xterm-256color", "COLORTERM": "truecolor", "LANG": os.environ.get("LANG", "en_US.UTF-8"), "TERM_PROGRAM": "ULTRON"}
    resize_r = resize_w = None
    popen_kw: dict = {}
    if IS_WIN:
        popen_kw["creationflags"] = 0x08000000
    else:
        resize_r, resize_w = os.pipe()   # the bridge reads "rows cols\n" from this pipe
        env["ULTRON_RESIZE_FD"] = str(resize_r)
        popen_kw["pass_fds"] = (resize_r,)
    try:
        p = subprocess.Popen([sys.executable, "-u", str(bridge)], cwd=str(Path.home()), env=env, stdin=subprocess.PIPE,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, **popen_kw)
    except OSError:
        sock.send_text(json.dumps({"error": "Python is needed for the terminal and could not be started"}))
        sock.close()
        return
    if resize_r is not None:
        os.close(resize_r)
    state = {"cwd": ""}

    def pump_out():
        while True:
            d = p.stdout.read1(65536) if hasattr(p.stdout, "read1") else p.stdout.read(4096)
            if not d:
                break
            loop.call_soon_threadsafe(_send_bytes, sock, d)
        loop.call_soon_threadsafe(_close_quiet, sock)

    def pump_err():   # first line: the shell's pid
        line = p.stderr.readline()
        try:
            pid = int(line.strip() or 0)
        except ValueError:
            pid = 0
        if pid and not IS_WIN:
            asyncio.run_coroutine_threadsafe(_follow_cwd(sock, pid, state, p), loop)
        for _ in p.stderr:   # keep draining
            pass
    threading.Thread(target=pump_out, daemon=True).start()
    threading.Thread(target=pump_err, daemon=True).start()
    try:
        while True:
            raw = await sock.recv()
            if raw is None:
                break
            try:
                m = json.loads(raw)
            except ValueError:
                continue
            try:
                if m.get("t") == "i" and isinstance(m.get("d"), str):
                    p.stdin.write(m["d"].encode("utf8"))
                    p.stdin.flush()
                elif m.get("t") == "r":
                    rows, cols = int(m.get("rows") or 0), int(m.get("cols") or 0)
                    if IS_WIN:   # Windows can't hand the bridge a fourth pipe: resizes travel on stdin
                        p.stdin.write(f"\x1b]ultron;resize;{rows};{cols}\x07".encode())
                        p.stdin.flush()
                    elif resize_w is not None:
                        os.write(resize_w, f"{rows} {cols}\n".encode())
            except (OSError, ValueError):
                break
    finally:
        try:
            p.stdin.close()
        except OSError:
            pass
        if resize_w is not None:
            try:
                os.close(resize_w)
            except OSError:
                pass
        loop.call_later(0.5, lambda: p.poll() is None and p.kill())


def _send_bytes(sock: Socket, d: bytes):
    if not sock.closed:
        sock.send_bytes(d)


def _close_quiet(sock: Socket):
    try:
        sock.close()
    except Exception:
        pass


async def _follow_cwd(sock: Socket, pid: int, state: dict, p):
    """Follow the shell's working folder, so the file browser can show where you are."""
    while not sock.closed and p.poll() is None:
        r = await __import__("ultron.proc", fromlist=["run"]).run("lsof", ["-a", "-d", "cwd", "-p", str(pid), "-Fn"])
        m = re.search(r"^n(.+)$", r["stdout"], re.M)
        if m and m.group(1) != state["cwd"]:
            state["cwd"] = m.group(1)
            sock.send_text(json.dumps({"cwd": state["cwd"]}))
        await asyncio.sleep(1.2)


# ───────────────────────── background loops, phone link, startup ─────────────────────────
async def telemetry_loop():
    """System telemetry for the HUD."""
    import psutil
    psutil.cpu_percent(None)
    batt = None
    last_batt = 0.0
    while True:
        await asyncio.sleep(2)
        if time.time() - last_batt > 30:
            last_batt = time.time()
            b = await plat.battery()
            batt = {"percent": b["percent"], "charging": b["charging"]} if b else None
        try:
            load = os.getloadavg()[0]
        except (AttributeError, OSError):
            load = 0
        msg = {"type": "sys", "cpu": psutil.cpu_percent(None) / 100, "load": load, "cores": psutil.cpu_count() or 1,
               "uptime": time.time() - psutil.boot_time(), "battery": batt}
        for c in list(store.clients):
            c.send(msg)


_tasks: list = []


async def startup():
    """Engines and background loops. Called once on the asyncio thread (desktop.py), no ports are opened."""
    vendor_setup.ensure()
    store._journal_loop = asyncio.get_running_loop()
    agent.install_hooks()
    await speech.start_engines()
    await ctl.start_control()
    for f in list(speech.TTS_DIR.iterdir()):
        f.unlink(missing_ok=True)
    if not IS_WIN:
        name = await plat.computer_name()
        if name:
            phone.set_machine_name(name)
    _tasks[:] = [asyncio.ensure_future(c) for c in (speech.cleanup_loop(), sched.job_loop(), telemetry_loop(), phone.outbox_cleanup_loop())]
    if store.LOG and store.LOG[-1]["t"] > (store.JOURNAL[-1]["to"] if store.JOURNAL else 0):
        store.schedule_journal()
    model = CONFIG["model"] or llm.default_model()
    print(f"\n  ULTRON online (desktop, no server)")
    print(f"  model: {model} · voice: {speech.default_voice()} · ollama: {CONFIG['ollama']}")
    fb = CONFIG["fallback_model"]
    print("  gemini: " + (f"key loaded · falls back to {fb}" if llm.gemini_key() else "no key (~/.ultron-gemini-key)") + "\n")
    llm.warm_up(model)


async def shutdown():
    set_keep_awake(False)
    speech.stop_engines()
    for t in _tasks:
        t.cancel()
