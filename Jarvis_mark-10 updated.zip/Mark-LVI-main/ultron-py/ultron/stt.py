"""Hearing, the JARVIS way: record, then transcribe with Whisper — on a server (Groq, OpenAI) or on
this computer (faster-whisper, if installed). The browser's own recognizer stays the default; this
is what push-to-talk uses when Settings → Voice → Hearing is set to something else.
"""
from __future__ import annotations

import asyncio
import json
import os
import tempfile
import urllib.error
import urllib.request
import uuid

from . import settings

ENGINES = {
    "groq": {"url": "https://api.groq.com/openai/v1/audio/transcriptions", "model": "whisper-large-v3-turbo", "label": "Groq Whisper"},
    "openai": {"url": "https://api.openai.com/v1/audio/transcriptions", "model": "whisper-1", "label": "OpenAI Whisper"},
}
_local_model = None


def _key(engine: str) -> str:
    S = settings.get()
    # One key is enough: the AI-engine key for the same service works for hearing too.
    return (S["stt"]["api_key"] or S["llm"]["keys"].get(engine) or "").strip()


def _multipart(fields: dict, file_field: str, filename: str, mime: str, data: bytes):
    boundary = uuid.uuid4().hex
    parts = []
    for k, v in fields.items():
        if v:
            parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode())
    parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{file_field}"; filename="{filename}"\r\nContent-Type: {mime}\r\n\r\n'.encode())
    parts += [data, f"\r\n--{boundary}--\r\n".encode()]
    return b"".join(parts), f"multipart/form-data; boundary={boundary}"


def _ext(mime: str) -> str:
    m = (mime or "").lower()
    return "webm" if "webm" in m else "mp4" if "mp4" in m else "ogg" if "ogg" in m else "wav" if "wav" in m else "webm"


def _api(engine: str, data: bytes, mime: str) -> str:
    cfg = ENGINES[engine]
    key = _key(engine)
    if not key:
        raise RuntimeError(f"No API key for {cfg['label']} (Settings → Voice)")
    S = settings.get()["stt"]
    body, ctype = _multipart({"model": S["model"] or cfg["model"], "language": S["language"], "response_format": "json"},
                             "file", f"speech.{_ext(mime)}", mime or "audio/webm", data)
    req = urllib.request.Request(cfg["url"], data=body, headers={"Authorization": f"Bearer {key}", "Content-Type": ctype}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return (json.loads(r.read().decode("utf8", "replace")).get("text") or "").strip()
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"{cfg['label']} {e.code}: {e.read().decode('utf8', 'replace')[:160]}") from None


def _local(data: bytes, mime: str) -> str:
    global _local_model
    try:
        from faster_whisper import WhisperModel
    except ImportError:
        raise RuntimeError("Local Whisper needs:  pip install faster-whisper") from None
    if _local_model is None:
        _local_model = WhisperModel(settings.get()["stt"]["model"] or "base", compute_type="int8")
    with tempfile.NamedTemporaryFile(suffix="." + _ext(mime), delete=False) as f:
        f.write(data)
        path = f.name
    try:
        segs, _ = _local_model.transcribe(path, language=settings.get()["stt"]["language"] or None)
        return " ".join(s.text.strip() for s in segs).strip()
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


async def transcribe(data: bytes, mime: str = "audio/webm") -> dict:
    engine = settings.get()["stt"]["engine"]
    if engine == "browser":
        return {"ok": False, "error": "Hearing is set to the browser. Choose Whisper in Settings → Voice."}
    if len(data) < 800:
        return {"ok": True, "text": ""}
    loop = asyncio.get_running_loop()
    try:
        text = await loop.run_in_executor(None, _local if engine == "local" else (lambda d, m: _api(engine, d, m)), data, mime)
        return {"ok": True, "text": text}
    except Exception as e:
        return {"ok": False, "error": str(e)}


async def test() -> dict:
    engine = settings.get()["stt"]["engine"]
    if engine == "browser":
        return {"ok": True, "message": "The browser's own recognizer is used (nothing to test)."}
    if engine == "local":
        try:
            import faster_whisper  # noqa: F401
            return {"ok": True, "message": "faster-whisper is installed."}
        except ImportError:
            return {"ok": False, "message": "Not installed:  pip install faster-whisper"}
    return {"ok": bool(_key(engine)), "message": f"{ENGINES[engine]['label']} key is set." if _key(engine) else f"No API key for {ENGINES[engine]['label']}."}
