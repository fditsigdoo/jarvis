"""User settings, kept the way JARVIS keeps them: one JSON file, a catalog of AI services, and a
separate choice for hearing (STT) and speaking (TTS). Everything is editable from the Settings
window in the UI, or with slash commands in the chat box. Keys are written to memory/settings.json
(already git-ignored with the rest of memory/) and never sent back to the browser, only a
"key is set" flag.
"""
from __future__ import annotations

import copy
import json
import os
import re
import threading

from .config import MEM_DIR

FILE = MEM_DIR / "settings.json"
_lock = threading.Lock()

# Same services JARVIS offers under ENGINE & PROVIDERS. Anything that speaks the OpenAI
# /chat/completions protocol works, so "custom" covers the rest.
SERVICES = [
    {"id": "openai",     "label": "OpenAI",       "base_url": "https://api.openai.com/v1",        "local": False, "model": "gpt-4o-mini"},
    {"id": "groq",       "label": "Groq",         "base_url": "https://api.groq.com/openai/v1",   "local": False, "model": "llama-3.3-70b-versatile"},
    {"id": "openrouter", "label": "OpenRouter",   "base_url": "https://openrouter.ai/api/v1",     "local": False, "model": ""},
    {"id": "deepseek",   "label": "DeepSeek",     "base_url": "https://api.deepseek.com/v1",      "local": False, "model": "deepseek-chat"},
    {"id": "mistral",    "label": "Mistral",      "base_url": "https://api.mistral.ai/v1",        "local": False, "model": "mistral-small-latest"},
    {"id": "xai",        "label": "xAI (Grok)",   "base_url": "https://api.x.ai/v1",              "local": False, "model": ""},
    {"id": "together",   "label": "Together",     "base_url": "https://api.together.xyz/v1",      "local": False, "model": ""},
    {"id": "cerebras",   "label": "Cerebras",     "base_url": "https://api.cerebras.ai/v1",       "local": False, "model": ""},
    {"id": "minimax",    "label": "MiniMax",      "base_url": "https://api.minimax.io/v1",        "local": False, "model": ""},
    {"id": "lmstudio",   "label": "LM Studio",    "base_url": "http://127.0.0.1:1234/v1",         "local": True,  "model": ""},
    {"id": "llamacpp",   "label": "llama.cpp",    "base_url": "http://127.0.0.1:8080/v1",         "local": True,  "model": ""},
    {"id": "vllm",       "label": "vLLM",         "base_url": "http://127.0.0.1:8000/v1",         "local": True,  "model": ""},
    {"id": "custom",     "label": "Something else (own address)", "base_url": "", "local": None, "model": ""},
]
SERVICE_BY_ID = {s["id"]: s for s in SERVICES}

# llm.provider: "auto" = what Ultron always did (Gemini if a key exists, else Ollama)
#               "ollama" | "gemini" | "api" (an OpenAI-compatible service from SERVICES)
DEFAULTS = {
    "llm": {
        "provider": "auto",
        "service": "openai",
        "model": "",                 # default model name for the chosen provider
        "base_urls": {},             # service id -> address override (custom / changed)
        "keys": {},                  # service id -> api key
        "gemini_key": "",
        "vision": "auto",            # auto | yes | no (for "api" models)
    },
    "stt": {
        "engine": "browser",         # browser | groq | openai | local (faster-whisper, if installed)
        "api_key": "",
        "model": "",
        "language": "",              # "" = let Whisper detect it, or "ko", "en"...
    },
    "tts": {
        "engine": "local",           # local (Kokoro / system) | elevenlabs | openai
        "api_key": "",
        "voice_id": "",
        "model": "",
        "base_url": "",
    },
}

SECRET_PATHS = (("llm", "keys"), ("llm", "gemini_key"), ("stt", "api_key"), ("tts", "api_key"))


def _merge(base: dict, patch: dict) -> dict:
    for k, v in patch.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            _merge(base[k], v)
        else:
            base[k] = v
    return base


_cache: dict | None = None


def get() -> dict:
    global _cache
    with _lock:
        if _cache is None:
            data = copy.deepcopy(DEFAULTS)
            try:
                _merge(data, json.loads(FILE.read_text("utf8")))
            except (OSError, ValueError):
                pass
            _cache = data
        return _cache


def save(patch: dict) -> dict:
    """Merges a partial settings dict. Empty-string secrets mean 'keep what is stored'."""
    cur = get()
    clean = copy.deepcopy(patch)
    for sect, key in SECRET_PATHS:
        sub = clean.get(sect, {})
        if key == "keys" and isinstance(sub.get("keys"), dict):
            sub["keys"] = {k: v for k, v in sub["keys"].items() if isinstance(v, str) and v.strip()}
        elif key in sub and not str(sub[key] or "").strip():
            sub.pop(key)
    with _lock:
        _merge(cur, clean)
        FILE.write_text(json.dumps(cur, indent=2, ensure_ascii=False), "utf8")
        try:
            os.chmod(FILE, 0o600)
        except OSError:
            pass
    return cur


def forget_key(section: str, service: str = "") -> None:
    cur = get()
    with _lock:
        if section == "llm" and service:
            cur["llm"]["keys"].pop(service, None)
        elif section == "llm":
            cur["llm"]["gemini_key"] = ""
        else:
            cur[section]["api_key"] = ""
        FILE.write_text(json.dumps(cur, indent=2, ensure_ascii=False), "utf8")


def public() -> dict:
    """What the browser may see: everything except the secrets, which become 'set' flags."""
    d = copy.deepcopy(get())
    d["llm"]["keys_set"] = {k: bool(v) for k, v in d["llm"].pop("keys").items()}
    d["llm"]["gemini_key_set"] = bool(d["llm"].pop("gemini_key"))
    d["stt"]["api_key_set"] = bool(d["stt"].pop("api_key"))
    d["tts"]["api_key_set"] = bool(d["tts"].pop("api_key"))
    d["services"] = SERVICES
    return d


# ───────────────────────── what the rest of the code asks ─────────────────────────
def provider() -> str:
    return get()["llm"]["provider"]


def api_service() -> dict:
    """The OpenAI-compatible service currently chosen: {id, label, base_url, key, model}."""
    L = get()["llm"]
    sid = L["service"]
    base = SERVICE_BY_ID.get(sid, SERVICE_BY_ID["custom"])
    url = (L["base_urls"].get(sid) or base["base_url"]).strip().rstrip("/")
    if url and "://" not in url:
        url = "http://" + url
    key = (L["keys"].get(sid) or "").strip()
    return {"id": sid, "label": base["label"], "base_url": url, "key": key, "model": L["model"] or base["model"], "local": base["local"]}


def gemini_key_saved() -> str:
    return (get()["llm"].get("gemini_key") or "").strip()


_VISION = re.compile(r"vision|vl\b|-vl|4o|gpt-4\.1|gpt-5|gpt-4-turbo|llava|gemini|claude|pixtral|llama-?3\.2-.*(11|90)b|qwen.*vl|gemma-?3", re.I)


def api_has_vision(model: str) -> bool:
    v = get()["llm"]["vision"]
    return True if v == "yes" else False if v == "no" else bool(_VISION.search(model or ""))
