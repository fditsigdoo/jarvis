"""Computer control: mouse, keyboard, accessibility tree, screenshots, windows.

This is the one part that has to speak to each operating system's own UI APIs, so it stays a small
native helper that is built on first run (the same two files as before, same commands, same output):
  control/control.cs     Windows: built with the C# compiler that ships with every Windows 10/11 (csc.exe)
  control/control.swift  macOS:   built with swiftc
Everything around it (what to click, what changed on screen, screenshots for the vision model) is here.
"""
from __future__ import annotations

import asyncio
import base64
import json
import os
import random
import re
import time
from pathlib import Path

from .config import HOST, IS_WIN, ROOT, TTS_DIR, app_name
from .proc import run

CONTROL = ROOT / "control" / ("control.exe" if IS_WIN else "control")
SRC = ROOT / "control" / ("control.cs" if IS_WIN else "control.swift")


def _framework_dir() -> Path:
    win = Path(os.environ.get("WINDIR", r"C:\Windows")) / "Microsoft.NET"
    return win / ("Framework64" if (win / "Framework64").exists() else "Framework") / "v4.0.30319"


async def ensure_helper(src: Path, binp: Path, what: str) -> None:
    """Compiles a native helper if it's missing or older than its source."""
    if binp.exists() and binp.stat().st_mtime >= src.stat().st_mtime:
        return
    print(f"  compiling {what}…")
    if not IS_WIN:
        r = await run("swiftc", ["-O", str(src), "-o", str(binp)], timeout=300)
    else:
        fw = _framework_dir()
        wpf = fw / "WPF"
        r = await run(str(fw / "csc.exe"), [
            "/nologo", "/optimize+", "/codepage:65001", "/target:exe", f"/out:{binp}",
            "/r:System.dll", "/r:System.Core.dll", "/r:System.Drawing.dll", "/r:System.Windows.Forms.dll", "/r:System.Management.dll",
            f"/r:{wpf / 'UIAutomationClient.dll'}", f"/r:{wpf / 'UIAutomationTypes.dll'}", f"/r:{wpf / 'WindowsBase.dll'}", str(src)], timeout=300)
    if r["code"] != 0:
        raise OSError(r["stdout"] or r["stderr"] or "compile failed")


async def start_control():
    try:
        await ensure_helper(SRC, CONTROL, "computer control")
    except OSError:
        print(f"  ({'the C# compiler (csc.exe) is' if IS_WIN else 'swiftc is'} unavailable — mouse/keyboard control disabled)")
        return
    if IS_WIN:
        return
    # Asks macOS for Accessibility + Screen Recording the first time (shows the system dialogs).
    r = await run(str(CONTROL), ["perm", "--prompt"])
    try:
        p = json.loads(r["stdout"])
        if not p.get("accessibility"):
            print("  ⚠ Accessibility permission needed for mouse/keyboard control")
        if not p.get("screen"):
            print("  ⚠ Screen Recording permission needed for screenshots")
    except ValueError:
        pass


def available() -> bool:
    return CONTROL.exists()


async def control(*args) -> dict:
    if not CONTROL.exists():
        return {"ok": False, "error": f"Computer control is not available (needs {'the .NET Framework C# compiler' if IS_WIN else 'swiftc'})"}
    args = list(args)
    # Shortcuts are written Mac-style everywhere (cmd+t); Windows gets its own (ctrl+t, f11, alt+left…).
    if IS_WIN and args and args[0] == "key" and len(args) > 1:
        from .winutil import win_combo
        args[1] = win_combo(args[1])
    r = await run(str(CONTROL), ["" if a is None else str(a) for a in args], timeout=45)
    out = r["stdout"].strip()
    if r["code"] != 0 or out.startswith("ERROR:"):
        return {"ok": False, "error": re.sub(r"^ERROR:\s*", "", out) or r["stderr"].strip()}
    return {"ok": True, "message": out}


# ───────────────────────── what's on screen ─────────────────────────
def _rid() -> str:
    return f"{int(time.time() * 1000)}-{random.randrange(36**4):04x}"


async def capture_screen(app: str = "", force_window: bool = False) -> dict | None:
    """JPEG (base64) of the app's window, or the whole screen when there's no window to target."""
    if IS_WIN:
        jpg = TTS_DIR / f"screen-{_rid()}.jpg"
        r = await control("shot", str(jpg), app or "", "window" if force_window else "auto")
        if not r["ok"] or not jpg.exists():
            return None
        try:
            info = json.loads(r["message"])
        except ValueError:
            info = {}
        image = base64.b64encode(jpg.read_bytes()).decode()
        jpg.unlink(missing_ok=True)
        return {"image": image, "windowShot": bool(info.get("window")), "app": info.get("app")}
    try:
        target = json.loads((await control("target", app or "")).get("message", "{}"))
    except ValueError:
        target = {}
    png = TTS_DIR / f"screen-{_rid()}.png"
    jpg = png.with_suffix(".jpg")
    window_shot = (app or target.get("frontIsUltron") or force_window) and target.get("windowId")
    await run("screencapture", ["-x", "-o", "-l", str(target["windowId"]), str(png)] if window_shot else ["-x", "-m", str(png)])
    if not png.exists():
        return None
    await run("sips", ["-s", "format", "jpeg", "-s", "formatOptions", "80", "-Z", "1600", str(png), "--out", str(jpg)])
    image = base64.b64encode((jpg if jpg.exists() else png).read_bytes()).decode()
    png.unlink(missing_ok=True)
    jpg.unlink(missing_ok=True)
    return {"image": image, "windowShot": bool(window_shot), "app": target.get("app")}


class Ui:
    """The UI list from the helper: a few header lines (App, Keyboard focus, Mouse), then one element per line."""

    def __init__(self, head: list, items: list):
        self.head, self.items = head, items


def split_ui(text: str) -> Ui:
    lines = (text or "").split("\n")
    head = [l for l in lines if re.match(r"^(App:|Keyboard focus:|Mouse at|\(no open window\))", l)]
    return Ui(head, [l for l in lines if l not in head and not l.startswith("…")])


def unmark(l: str) -> str:
    return re.sub(r"^\[\d+\] ", "", l)


class _State:
    last_view: dict | None = None   # the most recent screen check: {target, ui, t}
    marks: dict = {}                # number on the latest marked screenshot -> {x, y, what}


state = _State()


async def look_marked(target: str) -> dict | None:
    """Screenshot with a numbered box on every clickable thing, plus the element list with the same numbers.
    That's how she knows exactly what she's clicking: "click mark 12" is the box she sees."""
    out = TTS_DIR / f"marks-{_rid()}.jpg"
    view = await control("marks", target, str(out))
    image = None
    if view["ok"] and out.exists():
        image = base64.b64encode(out.read_bytes()).decode()
    out.unlink(missing_ok=True)
    if not view["ok"]:
        view = await control("ui", target)
    if not view["ok"]:
        return None
    ui = split_ui(view["message"])
    marks = {}
    for l in ui.items:
        m = re.match(r"^\[(\d+)\] (.+) at (-?\d+),(-?\d+)$", l)
        if m:
            marks[int(m.group(1))] = {"x": int(m.group(3)), "y": int(m.group(4)), "what": m.group(2)}
    if marks:
        state.marks = marks
    state.last_view = {"target": target, "ui": ui, "t": time.time()}
    return {"ui": ui, "image": image}


async def observe_after(tool: str, target: str, before: Ui | None) -> dict | None:
    """What the screen looks like after an action, compared with just before it: what appeared, what went
    away, where the keyboard focus is. "Nothing changed" is the tell for a missed tap."""
    await asyncio.sleep(0.25)
    look = await look_marked(target)
    flat = lambda ui: "\n".join(unmark(l) for l in ui.items)
    if before and look and flat(look["ui"]) == flat(before):
        await asyncio.sleep(0.9)   # pages take a moment
        look = (await look_marked(target)) or look
    if not look:
        return None
    now = look["ui"]
    out = list(now.head)
    if before:
        was = {unmark(l) for l in before.items}
        is_ = {unmark(l) for l in now.items}
        added = [l for l in now.items if unmark(l) not in was]
        gone = len([l for l in before.items if unmark(l) not in is_])
        moved = (before.head[0] if before.head else None) != (now.head[0] if now.head else None)
        if not added and not gone and not moved and tool != "move_mouse":
            out.append("NOTHING CHANGED on screen after this action — it probably missed or did nothing. Do not carry on as if it worked: look at the screenshot and try something else.")
        elif added or gone or moved:
            if moved:
                out.append("Window changed (was: %s)" % re.sub(r"^App:\s*", "", before.head[0] if before.head else ""))
            out.append(f"Appeared since the action ({len(added)}):")
            out.extend(added[:45])
            if len(added) > 45:
                out.append(f"… {len(added) - 45} more")
            if gone:
                out.append(f"({gone} element(s) disappeared)")
    out.append("Everything visible now ([n] = the numbered box on the screenshot; click it with click {\"mark\": n}):")
    out.extend(now.items[:90])
    if len(now.items) > 90:
        out.append("… more elements not shown (scroll or read_screen)")
    return {"text": "\n".join(out), "image": look["image"]}
