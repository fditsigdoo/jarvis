"""ULTRON: a local voice AI that controls your PC (or Mac), powered by Ollama.   Start it with: python run.py (opens its own desktop window)"""
import sys

if sys.version_info < (3, 10):
    sys.exit("ULTRON needs Python 3.10 or newer (https://python.org).")

from ultron.desktop import run

if __name__ == "__main__":
    run()
