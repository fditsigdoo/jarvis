// Settings window (AI engine · Voice · Commands) and server-side hearing (push-to-talk with Whisper).
// Talks to /api/settings*, /api/stt. app.js hands over what this needs through window.UltronBridge.

const $ = s => document.querySelector(s);
const root = $('#settings');
let S = null;            // settings as the server last sent them (no secrets, only "key is set" flags)
let openaiVoices = [];

const api = async (path, body) => {
  const r = await fetch(path, body === undefined ? {} : { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  return r.json();
};
const say = (text, kind = '') => { const m = $('#st-msg'); m.textContent = text; m.className = 'st-msg ' + kind; };

// ───────────── load / fill ─────────────
async function load() {
  const j = await api('/api/settings');
  if (!j.ok) return say(j.error || 'Could not load settings', 'bad');
  S = j.settings; openaiVoices = j.openai_voices || [];
  fill();
}

function currentService() { return S.services.find(x => x.id === $('#st-service').value) || S.services[0]; }

function fill() {
  const L = S.llm;
  $('#st-provider').value = L.provider;
  $('#st-service').innerHTML = S.services.map(x => `<option value="${x.id}">${x.label}${x.local ? ' · local' : ''}</option>`).join('');
  $('#st-service').value = L.service;
  showService();
  $('#st-model').value = L.model || '';
  $('#st-stt').value = S.stt.engine;
  $('#st-slang').value = S.stt.language || '';
  $('#st-tts').value = S.tts.engine;
  $('#st-voiceid').value = S.tts.voice_id || '';
  $('#st-tmodel').value = S.tts.model || '';
  ['#st-key', '#st-gkey', '#st-skey', '#st-tkey'].forEach(i => { $(i).value = ''; });
  $('#st-gkey').placeholder = S.llm.gemini_key_set ? '•••••• saved (type to replace)' : 'AI Studio key';
  $('#st-skey').placeholder = S.stt.api_key_set ? '•••••• saved (type to replace)' : 'blank = reuse the AI engine key';
  $('#st-tkey').placeholder = S.tts.api_key_set ? '•••••• saved (type to replace)' : 'blank = reuse the AI engine key (OpenAI)';
  toggles();
}

function showService() {
  const svc = currentService();
  const url = S.llm.base_urls[svc.id] || svc.base_url;
  $('#st-url').value = url;
  $('#st-url').placeholder = svc.id === 'custom' ? 'https://your-server/v1' : svc.base_url;
  $('#st-key').placeholder = S.llm.keys_set[svc.id] ? '•••••• saved (type to replace)' : (svc.local ? 'not needed for local servers' : 'API key');
  $('#st-model').placeholder = svc.model || 'model name';
}

function toggles() {
  const p = $('#st-provider').value;
  $('#st-api').hidden = p !== 'api';
  $('#st-gem').hidden = p === 'gemini' ? false : p !== 'auto';
  $('#st-stt-more').hidden = $('#st-stt').value === 'browser' || $('#st-stt').value === 'local';
  $('#st-tts-more').hidden = $('#st-tts').value === 'local';
  $('#st-forget-llm').hidden = p === 'ollama';
}

// ───────────── save ─────────────
function collect() {
  const svc = currentService();
  const patch = {
    llm: { provider: $('#st-provider').value, service: svc.id, model: $('#st-model').value.trim(), base_urls: {}, keys: {} },
    stt: { engine: $('#st-stt').value, language: $('#st-slang').value.trim(), api_key: $('#st-skey').value.trim() },
    tts: { engine: $('#st-tts').value, voice_id: $('#st-voiceid').value.trim(), model: $('#st-tmodel').value.trim(), api_key: $('#st-tkey').value.trim() },
  };
  const url = $('#st-url').value.trim();
  patch.llm.base_urls[svc.id] = url === svc.base_url ? '' : url;
  if ($('#st-key').value.trim()) patch.llm.keys[svc.id] = $('#st-key').value.trim();
  if ($('#st-gkey').value.trim()) patch.llm.gemini_key = $('#st-gkey').value.trim();
  return patch;
}

async function save(quiet) {
  const j = await api('/api/settings', { settings: collect() });
  if (!j.ok) { say(j.error || 'Save failed', 'bad'); return false; }
  S = j.settings; fill();
  setSttEngine(S.stt.engine);
  if (!quiet) say('Saved.', 'ok');
  return true;
}

async function test(target) {
  say('Testing…');
  if (!(await save(true))) return;
  const r = await api('/api/settings/test', { target });
  say(r.message || r.error || '', r.ok ? 'ok' : 'bad');
}

async function fillList(path, listEl, key) {
  say('Reading the list…');
  if (!(await save(true))) return;
  const j = await api(path);
  const items = key === 'models' ? (j.models || []).filter(m => m.startsWith('api:')).map(m => m.slice(4)) : null;
  if (key === 'models') {
    listEl.innerHTML = items.map(m => `<option value="${m}">`).join('');
    say(items.length ? `${items.length} models found. Click the field to pick one.` : 'No models returned (check the address and key).', items.length ? 'ok' : 'bad');
  } else {
    const eleven = j.elevenlabs || [];
    const list = $('#st-tts').value === 'elevenlabs' ? eleven : (j.openai || openaiVoices).map(v => ({ id: v, label: v }));
    listEl.innerHTML = list.map(v => `<option value="${v.id}">${v.label}</option>`).join('');
    say(list.length ? `${list.length} voices found. Click the field to pick one.` : 'No voices returned (check the key).', list.length ? 'ok' : 'bad');
  }
}

// ───────────── open / close ─────────────
async function open() {
  root.hidden = false;
  say('');
  await load();
}
const close = () => { root.hidden = true; };

$('#open-settings').onclick = open;
// Only visible when ULTRON is hosted inside JARVIS (html.embedded): hands the screen back with the same pixel-wipe.
$('#confine-ultron').onclick = () => window.__ultronHost && window.__ultronHost.confine();
$('#st-close').onclick = close;
$('#st-cancel').onclick = close;
$('#st-save').onclick = async () => { if (await save()) setTimeout(close, 500); };
root.addEventListener('mousedown', e => { if (e.target === root) close(); });
root.addEventListener('keydown', e => { if (e.key === 'Escape') { e.stopPropagation(); close(); } });
document.querySelectorAll('.st-tab').forEach(b => b.onclick = () => {
  document.querySelectorAll('.st-tab').forEach(x => x.setAttribute('aria-pressed', String(x === b)));
  document.querySelectorAll('.st-page').forEach(p => { p.hidden = p.dataset.page !== b.dataset.tab; });
});
['#st-provider', '#st-stt', '#st-tts'].forEach(i => $(i).onchange = toggles);
$('#st-service').onchange = () => { $('#st-model').value = ''; showService(); };
$('#st-test-llm').onclick = () => test('llm');
$('#st-test-stt').onclick = () => test('stt');
$('#st-test-tts').onclick = () => test('tts');
$('#st-list').onclick = () => fillList('/api/settings/models', $('#st-models'), 'models');
$('#st-vlist').onclick = () => fillList('/api/settings/voices', $('#st-voices'), 'voices');
$('#st-forget-llm').onclick = async () => {
  const p = $('#st-provider').value;
  const r = await api('/api/settings/forget', p === 'gemini' ? { section: 'llm' } : { section: 'llm', service: currentService().id });
  if (r.ok) { S = r.settings; fill(); say('Key forgotten.', 'ok'); }
};
$('#st-forget-voice').onclick = async () => {
  await api('/api/settings/forget', { section: 'stt' });
  const r = await api('/api/settings/forget', { section: 'tts' });
  if (r.ok) { S = r.settings; fill(); say('Voice keys forgotten.', 'ok'); }
};

// ───────────── hearing with Whisper (push-to-talk) ─────────────
// Press the mic (or Space): it records, stops by itself after ~1.2 s of silence (or 30 s),
// sends the clip to /api/stt and puts the text into the conversation. Press again to stop early.
let sttEngine = 'browser';
let recorder = null;

export function setSttEngine(e) { sttEngine = e || 'browser'; document.body.classList.toggle('mic-whisper', sttEngine !== 'browser'); }
fetch('/api/settings').then(r => r.json()).then(j => j.ok && setSttEngine(j.settings.stt.engine)).catch(() => {});

async function whisperTalk() {
  const B = window.UltronBridge;
  if (recorder) { recorder.stop(); return; }
  B.stopAll();
  let stream;
  try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); }
  catch { return B.toast('Microphone permission denied.'); }
  const mime = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4'].find(m => MediaRecorder.isTypeSupported(m)) || '';
  const mr = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
  const chunks = [];
  const ac = new AudioContext(), src = ac.createMediaStreamSource(stream), an = ac.createAnalyser();
  an.fftSize = 512; src.connect(an);
  const buf = new Float32Array(512);
  let heard = false, quietSince = performance.now(), t0 = performance.now();
  const vad = setInterval(() => {
    an.getFloatTimeDomainData(buf);
    const rms = Math.sqrt(buf.reduce((a, x) => a + x * x, 0) / buf.length);
    const now = performance.now();
    if (rms > 0.02) { heard = true; quietSince = now; }
    if ((heard && now - quietSince > 1200) || now - t0 > 30000 || (!heard && now - t0 > 8000)) mr.stop();
  }, 80);
  mr.ondataavailable = e => e.data.size && chunks.push(e.data);
  mr.onstop = async () => {
    clearInterval(vad); stream.getTracks().forEach(t => t.stop()); ac.close(); recorder = null;
    B.listening(false);
    if (!heard) return;
    B.toast('Transcribing…');
    const blob = new Blob(chunks, { type: mr.mimeType || 'audio/webm' });
    try {
      const r = await (await fetch('/api/stt', { method: 'POST', headers: { 'content-type': blob.type }, body: blob })).json();
      if (!r.ok) return B.toast(r.error || 'Transcription failed');
      if (r.text) B.sendUser(r.text, { voice: true });
    } catch { B.toast('Could not reach the transcription service.'); }
  };
  recorder = mr;
  B.chime();
  B.listening(true);
  mr.start();
}

// ───────────── what app.js uses ─────────────
window.UltronSettings = {
  open,
  isWhisper: () => sttEngine !== 'browser',
  talk: whisperTalk,
  setStt: setSttEngine,
  onChanged: async () => { try { const j = await api('/api/settings'); if (j.ok) { S = j.settings; setSttEngine(S.stt.engine); if (!root.hidden) fill(); } } catch {} },
};
