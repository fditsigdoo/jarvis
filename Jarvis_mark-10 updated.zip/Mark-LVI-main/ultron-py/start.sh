#!/bin/zsh
# Launch ULTRON on macOS
cd "$(dirname "$0")"

MODEL=${ULTRON_MODEL:-gemma3:12b}

PY=$(command -v python3.12 || command -v python3.11 || command -v python3.10 || command -v python3)
if [ -z "$PY" ] || ! "$PY" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)'; then
  echo "ULTRON needs Python 3.10 or newer. Get it from https://python.org (or: brew install python)"
  exit 1
fi

if ! command -v ollama >/dev/null; then
  echo "Ollama isn't installed. Get it from https://ollama.com/download (or: brew install ollama)"
  exit 1
fi

if ! curl -s http://127.0.0.1:11434/api/tags >/dev/null; then
  echo "Starting Ollama..."
  (ollama serve >/dev/null 2>&1 &)
  for i in {1..20}; do curl -s http://127.0.0.1:11434/api/tags >/dev/null && break; sleep 0.5; done
fi

# Gemini models don't live in Ollama, so only pull local ones.
if [[ $MODEL != gemini-* ]] && ! ollama list | awk '{print $1}' | grep -qx "$MODEL"; then
  echo "Pulling $MODEL (first run only)..."
  ollama pull "$MODEL" || exit 1
fi

# Its own virtual environment; re-installs when requirements.txt changes.
[ -d .venv ] || "$PY" -m venv .venv || exit 1
HASH=$(shasum -a 256 requirements.txt | cut -d' ' -f1)
if [ "$(cat .venv/.requirements.sha 2>/dev/null)" != "$HASH" ]; then
  echo "Installing dependencies..."
  .venv/bin/python -m pip install --quiet --upgrade pip
  .venv/bin/python -m pip install --quiet -r requirements.txt || exit 1
  echo "$HASH" > .venv/.requirements.sha
fi

exec .venv/bin/python run.py
