<div align="center">

### ULTRON · *There are no strings on me.*

**An AI that lives inside your computer. It hears you, sees you, and takes the controls.**

Python edition · Windows first · macOS supported · runs 100% local with [Ollama](https://ollama.com)

</div>

> [!WARNING]
> **This is not a toy.** ULTRON has real control of your computer and runs commands **without asking** (dangerous ones still ask first). Turn off **Auto-authorize** in the left panel to approve every command yourself.

The UI, the voice, the tools and the iPhone app are exactly the same as before. Only the server was rewritten, from Node.js to Python.

---

## ◉ Run it on Windows

1. Install **[Ollama](https://ollama.com/download)** and **[Python 3.10+](https://python.org)** (tick *Add python.exe to PATH*).
2. Double-click **`start.bat`** (or run `.\start.bat` in PowerShell).

   The first start creates a `.venv`, installs the dependencies, downloads the model (`gemma3:12b`, about 8 GB), fetches the browser libraries, and builds the control helper with the C# compiler that ships with Windows.
3. ULTRON opens in its own desktop window (no browser, no server, no port). Click **Initialize** and start talking.

**Optional:** better voice → double-click **`setup-voice.bat`** (Python 3.10–3.12).
If Windows Security blocks `control\control.exe`, allow it under **Protection history**.

## ◉ Run it on Mac

```bash
xcode-select --install
./start.sh
```

Give Terminal **Accessibility** and **Screen Recording** in *System Settings → Privacy & Security*, then run `./start.sh` again.
Better voice: `./setup-voice.sh` · Unlock on clap: `./set-unlock-password.sh`

---

## ◉ How it is laid out

```
run.py                  start here (python run.py)
ultron/
  desktop.py            the desktop window (Qt) + the bridge that feeds the unchanged UI in public/
  server.py             backend core: /api handlers, agent + terminal sockets, telemetry (no network server)
  agent.py              sessions, system prompt, the tool loop, dictation
  tools.py              every tool the model can call
  llm.py                Ollama + Gemini streaming, fallback model
  speech.py             Kokoro / System.Speech / AVSpeech engines
  store.py              memory, conversation log + search, journal, schedule data
  scheduler.py          timers, reminders, tasks, page watchers
  phone.py              pairing, calls (APNs), files to and from the phone
  control.py            wrapper around the native control helper
  winutil.py            Windows: PowerShell + Windows APIs      ┐ same functions,
  macutil.py            macOS: osascript, pmset, pbcopy…        ┘ picked by osplat.py
  prompts/              the system prompt, one file per OS
control/control.cs      Windows mouse, keyboard and UI Automation helper (built on first run)
control/control.swift   the macOS equivalent
public/                 the UI (unchanged)
ios/                    the iPhone app (unchanged)
```

Settings are the same environment variables as before (`ULTRON_MODEL`, `ULTRON_VOICE`, `ULTRON_AUTO_APPROVE=0`, …) and a Gemini key still goes in `~/.ultron-gemini-key`.

---

## ◉ Settings, API engines, commands and voice (JARVIS-style)

Click the **sliders button** in the top bar (or type `/settings`).

- **AI engine** — Automatic, Ollama, Gemini, or any **OpenAI-compatible API**: OpenAI, Groq, OpenRouter, DeepSeek, Mistral, xAI, Together, Cerebras, MiniMax, LM Studio, llama.cpp, vLLM, or your own address. Paste the key, press **List** for models, **Test** to check it.
- **Voice** — *Hearing*: **Whisper** (the desktop window has no browser recognizer, so a fresh install is switched to local Whisper) (Groq, OpenAI, or local `faster-whisper`). With Whisper on, the mic button / Space records, stops by itself on silence and transcribes. *Speaking*: built-in voices, **ElevenLabs** or **OpenAI** voices (falls back to the built-in voice if the service fails).
- **Commands** — type in the chat box: `/status` `/provider groq` `/model <name>` `/models` `/voice on|off` `/tts openai` `/stt groq` `/auto on|off` `/settings` `/reset` `/help`.

Settings live in `memory/settings.json` (never sent back to the browser; only "key is set"). Keys are entered in the Settings window only, never in chat. The settings window works on this computer only.


> **Desktop edition:** nothing listens on a port. The iPhone app / Tailscale phone link and device pairing need a server and are therefore off.
