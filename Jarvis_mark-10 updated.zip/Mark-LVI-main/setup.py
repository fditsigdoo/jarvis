"""
MARK LVI — ONE-COMMAND SETUP.

    python setup.py

That is all. This single script downloads and installs everything the project
can use, so nothing is left for later:

  1. Python packages           requirements.txt (OS-specific extras auto-filtered)
                               + ultron-py/requirements.txt
  2. Extra Python packages     soundfile, miniaudio, edge-tts, vosk, pandas, pydub,
                               openwakeword, piper-tts, mediapipe (if supported) ...
  3. Playwright browsers       chromium + firefox (+ webkit on macOS)
  4. ULTRON web libraries      three.js / xterm.js  (ultron-py/vendor, checksum-verified)
  5. Models                    Whisper "base" speech model, "Hey Jarvis" wake-word model
  6. Kokoro neural voice       ultron-py/tts/venv + voices + model  (~1 GB, needs Python 3.10-3.12)

Every step after step 1 is non-fatal: if one download fails (corporate network,
flaky connection, no matching wheel) the rest still run and the summary at the
end tells you exactly what to retry. Re-running is safe — finished work is skipped.

Options:
    python setup.py --minimal        only step 1 + 3 (core app, no big extras)
    python setup.py --skip-kokoro    everything except the ~1 GB Kokoro voice
    python setup.py --skip-models    don't pre-download Whisper / wake-word models
    python setup.py --skip-extras    don't install the optional extra packages
"""
from __future__ import annotations

import argparse
import importlib.util
import platform
import shutil
import subprocess
import sys
from pathlib import Path

OS = platform.system()  # "Windows" | "Darwin" | "Linux"
HERE = Path(__file__).resolve().parent
ULTRON = HERE / "ultron-py"

MIN_PY = (3, 11)   # hard floor: below this the syntax used here won't parse
MAX_PY = (3, 13)   # highest version this is actually tested on

# Kokoro (PyTorch) only has wheels for these interpreters.
KOKORO_PY = ((3, 12), (3, 11), (3, 10))

KOKORO_VOICES = ("bm_george bm_fable bm_lewis bm_daniel am_michael am_fenrir "
                 "am_puck bf_emma bf_isabella af_heart af_bella").split()

# Optional packages the app imports lazily. Installed one by one so a single
# failure never blocks the others.  (pip name, only-if predicate or None)
EXTRA_PACKAGES: list[tuple[str, bool]] = [
    ("soundfile", True),       # installer.py core / TTS
    ("miniaudio", True),       # installer.py core
    ("edge-tts", True),        # default TTS engine
    ("vosk", True),            # offline STT option
    ("huggingface_hub", True), # model / voice downloads
    ("pandas", True),          # file_processor spreadsheet analysis
    ("pydub", True),           # file_processor audio
    ("openwakeword", True),    # "Hey Jarvis" wake word
    ("piper-tts", True),       # local neural voice
    ("mediapipe", sys.version_info[:2] <= (3, 12)),  # pushup_counter (no wheels for 3.13)
]

# Results collected for the final summary: (label, "ok" | "fail" | "skip", note)
RESULTS: list[tuple[str, str, str]] = []


# ── tiny helpers ───────────────────────────────────────────────────────────────

def _say(msg: str) -> None:
    print(msg, flush=True)


def _step(title: str) -> None:
    _say(f"\n{'─' * 70}\n▶ {title}\n{'─' * 70}")


def _record(label: str, status: str, note: str = "") -> None:
    RESULTS.append((label, status, note))


def _run(args: list[str], *, check: bool = True, cwd: Path | None = None,
         input_text: str | None = None, timeout: int | None = None) -> subprocess.CompletedProcess:
    _say("   $ " + " ".join(str(a) for a in args))
    return subprocess.run(
        [str(a) for a in args], check=check, cwd=str(cwd) if cwd else None,
        input=input_text, text=input_text is not None,
        encoding="utf-8" if input_text is not None else None,
        errors="replace" if input_text is not None else None,
        timeout=timeout,
    )


def _pip(*pkgs: str, python: str | None = None) -> None:
    _run([python or sys.executable, "-m", "pip", "install",
          "--disable-pip-version-check", *pkgs])


def _guard(label: str, fn, *, fatal: bool = False) -> bool:
    """Run fn(); record the outcome; never let a non-fatal step stop the setup."""
    try:
        note = fn()
        _record(label, "ok", note if isinstance(note, str) else "")
        return True
    except KeyboardInterrupt:
        raise
    except Exception as e:  # noqa: BLE001 — we want every failure reported, not raised
        _say(f"\n⚠️  {label} failed: {e}")
        _record(label, "fail", str(e)[:120])
        if fatal:
            _summary()
            sys.exit(1)
        return False


def _module_available(name: str) -> bool:
    return importlib.util.find_spec(name) is not None


# ── checks ─────────────────────────────────────────────────────────────────────

def _check_python() -> None:
    v = sys.version_info[:2]
    if v > MAX_PY:
        _say(f"\n⚠️  Python {v[0]}.{v[1]} is newer than the {MAX_PY[0]}.{MAX_PY[1]} this is "
             f"tested on. Continuing — if a package has no wheel yet, install Python "
             f"{MAX_PY[0]}.{MAX_PY[1]} and run setup with that.")
        return
    if v < MIN_PY:
        _say(f"\n❌ Python {v[0]}.{v[1]} detected — MARK LVI needs at least "
             f"Python {MIN_PY[0]}.{MIN_PY[1]}.")
        _say("   Install a supported version and run setup with it, e.g.:")
        _say(f"     py -{MIN_PY[0]}.{MIN_PY[1]} setup.py        (Windows)")
        _say(f"     python{MIN_PY[0]}.{MIN_PY[1]} setup.py      (macOS / Linux)")
        sys.exit(1)


def _check_assets() -> None:
    face = HERE / "core" / "face_model.obj"
    if not face.exists() or face.stat().st_size < 4096:
        raise RuntimeError("core/face_model.obj is missing or truncated — the avatar will "
                           "fall back to the plain glowing core. Re-clone the repository.")


# ── steps ──────────────────────────────────────────────────────────────────────

def step_core_requirements() -> str:
    # Newer pip resolves the big dependency set faster and finds more wheels.
    try:
        _run([sys.executable, "-m", "pip", "install", "--upgrade", "pip",
              "--disable-pip-version-check"])
    except Exception:  # noqa: BLE001
        _say("   (pip upgrade skipped)")
    # requirements.txt filters OS-specific extras by itself via pip markers.
    _run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check",
          "-r", HERE / "requirements.txt"])
    return "requirements.txt"


def step_ultron_requirements() -> str:
    req = ULTRON / "requirements.txt"
    if not req.exists():
        return "ultron-py/requirements.txt not found — skipped"
    _run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "-r", req])
    return "ultron-py/requirements.txt"


def step_extra_packages() -> str:
    failed: list[str] = []
    for pkg, applicable in EXTRA_PACKAGES:
        if not applicable:
            _say(f"   – {pkg}: no build for Python "
                 f"{sys.version_info[0]}.{sys.version_info[1]}, skipped")
            continue
        try:
            _pip(pkg)
        except subprocess.CalledProcessError:
            failed.append(pkg)
            _say(f"   ⚠️  {pkg} could not be installed (optional)")
    if failed:
        raise RuntimeError("not installed: " + ", ".join(failed))
    return f"{len(EXTRA_PACKAGES)} packages"


def step_playwright() -> str:
    browsers = ["chromium", "firefox"]
    if OS == "Darwin":
        browsers.append("webkit")  # Safari automation
    _run([sys.executable, "-m", "playwright", "install", *browsers])
    return ", ".join(browsers)


def step_vendor_libs() -> str:
    """three.js / xterm.js for ULTRON's UI — reuses the project's own verified downloader."""
    path = ULTRON / "ultron" / "vendor_setup.py"
    if not path.exists():
        return "ultron-py/ultron/vendor_setup.py not found — skipped"
    spec = importlib.util.spec_from_file_location("_ultron_vendor_setup", path)
    mod = importlib.util.module_from_spec(spec)  # type: ignore[arg-type]
    spec.loader.exec_module(mod)                  # type: ignore[union-attr]
    if not mod.ensure():
        raise RuntimeError("some browser-side libraries could not be fetched")
    return "three.js, xterm.js"


def step_whisper_model() -> str:
    code = ("from faster_whisper import WhisperModel; "
            "WhisperModel('base', compute_type='int8'); print('whisper base ready')")
    _run([sys.executable, "-c", code], timeout=1800)
    return "faster-whisper 'base'"


def step_wake_word_model() -> str:
    code = ("import openwakeword.utils as u\n"
            "try:\n"
            "    u.download_models(['hey_jarvis'])\n"
            "except TypeError:\n"
            "    u.download_models()\n"
            "print('wake word model ready')")
    _run([sys.executable, "-c", code], timeout=900)
    return "hey_jarvis"


# ── Kokoro neural voice (ULTRON) ───────────────────────────────────────────────

def _py_ok_for_kokoro(cmd: list[str]) -> bool:
    try:
        out = subprocess.run(
            cmd + ["-c", "import sys; print(sys.version_info[0], sys.version_info[1])"],
            capture_output=True, text=True, timeout=30)
        if out.returncode != 0:
            return False
        major, minor = (int(x) for x in out.stdout.split()[:2])
        return (major, minor) in KOKORO_PY
    except Exception:  # noqa: BLE001
        return False


def _find_kokoro_python() -> list[str] | None:
    """An interpreter Kokoro/PyTorch has wheels for (3.10–3.12), as a command list."""
    if sys.version_info[:2] in KOKORO_PY:
        return [sys.executable]
    candidates: list[list[str]] = []
    if OS == "Windows" and shutil.which("py"):
        candidates += [["py", f"-{a}.{b}"] for a, b in KOKORO_PY]
    for a, b in KOKORO_PY:
        exe = shutil.which(f"python{a}.{b}")
        if exe:
            candidates.append([exe])
    for c in candidates:
        if _py_ok_for_kokoro(c):
            return c
    return None


def _ensure_espeak() -> None:
    """Kokoro pronounces unusual words with espeak-ng. Optional; best effort."""
    if shutil.which("espeak-ng"):
        return
    if OS == "Windows" and (Path(r"C:\Program Files\eSpeak NG\espeak-ng.exe")).exists():
        return
    if OS == "Darwin" and shutil.which("brew"):
        try:
            _run(["brew", "install", "espeak-ng"])
            return
        except Exception:  # noqa: BLE001
            pass
    hint = {
        "Windows": "install the .msi from https://github.com/espeak-ng/espeak-ng/releases",
        "Linux": "sudo apt install espeak-ng   (or your distro's equivalent)",
        "Darwin": "brew install espeak-ng",
    }.get(OS, "install espeak-ng")
    _say(f"   ℹ️  espeak-ng not found (Kokoro still works, pronunciation is a bit worse): {hint}")


def step_kokoro() -> str:
    py = _find_kokoro_python()
    if py is None:
        raise RuntimeError(
            "Kokoro needs Python 3.10–3.12 and none was found. Install Python 3.12 "
            "(https://python.org) and re-run:  python setup.py   (the rest is already done)")
    if not ULTRON.exists():
        raise RuntimeError("ultron-py/ folder not found")

    _ensure_espeak()

    venv = ULTRON / "tts" / "venv"
    vpy = venv / ("Scripts/python.exe" if OS == "Windows" else "bin/python")
    (ULTRON / ".tts").mkdir(exist_ok=True)
    if not vpy.exists():
        _run(py + ["-m", "venv", venv])
    _run([vpy, "-m", "pip", "install", "-q", "--upgrade", "pip"], check=False)
    _run([vpy, "-m", "pip", "install", "-q", "kokoro", "soundfile"])

    _say("   Downloading Kokoro voices …")
    voices = repr(KOKORO_VOICES)
    _run([vpy, "-c",
          "from huggingface_hub import hf_hub_download\n"
          f"for v in {voices}:\n"
          "    hf_hub_download('hexgrad/Kokoro-82M', f'voices/{v}.pt')\n"], cwd=ULTRON)

    # A first synthesis downloads the model weights themselves into the HF cache.
    _say("   Warming up the model (downloads the 82M-parameter weights) …")
    test = ULTRON / ".tts" / "test.wav"
    try:
        _run([vpy, ULTRON / "tts" / "kokoro_server.py"], cwd=ULTRON, timeout=1800,
             input_text=f"1\tbm_george\t{test}\tGood evening, sir. All systems are online.\n")
    finally:
        try:
            test.unlink()
        except OSError:
            pass
    return "ultron-py/tts/venv"


# ── summary / notes ────────────────────────────────────────────────────────────

def _os_notes() -> None:
    if OS == "Windows":
        try:
            import win32com.client  # noqa: F401
        except ImportError:
            postinstall = Path(sys.executable).parent / "Scripts" / "pywin32_postinstall.py"
            _say("\n⚠️  pywin32 did not register correctly — desktop-shortcut creation will use a "
                 "slower fallback. To fix it, run:\n"
                 f'    "{sys.executable}" -m pip install --force-reinstall pywin32\n'
                 f'    "{sys.executable}" "{postinstall}" -install')
    elif OS == "Linux":
        _say("\nℹ️  Linux note — a few voice-controlled OS actions shell out to native tools "
             "(need root, so they are not installed automatically):\n"
             "    • volume      → pulseaudio-utils   (pactl)\n"
             "    • brightness  → brightnessctl\n"
             "    • reminders   → systemd (systemd-run) or 'at'\n"
             "    • open URLs   → xdg-utils          (xdg-open)\n"
             "    • Playwright system libs →  python -m playwright install-deps")
    elif OS == "Darwin":
        _say("\nℹ️  macOS note — volume, brightness and reminders use the built-in 'osascript' / "
             "LaunchAgents, so no extra tools are required.")


def _summary() -> None:
    icons = {"ok": "✅", "fail": "⚠️ ", "skip": "⏭ "}
    _say(f"\n{'═' * 70}\n SETUP SUMMARY\n{'═' * 70}")
    for label, status, note in RESULTS:
        tail = f"  — {note}" if note else ""
        _say(f" {icons[status]} {label}{tail}")
    failed = [r for r in RESULTS if r[1] == "fail"]
    if failed:
        _say("\n Some optional steps failed. Everything else works. Fix the cause "
             "(network / Python version) and re-run `python setup.py` — finished steps are skipped.")


# ── main ───────────────────────────────────────────────────────────────────────

def main() -> None:
    ap = argparse.ArgumentParser(description="MARK LVI one-command setup")
    ap.add_argument("--minimal", action="store_true",
                    help="core packages + Playwright only (no extras, models or Kokoro)")
    ap.add_argument("--skip-kokoro", action="store_true", help="skip the ~1 GB Kokoro voice")
    ap.add_argument("--skip-models", action="store_true", help="skip Whisper / wake-word model downloads")
    ap.add_argument("--skip-extras", action="store_true", help="skip optional extra packages")
    args = ap.parse_args()
    if args.minimal:
        args.skip_kokoro = args.skip_models = args.skip_extras = True

    # Windows consoles (cp949 / cp1252) choke on ✅ ▶ etc. — never die on a print.
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")  # type: ignore[attr-defined]
        except Exception:  # noqa: BLE001
            pass

    _say(f"⚙  MARK LVI setup — detected OS: {OS or 'unknown'}, "
         f"Python {sys.version_info[0]}.{sys.version_info[1]}")
    _check_python()

    # 1. Core — the only fatal step: without it the app cannot start.
    _step("1/6  Python dependencies (requirements.txt)")
    _guard("Core Python packages", step_core_requirements, fatal=True)
    _guard("ULTRON Python packages", step_ultron_requirements)

    # 2. Extras
    _step("2/6  Extra Python packages")
    if args.skip_extras:
        _record("Extra Python packages", "skip", "--skip-extras / --minimal")
    else:
        _guard("Extra Python packages", step_extra_packages)

    # 3. Playwright
    _step("3/6  Playwright browsers")
    _guard("Playwright browsers", step_playwright)

    # 4. ULTRON browser-side libraries
    _step("4/6  ULTRON web libraries (three.js, xterm.js)")
    if args.minimal:
        _record("ULTRON web libraries", "skip", "--minimal")
    else:
        _guard("ULTRON web libraries", step_vendor_libs)

    # 5. Models
    _step("5/6  Speech models")
    if args.skip_models:
        _record("Whisper model", "skip", "--skip-models / --minimal")
        _record("Wake-word model", "skip", "--skip-models / --minimal")
    else:
        if _module_available("faster_whisper"):
            _guard("Whisper model", step_whisper_model)
        else:
            _record("Whisper model", "fail", "faster-whisper not installed")
        if _module_available("openwakeword"):
            _guard("Wake-word model", step_wake_word_model)
        else:
            _record("Wake-word model", "fail", "openwakeword not installed")

    # 6. Kokoro
    _step("6/6  Kokoro neural voice (ULTRON)")
    if args.skip_kokoro:
        _record("Kokoro voice", "skip", "--skip-kokoro / --minimal")
    else:
        _guard("Kokoro voice", step_kokoro)

    _guard("Avatar asset check", lambda: (_check_assets(), "core/face_model.obj")[1])
    _os_notes()
    _summary()

    _say("\n✅ Setup finished!")
    _say("   1) Launch it:  python main.py")
    _say("   2) Paste your free Gemini API key when the setup screen appears.")
    _say("   3) Say \"Hey Jarvis\" — the wake word is already installed (enable it in ⚙ → WAKE WORD).")


if __name__ == "__main__":
    main()
