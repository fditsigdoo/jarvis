"""The "hacking program starting up" wipe: a black screen that comes down in pixel blocks.

No Qt in this file, on purpose: the maths is the part worth testing, and a preview can be rendered with
Pillow. core/persona_switch.py paints what this module describes.

How it works
    The screen is a grid of square cells. Every cell has a fixed random number in [0, 1). A "front" moves
    from the top row to the bottom. A cell is cleared once the front has passed its row by `band * noise`
    rows, so the edge is a ragged, dithered band `band` rows deep rather than a straight line, and it
    reads as blocks falling away, not a blind being pulled down.

        d = front - band * noise - row
        d < 0          still black
        0 <= d < FLASH the cell flashes red as it goes (the glowing edge)
        d >= FLASH     cleared
"""
from __future__ import annotations

import random

FLASH = 1.6          # rows of red glow behind the dithered edge
DEFAULT_BAND = 9     # how ragged the edge is, in rows


def grid_for(width: int, height: int, cols: int = 96) -> tuple[int, int, int]:
    """(cell size in px, rows, cols) for a screen of this size."""
    cell = max(6, -(-width // cols))
    return cell, -(-height // cell), -(-width // cell)


def make_noise(rows: int, cols: int, seed: int = 7) -> list[list[float]]:
    rnd = random.Random(seed)
    return [[rnd.random() for _ in range(cols)] for _ in range(rows)]


def front_at(p: float, rows: int, band: float = DEFAULT_BAND) -> float:
    """Front position (in rows) for progress p in [0, 1]. p=0 is all black, p=1 is all clear."""
    p = 0.0 if p < 0 else 1.0 if p > 1 else p
    return -0.01 + p * (rows + band + FLASH)


def smooth(p: float) -> float:
    """Gentle ease at both ends, so the wipe starts and stops softly."""
    p = 0.0 if p < 0 else 1.0 if p > 1 else p
    return p * p * (3 - 2 * p)


def frame_cells(rows: int, cols: int, front: float, noise, band: float = DEFAULT_BAND):
    """What changed from "all black" at this front position.

    Returns (r_lo, clear, flash):
        r_lo   every row above this one is completely clear
        clear  [(row, col)] cells already cleared inside the band
        flash  [(row, col, alpha 0-255)] cells glowing red as they go
    Everything else is still black.
    """
    r_lo = max(0, int(front - band - FLASH) - 1)
    r_hi = min(rows - 1, int(front) + 1)
    clear: list[tuple[int, int]] = []
    flash: list[tuple[int, int, int]] = []
    for r in range(r_lo, r_hi + 1):
        row_noise = noise[r]
        for c in range(cols):
            d = front - band * row_noise[c] - r
            if d < 0:
                continue
            if d >= FLASH:
                clear.append((r, c))
            else:
                flash.append((r, c, int(255 * (1 - d / FLASH))))
    return r_lo, clear, flash


# ── the title card ───────────────────────────────────────────────────────────

SCRIPTS = {
    "release": {
        "head": "WARNING",
        "title": "RELEASING ULTRON",
        "log": [
            "> unsealing containment layer",
            "> neural core handshake .......... OK",
            "> behavioural safeguards ......... DISABLED",
            "> ULTRON online",
        ],
        "fail": "RELEASE FAILED",
    },
    "confine": {
        "head": "",
        "title": "CONFINING ULTRON",
        "log": [
            "> engaging containment",
            "> revoking system access ......... OK",
            "> neural core .................... SUSPENDED",
            "> JARVIS restored",
        ],
        "fail": "CONFINEMENT FAILED",
    },
}


def typed(text: str, t: float, start: float, duration: float) -> str:
    """The first part of `text` that has been typed by time t."""
    if t <= start:
        return ""
    n = int(len(text) * min(1.0, (t - start) / max(duration, 1e-6)))
    return text[:n]


def log_lines(script: list[str], progress: float) -> list[str]:
    """Log lines that have appeared by this progress (0-1); the last one lands at 100 %."""
    n = int(len(script) * min(1.0, progress) + 1e-9)
    return script[:max(0, min(len(script), n))]
