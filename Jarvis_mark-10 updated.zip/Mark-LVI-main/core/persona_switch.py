"""JARVIS <-> ULTRON, in one window.

    "Jarvis, release Ultron"  ->  the screen cuts to black, red text says WARNING / RELEASING ULTRON, then the
                                  black comes down in pixel blocks and ULTRON is underneath.
    CONFINE ULTRON button     ->  the same, saying CONFINING ULTRON, and JARVIS is underneath.

ULTRON runs inside this process as a second page of the main window (a QStackedWidget); nothing is launched
and no port is opened. See core/ultron_host.py for how it is found and built.

Threading: release()/confine() may be called from ANY thread (tools run on workers). They only emit a signal;
everything else happens on the Qt thread.
"""
from __future__ import annotations

import random
import threading
import time

from PyQt6.QtCore import QEvent, QObject, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QFontMetrics, QImage, QPainter, QPen
from PyQt6.QtWidgets import QStackedWidget, QWidget

from . import pixel_wipe as pw

RED = QColor(255, 45, 45)


# ───────────────────────── the overlay ─────────────────────────
class TransitionOverlay(QWidget):
    """Covers the whole window. Phases: cover -> text -> (wait for ready) -> hold -> reveal; or text -> fail -> reveal."""

    COVER = 0.12       # hard cut to black
    TEXT_MIN = 2.7     # the title card is on screen at least this long
    HOLD = 0.35        # everything at 100 % before the wipe starts
    REVEAL = 1.5       # the pixel wipe
    FAIL_HOLD = 2.8
    TIMEOUT = 25.0

    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self.hide()
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent, False)
        self.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self._timer = QTimer(self)
        self._timer.setInterval(33)
        self._timer.timeout.connect(self._tick)
        self._img: QImage | None = None
        self._grid = None      # (w, h, cell, rows, cols, noise)
        self.phase = "idle"
        self.script = pw.SCRIPTS["release"]

    # -- control --
    def start(self, mode: str, ready, on_swap, on_fail, on_done):
        self.script = pw.SCRIPTS[mode]
        self._ready, self._on_swap, self._on_fail, self._on_done = ready, on_swap, on_fail, on_done
        self._swapped = False
        self.reason = ""
        self.phase = "cover"
        self._t0 = self._t_phase = time.monotonic()
        self.setGeometry(self.parentWidget().rect())
        self.raise_()
        self.show()
        self._timer.start()
        self.update()

    def _enter(self, phase: str):
        self.phase = phase
        self._t_phase = time.monotonic()

    def _tick(self):
        now = time.monotonic()
        dt = now - self._t_phase
        try:
            if self.phase == "cover":
                if dt >= self.COVER:
                    self._enter("text")
            elif self.phase == "text":
                if dt >= self.TEXT_MIN:
                    r = self._ready()
                    if r is True:
                        self._on_swap()          # the screen is fully black here, so the swap is invisible
                        self._swapped = True
                        self._enter("hold")
                    elif isinstance(r, str):
                        self.reason = r
                        self._enter("fail")
                    elif dt >= self.TIMEOUT:
                        self.reason = "it did not answer in time"
                        self._enter("fail")
            elif self.phase == "hold":
                if dt >= self.HOLD:
                    self._enter("reveal")
            elif self.phase == "fail":
                if dt >= self.FAIL_HOLD:
                    self._on_fail(self.reason)
                    self._enter("reveal")
            elif self.phase == "reveal":
                if dt >= self.REVEAL:
                    self._finish()
                    return
        except Exception as e:      # a broken swap must never leave a black screen stuck on top
            self.reason = str(e)
            try:
                self._on_fail(self.reason)
            finally:
                self._finish()
            return
        self.update()

    def _finish(self):
        self._timer.stop()
        self.hide()
        self.phase = "idle"
        cb, self._on_done = self._on_done, None
        if cb:
            cb()

    # -- painting --
    def _progress(self) -> float:
        """The bar: eases to 92 % while the title card runs, waits there for ULTRON, then completes."""
        if self.phase in ("hold", "reveal"):
            return 1.0
        if self.phase in ("cover",):
            return 0.0
        dt = time.monotonic() - self._t_phase
        return 0.92 * pw.smooth(dt / self.TEXT_MIN)

    def _fonts(self, h: int):
        def mk(px, bold=True, spacing=0):
            f = QFont()
            f.setFamilies(["Consolas", "Cascadia Mono", "Menlo", "Courier New", "monospace"])
            f.setStyleHint(QFont.StyleHint.Monospace)
            f.setPixelSize(max(8, int(px)))
            f.setBold(bold)
            if spacing:
                f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, spacing)
            return f
        return mk(h * 0.115, True, h * 0.012), mk(h * 0.052, True, h * 0.008), mk(max(11, h * 0.021), False, 0)

    def _glow_text(self, q: QPainter, cx: float, cy: float, text: str, font: QFont, alpha: int = 255):
        q.setFont(font)
        fm = QFontMetrics(font)
        w = fm.horizontalAdvance(text)
        x, y = int(cx - w / 2), int(cy + fm.ascent() / 2 - fm.descent() / 2)
        for dx, dy, a in ((-2, 0, 40), (2, 0, 40), (0, -2, 40), (0, 2, 40), (-4, 0, 18), (4, 0, 18)):
            q.setPen(QColor(255, 45, 45, int(a * alpha / 255)))
            q.drawText(x + dx, y + dy, text)
        q.setPen(QColor(255, 45, 45, alpha))
        q.drawText(x, y, text)

    def _draw_card(self, q: QPainter, w: int, h: int):
        now = time.monotonic()
        t = now - self._t0
        head_f, title_f, log_f = self._fonts(h)
        rnd = random.Random(int(now * 30))
        glitch = (int(now * 1000) % 1100) < 80 and self.phase != "fail"
        gx = rnd.randint(-16, 16) if glitch else 0
        cy = h * 0.42
        if self.phase == "fail":
            head, title = self.script["head"] and "WARNING" or "", self.script["fail"]
        else:
            head, title = self.script["head"], self.script["title"]
        # headline: flickers on for the first second, then holds
        if head:
            on = t > 1.1 or int(t * 9) % 2 == 0
            self._glow_text(q, w / 2 + gx, cy - h * 0.07, head, head_f, 255 if on else 70)
        ty = cy + (h * 0.05 if head else 0)
        if self.phase == "fail":
            self._glow_text(q, w / 2, ty, title, title_f)
            self._glow_text(q, w / 2, ty + h * 0.075, self.reason[:90], log_f, 200)
        else:
            dt = now - self._t_phase if self.phase == "text" else 99.0
            shown = pw.typed(title, dt if self.phase == "text" else 99.0, 0.35, 1.0)
            cursor = "█" if (int(now * 3) % 2 == 0 and self.phase == "text" and len(shown) < len(title) + 40) else " "
            # centre on the FULL title so the line doesn't slide while it types
            fm = QFontMetrics(title_f)
            q.setFont(title_f)
            x = int(w / 2 - fm.horizontalAdvance(title) / 2 + gx)
            base = int(ty + fm.ascent() / 2 - fm.descent() / 2)
            for dx, a in ((-2, 40), (2, 40), (-4, 18), (4, 18)):
                q.setPen(QColor(255, 45, 45, a))
                q.drawText(x + dx, base, shown + cursor)
            q.setPen(RED)
            q.drawText(x, base, shown + cursor)
        # progress bar
        bw, bh = w * 0.34, max(6, h * 0.012)
        bx, by = (w - bw) / 2, ty + h * (0.15 if self.phase != "fail" else 0.17)
        prog = 0.0 if self.phase == "fail" else self._progress()
        if self.phase == "text" and prog >= 0.9:
            prog = 0.92 + 0.02 * (0.5 + 0.5 * (1 if int(now * 4) % 2 else -1))   # waiting for ULTRON: it breathes
        q.setPen(QPen(QColor(255, 45, 45, 160), 1))
        q.setBrush(Qt.BrushStyle.NoBrush)
        q.drawRect(int(bx), int(by), int(bw), int(bh))
        q.fillRect(int(bx + 2), int(by + 2), max(0, int((bw - 4) * prog)), int(bh - 3), QColor(255, 45, 45, 220))
        q.setFont(log_f)
        q.setPen(QColor(255, 45, 45, 150))
        q.drawText(int(bx + bw + 14), int(by + bh), f"{int(prog * 100):3d}%")
        # log lines, bottom left
        lines = pw.log_lines(self.script["log"], prog if self.phase != "fail" else 0.0)
        fm = QFontMetrics(log_f)
        for i, line in enumerate(lines):
            q.setPen(QColor(255, 70, 70, 200 if i == len(lines) - 1 else 120))
            q.drawText(int(w * 0.05), int(h * 0.82 + i * fm.lineSpacing()), line)
        # scanlines
        q.setPen(QColor(0, 0, 0, 70))
        for y in range(0, h, 3):
            q.drawLine(0, y, w, y)

    def paintEvent(self, _e):
        w, h = self.width(), self.height()
        if w < 2 or h < 2 or self.phase == "idle":
            return
        if self._img is None or self._img.width() != w or self._img.height() != h:
            self._img = QImage(w, h, QImage.Format.Format_ARGB32_Premultiplied)
        if self._grid is None or self._grid[0] != w or self._grid[1] != h:
            cell, rows, cols = pw.grid_for(w, h)
            self._grid = (w, h, cell, rows, cols, pw.make_noise(rows, cols))
        _, _, cell, rows, cols, noise = self._grid

        img = self._img
        img.fill(QColor(0, 0, 0, 255))
        q = QPainter(img)
        q.setRenderHint(QPainter.RenderHint.TextAntialiasing, True)
        if self.phase != "cover":
            self._draw_card(q, w, h)
        if self.phase == "reveal":
            front = pw.front_at(pw.smooth((time.monotonic() - self._t_phase) / self.REVEAL), rows)
            r_lo, clear, flash = pw.frame_cells(rows, cols, front, noise)
            # Cleared cells become transparent (so the page underneath shows), the edge glows red as it goes.
            q.setCompositionMode(QPainter.CompositionMode.CompositionMode_Clear)
            if r_lo > 0:
                q.fillRect(0, 0, w, min(h, r_lo * cell), QColor(0, 0, 0, 0))
            for r, c in clear:
                q.fillRect(c * cell, r * cell, cell, cell, QColor(0, 0, 0, 0))
            q.setCompositionMode(QPainter.CompositionMode.CompositionMode_SourceOver)
            for r, c, a in flash:
                q.fillRect(c * cell, r * cell, cell, cell, QColor(255, 45, 45, a))
        q.end()
        p = QPainter(self)
        p.drawImage(0, 0, img)

    def mousePressEvent(self, e):
        e.accept()       # nothing underneath is clickable while the screen is changing

    def keyPressEvent(self, e):
        e.accept()


# ───────────────────────── the switch ─────────────────────────
class PersonaSwitch(QObject):
    release_sig = pyqtSignal()
    confine_sig = pyqtSignal()
    _imported = pyqtSignal(object, str)      # (module or None, error text) from the import thread

    def __init__(self, win):
        super().__init__(win)
        self.win = win
        self.persona = "jarvis"             # "jarvis" | "ultron"
        self.busy = False
        self._pane = None
        self._backend = None
        self._err = ""
        self._muted_by_us = False
        self._title = win.windowTitle()

        # JARVIS keeps living exactly as it was, as page 0 of a stack; ULTRON becomes page 1 when it is first needed.
        old = win.takeCentralWidget()
        self.stack = QStackedWidget(win)
        self.stack.addWidget(old)
        win.setCentralWidget(self.stack)
        # ui.py asks win.centralWidget() all over the place for geometry and as the parent of its floating panels.
        # Keep answering with JARVIS's own page, so none of that changes (and its panels hide with the page).
        win.centralWidget = lambda: old

        self.overlay = TransitionOverlay(win)
        win.installEventFilter(self)

        self.release_sig.connect(self.release)
        self.confine_sig.connect(self.confine)
        self._imported.connect(self._build_pane)

    def eventFilter(self, obj, ev):
        if obj is self.win and ev.type() == QEvent.Type.Resize and self.overlay.isVisible():
            self.overlay.setGeometry(self.win.rect())
        return False

    # -- logging into JARVIS's own log --
    def _log(self, text: str):
        try:
            self.win._log.append_log(text)
        except Exception:
            pass

    # -- JARVIS -> ULTRON --
    def release(self):
        if self.busy or self.persona == "ultron":
            return
        self.busy = True
        self._err = ""
        self.overlay.start("release", self._pane_status, self._swap_to_ultron, self._release_failed, self._idle)
        if self._pane is None:
            # Importing ULTRON's modules is the slow part; do it off the Qt thread while the title card plays.
            threading.Thread(target=self._import_worker, name="ultron-import", daemon=True).start()

    def _import_worker(self):
        try:
            from . import ultron_host
            mod = ultron_host.import_desktop()
            self._imported.emit(mod, "")
        except Exception as e:
            self._imported.emit(None, str(e) or e.__class__.__name__)

    def _build_pane(self, mod, err: str):
        if self._pane is not None:
            return
        if mod is None:
            self._err = err
            return
        try:
            self._backend = mod.Backend()
            self._backend.start()
            self._pane = mod.UltronView(self._backend, None, embedded=True)
            self._pane.confine_requested.connect(self.confine)
            self.stack.addWidget(self._pane)
            self._pane.set_active(False)
            mod.boot_backend(self._backend, self._pane.backend_ready.emit)
            from PyQt6.QtWidgets import QApplication
            QApplication.instance().aboutToQuit.connect(self._backend.stop)
        except Exception as e:
            self._err = str(e) or e.__class__.__name__
            self._pane = None

    def _pane_status(self):
        if self._err:
            return self._err
        if self._pane is None:
            return None
        if self._pane.state == "ready":
            return True
        if self._pane.state == "error":
            return self._pane.error or "ULTRON failed to start"
        return None

    def _swap_to_ultron(self):
        self.stack.setCurrentWidget(self._pane)
        self._pane.set_active(True)
        if not self.win._muted:
            self._muted_by_us = True
            self.win._set_muted(True, "ULTRON has control.")
        self.win.setWindowTitle("ULTRON")
        self.persona = "ultron"
        self._pane.setFocus()

    def _release_failed(self, reason: str):
        self._log(f"SYS: ULTRON could not be released: {reason}")

    # -- ULTRON -> JARVIS --
    def confine(self):
        if self.busy or self.persona != "ultron":
            return
        self.busy = True
        self.overlay.start("confine", lambda: True, self._swap_to_jarvis, lambda r: None, self._idle)

    def _swap_to_jarvis(self):
        if self._pane is not None:
            self._pane.set_active(False)
        self.stack.setCurrentIndex(0)
        if self._muted_by_us:
            self._muted_by_us = False
            self.win._set_muted(False, "JARVIS has control.")
        self.win.setWindowTitle(self._title)
        self.persona = "jarvis"

    def _idle(self):
        self.busy = False
