"""Finding ULTRON and getting it ready to live inside JARVIS's window.

ULTRON is the `ultron-py` folder. It is looked for, in order:
    1. the ULTRON_DIR environment variable
    2. <this project>/ultron-py          (the default: unzip it next to main.py)
    3. <this project>/../ultron-py

Two moments matter:
    preregister()     Before the QApplication exists. Qt requires QtWebEngine to be imported, and ULTRON's
                      private ultron:// URL scheme registered, before the app is created. It costs nothing when
                      ULTRON isn't installed, and it does NOT import ULTRON's agent: that waits until the
                      first release.
    import_desktop()  The first time ULTRON is released (off the Qt thread). Imports ultron.desktop.
"""
from __future__ import annotations

import importlib
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
_dir: Path | None = None


def find_dir() -> Path | None:
    global _dir
    if _dir is not None:
        return _dir
    cands = []
    if os.environ.get("ULTRON_DIR"):
        cands.append(Path(os.environ["ULTRON_DIR"]).expanduser())
    cands += [ROOT / "ultron-py", ROOT.parent / "ultron-py"]
    for c in cands:
        if (c / "ultron" / "desktop.py").is_file():
            _dir = c
            return c
    return None


def _on_path(d: Path) -> None:
    # Appended, never prepended: JARVIS's own packages (memory, core, config...) must always win a name clash.
    p = str(d)
    if p not in sys.path:
        sys.path.append(p)


def preregister() -> bool:
    """Call before QApplication is created. True if ULTRON can be hosted."""
    d = find_dir()
    if d is None:
        return False
    try:
        from PyQt6 import QtWebEngineWidgets  # noqa: F401  (must be imported before the QApplication exists)
        from PyQt6.QtCore import QCoreApplication, Qt
    except ImportError:
        return False        # PyQt6-WebEngine isn't installed: release will say so
    _on_path(d)
    from ultron.qtscheme import register_scheme
    register_scheme()
    QCoreApplication.setAttribute(Qt.ApplicationAttribute.AA_ShareOpenGLContexts)
    return True


def import_desktop():
    """ULTRON's window module (ultron.desktop). Raises a sentence a person can act on."""
    d = find_dir()
    if d is None:
        raise RuntimeError("the ultron-py folder was not found next to JARVIS (or set ULTRON_DIR)")
    _on_path(d)
    try:
        from PyQt6 import QtWebEngineWidgets  # noqa: F401
    except ImportError:
        raise RuntimeError("ULTRON needs PyQt6-WebEngine:  pip install PyQt6-WebEngine") from None
    try:
        return importlib.import_module("ultron.desktop")
    except SystemExit as e:                     # ultron.desktop exits with a message when a dependency is missing
        raise RuntimeError(str(e)) from None
    except ImportError as e:
        raise RuntimeError(f"ULTRON is missing a package ({e}). Run: pip install -r ultron-py/requirements.txt") from None
