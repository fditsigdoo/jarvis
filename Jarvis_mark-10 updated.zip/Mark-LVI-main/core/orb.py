"""
The orb — centrepiece of the HUD.

Pure numpy, no Qt. `OrbModel` advances the animation and hands back plain
arrays; ui.py only has to stroke them. Keeping the maths out of the paint code
means it can be previewed or tested without a window.

What it draws, and why each part moves:

  * ribbons   Thin luminous curves orbiting a point. At rest they are loose,
              wandering wisps (STANDBY). As the assistant becomes active they
              pull into tilted elliptical orbits and lengthen into sweeping
              arcs (SPEAKING). `order` is that 0 -> 1 transition.
  * rings     A fine bundle of concentric ellipses and a graduated dial. They
              fade in with `order`, so a quiet orb is only wisps and a busy
              one is a full instrument.
  * core      The light at the centre. Its brightness follows `energy`, which
              the live audio level lifts, so the orb pulses with the voice.
"""
from __future__ import annotations

import math

import numpy as np

# Each palette: core = centre glow, ribbon = bright stroke when active,
# accent = the few warm strands, cool = what everything fades to at rest.
PALETTES: dict[str, dict[str, tuple[int, int, int]]] = {
    "gold":     dict(core=(255, 208, 110), ribbon=(255, 240, 196),
                     accent=(255, 192, 72),  cool=(176, 208, 255)),
    "ice":      dict(core=(140, 196, 255), ribbon=(222, 238, 255),
                     accent=(255, 204, 108), cool=(176, 208, 255)),
    "lavender": dict(core=(170, 150, 238), ribbon=(238, 230, 255),
                     accent=(255, 226, 150), cool=(196, 190, 255)),
    "mint":     dict(core=(118, 232, 188), ribbon=(222, 255, 240),
                     accent=(255, 226, 150), cool=(160, 232, 255)),
}


def palette_for(model_label: str) -> str:
    """Pick a palette from whatever the model is called."""
    m = (model_label or "").lower()
    if any(k in m for k in ("gpt", "openai", "o1", "o3", "astra")):
        return "lavender"
    if any(k in m for k in ("claude", "anthropic", "fable", "opus", "sonnet")):
        return "ice"
    if any(k in m for k in ("qwen", "llama", "ollama", "local", "mistral",
                            "deepseek", "phi")):
        return "mint"
    return "gold"


def _mix(a, b, k: float):
    k = max(0.0, min(1.0, k))
    return tuple(a[i] + (b[i] - a[i]) * k for i in range(3))


def _rot(rx: float, ry: float, rz: float) -> np.ndarray:
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)
    mx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
    my = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
    mz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
    return mz @ my @ mx


class OrbModel:
    N = 13          # ribbons
    SEG = 110       # points per ribbon
    MAIN = 5        # ribbons that become the big orbits when active

    def __init__(self, seed: int = 11):
        rng = np.random.default_rng(seed)
        self.t = 0.0
        self.order = 0.0        # 0 = wisps, 1 = orbits
        self.energy = 0.12      # 0..~1.4 brightness of the whole thing
        self.pulse = 0.0        # voice level, smoothed
        self.palette = "gold"
        self.ribbons = []
        for i in range(self.N):
            self.ribbons.append(dict(
                a=float(rng.uniform(0.62, 1.0)),
                b=float(rng.uniform(0.30, 0.78)),
                rx=float(rng.uniform(0, math.tau)),
                ry=float(rng.uniform(0, math.tau)),
                rz=float(rng.uniform(0, math.tau)),
                wx=float(rng.uniform(-0.10, 0.10)),
                wy=float(rng.uniform(-0.10, 0.10)),
                speed=float(rng.uniform(0.30, 0.62) * rng.choice([-1, 1])),
                phase=float(rng.uniform(0, math.tau)),
                length=float(rng.uniform(0.26, 0.52)),
                wob=float(rng.uniform(0.14, 0.36)),
                wf=int(rng.integers(2, 5)),
                wp=float(rng.uniform(0, math.tau)),
                width=float(rng.uniform(0.9, 1.9)),
                warm=bool(rng.random() < 0.28),
                main=i < self.MAIN,
                k=i,
            ))
        # Fixed fine rings (the "bundle" visible while active).
        self.rings = [dict(a=0.72 + 0.045 * k, b=0.38 + 0.05 * k,
                           tilt=0.55 + 0.11 * k, drift=0.020 * (1 if k % 2 else -1))
                      for k in range(6)]

    # ── animation ───────────────────────────────────────────────────────────
    def step(self, dt: float, amp: float, state: str, speaking: bool,
             muted: bool = False) -> None:
        dt = max(0.0, min(0.1, dt))
        if muted:
            o_t, e_t = 0.0, 0.07
        elif speaking:
            o_t, e_t = 1.0, 0.85 + 0.55 * amp
        elif state in ("THINKING", "PROCESSING"):
            o_t, e_t = 0.62, 0.62
        elif state == "LISTENING":
            o_t, e_t = 0.18, 0.30 + 0.45 * amp
        else:                                   # STANDBY / SLEEPING / INIT
            o_t, e_t = 0.0, 0.12
        k_o = 1.0 - math.exp(-dt * 1.9)
        k_e = 1.0 - math.exp(-dt * (7.0 if e_t > self.energy else 3.0))
        self.order += (o_t - self.order) * k_o
        self.energy += (e_t - self.energy) * k_e
        self.pulse += (amp - self.pulse) * (1.0 - math.exp(-dt * 14.0))
        self.t += dt * (0.55 + 1.25 * self.order
                        + (0.9 if state in ("THINKING", "PROCESSING") else 0.0))

    # ── geometry ────────────────────────────────────────────────────────────
    def colours(self):
        pal = PALETTES.get(self.palette, PALETTES["gold"])
        k = min(1.0, 0.12 + self.order * 0.95)
        return dict(
            ribbon=_mix(pal["cool"], pal["ribbon"], k),
            core=_mix(pal["cool"], pal["core"], k),
            accent=_mix(pal["cool"], pal["accent"], 0.45 + 0.55 * k),
        )

    def frame(self) -> dict:
        """Everything the painter needs, in unit coordinates (radius 1)."""
        t, od = self.t, self.order
        col = self.colours()
        breath = 1.0 + 0.045 * self.pulse + 0.012 * math.sin(t * 0.8)
        u = np.linspace(0.0, 1.0, self.SEG)
        env = np.sin(np.pi * u) ** 0.85 * (0.40 + 0.60 * u)
        env = env / max(1e-6, env.max())
        out = []
        for r in self.ribbons:
            k = r["k"]
            free_len = r["length"]
            orb_len = (0.50 + 0.07 * (k % 3)) if r["main"] else min(0.92, free_len * 1.9)
            span = (free_len + (orb_len - free_len) * od) * math.tau
            head = r["phase"] + r["speed"] * t
            th = head - span * (1.0 - u)
            wob = r["wob"] * (1.0 - od) ** 1.2
            x = r["a"] * np.cos(th) + wob * np.sin(r["wf"] * th + r["wp"] + 0.35 * t)
            y = r["b"] * np.sin(th) + wob * np.cos((r["wf"] + 1) * th + r["wp"] - 0.27 * t)
            z = 0.55 * np.sin(2.0 * th + r["wp"]) * (0.4 + 0.6 * (1.0 - od))
            R = _rot(r["rx"] + r["wx"] * t, r["ry"] + r["wy"] * t, r["rz"])
            P = R @ np.vstack([x, y, z])
            alpha = 1.0
            if r["main"]:
                # A clean tilted ellipse, evenly fanned out, slowly precessing.
                d = 1.0 if k % 2 == 0 else -1.0
                a_o, b_o = 0.94, 0.40 + 0.06 * k
                Ro = _rot(0.95 + 0.10 * k + 0.03 * d * t,
                          0.18 * (k - 2),
                          k * math.pi / self.MAIN + 0.10 * d * t)
                Po = Ro @ np.vstack([a_o * np.cos(th), b_o * np.sin(th),
                                     0.0 * th])
                P = P * (1.0 - od) + Po * od
            else:
                alpha = (1.0 - 0.86 * od) * 0.8   # the rest recede into the glow
            s = 1.0 / (1.0 - 0.30 * P[2])
            pts = np.stack([P[0] * s, P[1] * s], axis=1) * breath
            out.append(dict(pts=pts, env=env, width=r["width"],
                            warm=r["warm"], alpha=alpha))
        rings = []
        if od > 0.04:
            for g in self.rings:
                ang = g["tilt"] + g["drift"] * t * 6.0
                c, s_ = math.cos(ang), math.sin(ang)
                a, b = g["a"] * breath, g["b"] * breath
                phi = np.linspace(0, math.tau, 140)
                ex, ey = a * np.cos(phi), b * np.sin(phi)
                rings.append(np.stack([ex * c - ey * s_, ex * s_ + ey * c], axis=1))
        return dict(
            ribbons=out, rings=rings, colours=col,
            order=od, energy=self.energy, pulse=self.pulse,
            core_r=0.16 + 0.10 * min(1.2, self.energy) + 0.07 * self.pulse,
            dial_phase=t * 0.35,
        )
