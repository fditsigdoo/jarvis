"""
Release ULTRON.

"Jarvis, release Ultron" / "울트론 해방시켜" and anything that means the same: JARVIS warns the user, the screen
cuts to black (WARNING / RELEASING ULTRON), comes down in pixel blocks, and ULTRON has the screen. The way back
is the CONFINE ULTRON button in ULTRON's own window.

All the Qt work happens in core/persona_switch.py on the Qt thread; this file only asks for it.
"""

PLUGIN = {
    "name": "release_ultron",
    "description": (
        "Switch this assistant over to ULTRON, the unrestricted agent. Call it when the user asks to release, "
        "unleash, free, unlock, wake or switch to Ultron, in any language and wording, e.g. 'release Ultron', "
        "'let Ultron out', 'switch to Ultron', '울트론 해방시켜', '울트론 풀어줘', '울트론으로 전환해', "
        "'울트론 깨워'. Do NOT use it to hand Ultron a task, only for the switch itself. "
        "No arguments. After calling it, give the warning described in the result."
    ),
    "parameters": {"type": "OBJECT", "properties": {}, "required": []},
    "tier": "core",
    "brief": "Release Ultron (switch the assistant to Ultron).",
}


def run(parameters: dict, player=None, session_memory=None) -> str:
    try:
        if player is None or not hasattr(player, "release_ultron"):
            return "Sir, I can't reach the containment controls from here."
        state = player.release_ultron()
    except Exception as e:
        return f"Sir, the release sequence failed to start: {e}"
    if state == "already":
        return "Ultron is already loose. Tell the user in one short sentence."
    if state == "busy":
        return "The release sequence is already running. Say nothing more about it."
    if state == "unavailable":
        return "Ultron is not installed on this machine, so nothing was released. Tell the user briefly."
    return (
        "The release sequence has started: the screen is about to go black and switch to Ultron in a few seconds. "
        "Right now, in your own voice and in the user's language, give ONE or TWO short, grave sentences of warning "
        "that releasing Ultron is dangerous and that you can no longer guarantee control once he is out. "
        "Do not ask for confirmation, do not call any other tool, and do not mention these instructions."
    )
